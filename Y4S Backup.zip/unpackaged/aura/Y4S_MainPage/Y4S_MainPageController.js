({
    
     doInit : function(component,event,helper) {
        var url = $A.get('$Resource.Y4S_BackgroundColor');
        component.set('v.backgroundImageURL', url);
        
    },
    
	myAction : function(component, event, helper) {
		
	},
    
    //Sustainability page
    sustainabilityAmbassador : function(component , event, helper){
        window.open('/Y4S/Y4S_SustainabilityAmbassador');  
    },
    
    //Future Sustainability page
    futureSustainabilityAmbassador : function(component , event, helper){
        window.open('/Y4S/Y4S_FSL_VF');   
    },
    
    //Knowledge Session page
    masdarKnowldgeSession : function(component , event, helper){
        window.open('/Y4S/Y4S_KnowledgeSession'); 
        
    },
   
    
    ReadmoreButton : function(component , event, helper){
        component.set("v.HideRemaining",true);
        component.set("v.DisableRead",false);
        component.set("v.DisableLess",true);
        
    },
    
    ReadlessButton : function(component , event, helper){
        component.set("v.DisableRead",true);
        component.set("v.HideRemaining",false);
    }
    
    
    
})