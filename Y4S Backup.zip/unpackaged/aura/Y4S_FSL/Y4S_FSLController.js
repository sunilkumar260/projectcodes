({
    futureSustainabilityAmbassador : function(component, event, helper) {
        
        //window.open("https://zsp-masdar.cs84.force.com/Y4S/Y4S_FutureSustainabilityLeader","_blank");
        window.open('/Y4S/Y4S_FutureSustainabilityLeaderVf'); 
        
    }
})