({
	
    handleSave : function(component, event, helper){
        
        //getting the customer information
        var contactRecord = component.get("v.con");
        console.log('final save record customer = '+ JSON.stringify(contactRecord));
        
        var action = component.get("c.createRecords");
        
        action.setParams({
            contactRecord : contactRecord,
            
        });
        action.setCallback(this,function(a){
            var state = a.getState();
            console.log('State = '+state);
            if(state == "SUCCESS"){
                var result =a.getReturnValue();
                console.log('result='+result);
                component.set("v.parentId",result);			
                //alert('Record Saved Successfully');
                /*Getting To Thanks Page Once Save The Page*/
                 window.open('/Y4S/Y4S_ThankYouPage',"_self");
                //this.handleAttachments(component,event,helper);

            } else if(state == "ERROR"){
                //alert('Error in Saving record');
                
            }
        });
        
        $A.enqueueAction(action);
        
    },
   
    
    getContactlang : function(component,event,helper){
        var action = component.get("c.getPickListValues");
        action.setParams({
            objectType : "contact",
            selectedField : "Y4S_Language__c"
        })
        action.setCallback(this,function(response){
             var langpi = response.getReturnValue();
            component.set("v.langpiclist", langpi); 
            
        })
        $A.enqueueAction(action);
    },
    getContactorgtype : function(component,event,helper){
        var action = component.get("c.getPickListValues");
        action.setParams({
            objectType : "contact",
            selectedField : "Y4S_Type_of_Organization__c"
        })
        action.setCallback(this,function(response){
             var orgtype = response.getReturnValue();
            component.set("v.orgtype", orgtype); 
            
        })
        $A.enqueueAction(action);
    },
    
    
    //File Upload Functionality
    
    MAX_FILE_SIZE: 7000000, //Max file size 7 MB 
    CHUNK_SIZE: 10000000,      //Chunk Max size 750Kb 
    
    uploadHelper: function(component, event,actFile) {
        
        component.set("v.showLoadingSpinner", true);
        
        var fileInput = actFile;
        
        var file = fileInput[0];
        var self = this;
        
        if (file.size > self.MAX_FILE_SIZE) {
            component.set("v.showLoadingSpinner", false);
            // component.set("v.fileName", 'Alert : File size cannot exceed ' + self.MAX_FILE_SIZE + ' bytes.\n' + ' Selected file size: ' + file.size);
            component.set("v.fileName", 'File size exceeded.');
            
            return;
        }
        var objFileReader = new FileReader();
        
        objFileReader.onload = $A.getCallback(function() {
            var fileContents = objFileReader.result;
            var base64 = 'base64,';
            var dataStart = fileContents.indexOf(base64) + base64.length;
            
            fileContents = fileContents.substring(dataStart);
            
            self.uploadProcess(component, file, fileContents);
        });
        
        objFileReader.readAsDataURL(file);
    },
    
    uploadProcess: function(component, file, fileContents) {
        
        var startPosition = 0;
        
        var endPosition = Math.min(fileContents.length, startPosition + this.CHUNK_SIZE);
        
        
        this.uploadInChunk(component, file, fileContents, startPosition, endPosition, '');
    },
    
    
    uploadInChunk: function(component, file, fileContents, startPosition, endPosition, attachId) {
        
        var getchunk = fileContents.substring(startPosition, endPosition);
        var action = component.get("c.saveChunk");
        console.log('parent id ='+component.get("v.parentId"));
        action.setParams({
            parentId: component.get("v.parentId"),
            fileName: file.name,
            base64Data: encodeURIComponent(getchunk),
            contentType: file.type,
            fileId: attachId
        });
        
        
        action.setCallback(this, function(response) {
            
            var state = response.getState();
            if (state === "SUCCESS") {
                
                startPosition = endPosition;
                endPosition = Math.min(fileContents.length, startPosition + this.CHUNK_SIZE);
                
                if (startPosition < endPosition) {
                    this.uploadInChunk(component, file, fileContents, startPosition, endPosition, attachId);
                } else {
                    alert('your File is uploaded successfully');
                    component.set("v.showLoadingSpinner", false);
                }
                
            } else if (state === "ERROR") {
                alert('File Upload Error Occured In Server Side:');
            }
        });
        
        $A.enqueueAction(action);
    },
    
     handleAttachments : function(component, event, helper) {
        
        if (component.find("fileId1").get("v.files").length > 0) {
            var uploadvideo = component.find("fileId1").get("v.files");
            console.log('inside uploadvideo');
            console.log ('cv ='+ uploadvideo);
            var actFile = uploadvideo;
            helper.uploadHelper(component, event,actFile);
            component.set('v.ShowSuccessMesg' , true);
            component.set('v.ShowMainForm', false);
        } else {
            alert('Please Select a Valid File');
        }
     },
    
    handleVaidations : function(component,event,helper){
        
        var contactRecord = component.get("v.con"); 
        
       
        if($A.util.isEmpty(contactRecord.LastName) || $A.util.isUndefined(contactRecord.LastName)){
            //  alert('Email Adress is Required');
            component.set('v.pointconError',true);
        }  else{
            component.set('v.pointconError',false);
        }
        
         if($A.util.isEmpty(contactRecord.Y4S_Academic_Insitution_Name__c) || $A.util.isUndefined(contactRecord.Y4S_Academic_Insitution_Name__c)){
            //  alert('Email Adress is Required');
            component.set('v.academicError',true);
        }  else{
            component.set('v.academicError',false);
        }
        
         if($A.util.isEmpty(contactRecord.Y4S_Level_of_students__c) || $A.util.isUndefined(contactRecord.Y4S_Level_of_students__c)){
            //  alert('Email Adress is Required');
            component.set('v.levelError',true);
        }  else{
            component.set('v.levelError',false);
        }
        
         if($A.util.isEmpty(contactRecord.Y4S_Country_of_academic_Institution__c) || $A.util.isUndefined(contactRecord.Y4S_Country_of_academic_Institution__c)){
            //  alert('Email Adress is Required');
            component.set('v.conError',true);
        }  else{
            component.set('v.conError',false);
        }
        
         if($A.util.isEmpty(contactRecord.Y4S_Point_Of_Contact_Email__c) || $A.util.isUndefined(contactRecord.Y4S_Point_Of_Contact_Email__c)){
            //  alert('Email Adress is Required');
            component.set('v.emailError',true);
        }  else{
            component.set('v.emailError',false);
        }
        
         if($A.util.isEmpty(contactRecord.Y4S_Mobile__c) || $A.util.isUndefined(contactRecord.Y4S_Mobile__c)){
            //  alert('Email Adress is Required');
            component.set('v.mobileError',true);
        }  else{
            component.set('v.mobileError',false);
        }
         if($A.util.isEmpty(contactRecord.Y4S_Objective_knowledge_se__c) || $A.util.isUndefined(contactRecord.Y4S_Objective_knowledge_se__c)){
            //  alert('Email Adress is Required');
            component.set('v.objError',true);
        }  else{
            component.set('v.objError',false);
        }
       
        //alert('Date is from Object' + contactRecord.Y4S_Date_of_Knowledge_Session__c);
        //alert('Date is from Object' + today().getTime());
        if($A.util.isEmpty(contactRecord.Y4S_Date_of_Knowledge_Session__c) || $A.util.isUndefined(contactRecord.Y4S_Date_of_Knowledge_Session__c)){
            //  alert('Email Adress is Required');
            component.set('v.dateError',true);
        }  else{
            component.set('v.dateError',false);
        }
        
        if($A.util.isEmpty(contactRecord.Y4S_Group_Size__c) || $A.util.isUndefined(contactRecord.Y4S_Group_Size__c)){
            //  alert('Email Adress is Required');
            component.set('v.groupError',true);
        }  else{
            component.set('v.groupError',false);
        }
        if($A.util.isUndefined(contactRecord.LastName ) ||
           $A.util.isEmpty(contactRecord.Y4S_Academic_Insitution_Name__c) || $A.util.isUndefined(contactRecord.Y4S_Academic_Insitution_Name__c) ||
           $A.util.isEmpty(contactRecord.Y4S_Level_of_students__c) || $A.util.isUndefined(contactRecord.Y4S_Level_of_students__c) ||
           $A.util.isEmpty(contactRecord.Y4S_Country_of_academic_Institution__c) || $A.util.isUndefined(contactRecord.Y4S_Country_of_academic_Institution__c) ||
           $A.util.isEmpty(contactRecord.Y4S_Point_Of_Contact_Email__c) || $A.util.isUndefined(contactRecord.Y4S_Point_Of_Contact_Email__c) ||
           $A.util.isEmpty(contactRecord.Y4S_Mobile__c) || $A.util.isUndefined(contactRecord.Y4S_Mobile__c) ||
            $A.util.isEmpty(contactRecord.Y4S_Objective_knowledge_se__c) || $A.util.isUndefined(contactRecord.Y4S_Objective_knowledge_se__c) ||
            $A.util.isEmpty(contactRecord.Y4S_Date_of_Knowledge_Session__c) || $A.util.isUndefined(contactRecord.Y4S_Date_of_Knowledge_Session__c) ||
           $A.util.isEmpty(contactRecord.Y4S_Group_Size__c) || $A.util.isUndefined(contactRecord.Y4S_Group_Size__c)){
           
           
            console.log('inside false');
            return false;
        }  else{
              console.log('inside true');
            return true;
        } 
         return true;
       
    },
    
     handleAttachmentsValidation : function(component, event, helper) {
    
     
        var cvv= component.find("fileId1").get("v.files");
        console.log('cvv dada= '+cvv);
        
        if (component.find("fileId1").get("v.files") == null) {
            component.set('v.uploadError',true);
        } else{
            component.set('v.uploadError',false);
        }
         
         console.log('before attach validation');
        if(component.find("fileId1").get("v.files") == null)
           {
            
            console.log('inside attach validation');
            return false;
        }else{
             console.log('outside attach validation');
            return true;
        }
        
       },
    
})