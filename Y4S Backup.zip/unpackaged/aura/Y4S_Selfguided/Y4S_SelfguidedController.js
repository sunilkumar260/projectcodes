({
    //FINAL SAVE
    handleSave : function(component, event, helper) {
        console.log('Outside final save');
        
        
        var knowledgeDate = component.get("v.con.Y4S_Date_of_Knowledge_Session__c");
        console.log('knowledgeDate'+knowledgeDate);
        
        var selfguidcheck = component.get("v.con.Self_Guided_Tour__c");
        console.log('Self Guide Check Box Value'+selfguidcheck);
        
        
        var staticLabel = $A.get("$Label.c.Y4S_Group_Size");
        console.log('knowledgeDate'+staticLabel);
        
        
        var action = component.get("c.Groupsum");
        action.setParams({ kdate : component.get("v.con.Y4S_Date_of_Knowledge_Session__c")});
        
        action.setCallback(this, function(response) {
            var state = response.getState(); 
            
            if (state === "SUCCESS") {
                
                console.log('returned values====='+response.getReturnValue());
                var diff = 200-response.getReturnValue();
                console.log('different value is===='+diff);
                
                var gp = component.get("v.con.Y4S_Group_Size__c");
                console.log('gp'+gp);
                console.log('returned values====='+response.getReturnValue());
                var rlimit = (200-response.getReturnValue());
                
                console.log('rlimit'+rlimit);
                
                if(diff < gp){
                    console.log('call Inside ONe');
                    component.set("v.selfGuidShow",true);
                    
                    if(selfguidcheck == true){
                        
                        if(helper.handleVaidations(component, event, helper)){
                            console.log('inside final save');
                            helper.handleSave(component, event, helper);
                        }
                    }else if(diff < response.getReturnValue()){
                        alert("Group size for this date is 200"+"\n"+"Remaining limit of" +" "+ knowledgeDate +" "+ "the day is "+ 0);
                        alert("Reduce the group size or select another date for your visit.");
                        
                    }
                    else {
                        alert("Group size for this date is 200"+"\n"+"Remaining limit of" +" "+ knowledgeDate +" "+ "the day is "+" "+ (rlimit) );
                        alert("Reduce the group size or select another date for your visit.");
                        
                    }
                    
                }else{
                    //alert('Day limit is available for Knowldge Session');
                    
                    component.set("v.selfGuidShow",false);
                    
                    console.log('Handle Validation' + helper.handleVaidations(component, event, helper));
                    
                    if(helper.handleVaidations(component, event, helper)){
                        console.log('inside final save');
                        helper.handleSave(component, event, helper);
                    }
                }
                
            }      else if (state === "INCOMPLETE") {
                console.log('INCOMPLETE');
                // do something
            }else if (state === "ERROR") {
                console.log('ERROR');
            }
            
        });
        
        $A.enqueueAction(action);        
        
        
    },
    doInit : function(component,event,helper) {
        var today = new Date();
        var dd = String(today.getDate() ).padStart(2, '0');
        console.log('response date is===='+dd);
        
        var mm = String(today.getMonth()+1).padStart(2, '0'); //January is 0!
        console.log('response month is===='+ mm);
        var yyyy = today.getFullYear();
        
        today = yyyy + '-' + mm + '-' + dd;
        console.log('Final date date is===='+ today);
        
        component.set("v.todaysDate",today);
        
      
        //helper.getrecordamount(component,event,helper);
        //Background Image
        //var url = $A.get('$Resource.Y4S_BackgroundColor');
        //component.set('v.backgroundImageURL', url);
        
    },
    
    
    
    onlangChange : function(component,event,helper){
        
        var value = component.find('lang').get('v.value');
        console.log('lang is'+value);
        component.set("v.con.Y4S_Language__c",value);
        
    },
    
    handleCheck : function(component, event, helper) {
        var isChecked = component.find("saterms").get("v.checked");
        component.set("v.con.Self_Guided_Tour__c", isChecked);
        // console.log('self value is===='+ v.con.Self_Guided_Tour__c);
        
    },
    
    onorgtypeChange : function(component,event,helper){
        
        var value = component.find('orgtype').get('v.value');
        console.log('orgtype is '+value);
        component.set("v.con.Y4S_Type_of_Organization__c",value);
        
    },
    gotoHomePage : function (component, event, helper) {
        window.open('/Y4S/Y4S_LandingHomePage','_self'); 
    },
    
    
    //File Upload Functionalty
    doSave: function(component, event, helper) {
        var uploadvideo = component.find("fileId1").get("v.files");
        
        if (uploadvideo.length > 0) {
            console.log('inside uploadvideo');
            console.log ('cv ='+uploadvideo);
            var actFile = uploadvideo;
            helper.uploadHelper(component, event,actFile);
        } else {
            alert('Please Select a Valid File Video');
        }
    },
    
    UploadVideo: function(component, event, helper) {
        var fileName = 'No File Selected..';
        if (event.getSource().get("v.files").length > 0) {
            fileName = event.getSource().get("v.files")[0]['name'];
        }
        component.set("v.fileName1", fileName);
    }
})