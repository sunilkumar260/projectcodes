({
    knowledgesession : function(component, event, helper) {
        
        window.open("https://zsp-masdar.cs84.force.com/Y4S/Y4S_Masdarknowledgesession","_blank");
        
    },
    selfguided : function(component, event, helper) {
        
       
        
       window.open("https://zsp-masdar.cs84.force.com/Y4S/Y4S_MasdarSelfGuidedTour","_blank");
        
    }
})