({               
    //FINAL SAVE
    handleSave : function(component, event, helper) {
        
        var contactRecord = component.get("v.con"); 
        
        helper.HandleValidations(component, event, helper);        
        
        if (component.find("fileId1").get("v.files") == null) {
            component.set('v.uploadcvError',true);
        }
        if (component.find("fileId2").get("v.files") == null) {
            component.set('v.uploadpassportError',true);
        }
        
        if (component.find("fileId4").get("v.files") == null) {
            component.set('v.uploadpasspError',true);
        }
        
        
         if (component.find("fileId6").get("v.files") == null) {
            component.set('v.uploadvideoError',true);
        }
       
        if($A.util.isEmpty(contactRecord.Y4S_Email__c) || $A.util.isUndefined(contactRecord.Y4S_Email__c)){
            component.set('v.emailError',true);
        } else {
            component.set('v.emailError',false);
            
            var action = component.get("c.validateEmail");
            action.setParams({ email : contactRecord.Y4S_Email__c });
            
            action.setCallback(this, function(response) {
                var state = response.getState();            
                if (state === "SUCCESS") {
                    
                    if(response.getReturnValue() > 0){
                        component.set('v.emailValidationError',true);  
                    }else{
                        component.set('v.emailValidationError',false);
                        if(helper.HandleValidations(component, event, helper) && helper.HandleAttachmentsValidation(component, event, helper)){
                            
                            helper.handleSave(component, event, helper);
                            
                        }
                    }
                }
                else if (state === "INCOMPLETE") {
                    console.log('INCOMPLETE');
                    // do something
                }else if (state === "ERROR") {
                    console.log('ERROR');
                }
                
            });
            
            $A.enqueueAction(action);        
            
        }
    },
    doInit : function(component,event,helper) {
        //Contact SA picklist
        helper.getContactuniversity(component,event,helper);
        
        helper.getContactyear(component,event,helper);
        helper.getContactemirate(component,event,helper);
        helper.getContactRecord(component,event,helper);
        helper.getAreaOfStudy(component,event,helper);
        //Background Image
        //var url = $A.get('$Resource.Y4S_BackgroundColor');
        //component.set('v.backgroundImageURL', url);
        
    },
    ParentalConcentFormPdf : function(component , event, helper){
        
        window.open('/Y4S/Y4S_ParentalConsentFormPDF');
    }, 
    onUniversityChange : function(component,event,helper){
        
        var value = component.find('university').get('v.value');
        console.log('university  is'+value);
        component.set("v.con.Y4S_University_Name__c",value);
        if(value == "Others"){
            component.set("v.ShowOtherUniver",true);
            component.set("v.ShowOtherUniver1",false);
            
        }
        else{
            component.set("v.ShowOtherUniver",false);
            component.set("v.ShowOtherUniver1",true);
        }
        
    },
    onSubChange : function(component,event,helper){        
        var value = component.find('subject').get('v.value');
        component.set("v.con.Current_Major_Area_of_Study__c",value);
         if(value == "Other"){
            component.set("v.ShowOtherArea",true);
            
        }
        else{
            component.set("v.ShowOtherArea",false);
           
        }
        
    },
    
    onyearChange : function(component,event,helper){
        
        var value = component.find('yearpic').get('v.value');
        console.log('yearpic is '+value);
        component.set("v.con.Y4S_Year__c",value);
        
    },
    onemirateChange : function(component,event,helper){
        
        var value = component.find('emirate').get('v.value');
        console.log('emirate is '+value);
        component.set("v.con.Y4S_Emirate__c",value);
        
        if(value == "International"){
            component.set("v.ShowOtherEmirate",true);
            component.set("v.ShowOtherEmirate1",false);
        }
        else{
            component.set("v.ShowOtherEmirate",false);
            component.set("v.ShowOtherEmirate1",true);
        }
        
    },
    
    ontermsChange : function(component, event, helper){
        var value = component.find('terms').get('v.value');
        component.set("v.con.Y4S_Terms_and_Condition__c",value);
        consol.log('Terms==='+value);
    },
    
    gotoHomePage : function (component, event, helper) {
        window.open('/Y4S/Y4S_LandingHomePage',"_self"); 
    },
    
    handleCheck : function(component, event, helper) {
        var isChecked = component.find("DisclaimerCheckBox").get("v.checked");
        
        component.set("v.con.Y4S_FSL_Terms__c", isChecked);
    },
    onrecordChange : function(component,event,helper){
        
        var value = component.find('recordvideo').get('v.value');
        console.log('recordvideo is '+value);
        component.set("v.con.Y4S_Upload_Video__c",value);
        if(value == 'Record & Upload'){
            console.log('Enter Into The  upload video **********' + value);
            component.set("v.showvideosec",true);
            
        }else{
            component.set("v.showvideosec",false);
            
        } if (value == 'Upload Video'){
            
            component.set("v.showuploadsec",true);
        }else{
            component.set("v.showuploadsec",false);
        }
        
        
    },
    
    handleCheck : function(component, event, helper) {
        var isChecked = component.find("saterms").get("v.checked");
        component.set("v.con.Y4S_FSL_Terms__c", isChecked);
        //consol.log('Terms and conditions are=='+component.get("v.con.Y4S_SA_Terms__c"));
        if(isChecked == true){
            component.set("v.disabledSubmit", false);
            
        }else{
            component.set("v.disabledSubmit", true);
        }
    },
    
    //File Upload Functionalty
    doSave: function(component, event, helper) {
        var cv = component.find("fileId1").get("v.files");
        var passCopy = component.find("fileId2").get("v.files");
        var emiId = component.find("fileId3").get("v.files");
        var passPhoto = component.find("fileId4").get("v.files");
        //var consForm = component.find("fileId5").get("v.files");
        var uploadrecvido = component.find("fileId6").get("v.files");
        var uploadvideo = component.find("fileId7").get("v.files");
        console.log('inside do Save');
        
        if (cv.length > 0) {
            console.log('inside cv');
            console.log ('cv ='+cv);
            var actFile = cv;
            helper.uploadHelper(component, event,actFile);
        } else {
            alert('Please Select a Valid File CV');
        }
        
        if (passCopy.length > 0) {
            
            console.log('inside passCopy');
            console.log ('passCopy ='+passCopy);
            var actFile = passCopy;
            helper.uploadHelper(component, event,actFile);
        } else {
            alert('Please Select a Valid File PASSPORT COPY');
        }
        
        if (emiId.length > 0) {
            
            console.log('inside emiId');
            console.log ('emiId ='+emiId);
            
            var actFile = emiId;
            helper.uploadHelper(component, event,actFile);
        } else {
            alert('Please Select a Valid File EMIRATE ID');
        }
        
        if (passPhoto.length > 0) {
            
            console.log('inside passPhoto');
            console.log ('passPhoto ='+passPhoto);
            
            var actFile = passPhoto;
            helper.uploadHelper(component, event,actFile);
        } else {
            alert('Please Select a Valid File PASSPORT PHOTO');
        }
        
        /*if (consForm.length > 0) {
            console.log('inside consForm');
            console.log ('consForm ='+consForm);
            
            var actFile = consForm;
            helper.uploadHelper(component, event,actFile);
        } else {
            alert('Please Select a Valid File CONSENT FORM');
        }  */
        
        if (uploadrecvido.length > 0) {
            console.log('inside uploadrecvido');
            console.log ('Recorded video  ='+uploadrecvido);
            
            var actFile = uploadrecvido;
            helper.uploadHelper(component, event,actFile);
        } else {
            alert('Please Select a Valid File CONSENT FORM');
        } 
        
        if (uploadvideo.length > 0) {
            console.log('inside uploadvideo');
            console.log ('Upload Video ='+uploadvideo);
            var actFile = uploadvideo;
            helper.uploadHelper(component, event,actFile);
        } else {
            alert('Please Select a Valid File CV');
        }
        
        
    }, 
    
    latestCV: function(component, event, helper) {
        var fileName = 'No File Selected..';
        if (event.getSource().get("v.files").length > 0) {
            fileName = event.getSource().get("v.files")[0]['name'];
            console.log(event.getSource().get("v.files")[0]['type']);
        }

        if(event.getSource().get("v.files")[0]['type']=='video/mp4' || event.getSource().get("v.files")[0]['type']=='video/webm'){
            component.set("v.uploadcvFormatError", true);
            component.set("v.uploadcvError", false); 
            return false;
        }
        
        component.set("v.fileName1", fileName);
        component.set("v.uploadcvFormatError", false);
        component.set("v.uploadcvError", false);        
        
    },
    
    passport: function(component, event, helper) {
        var fileName = 'No File Selected..';
        if (event.getSource().get("v.files").length > 0) {
            fileName = event.getSource().get("v.files")[0]['name'];
        }
        if(event.getSource().get("v.files")[0]['type']=='video/mp4' || event.getSource().get("v.files")[0]['type']=='video/webm'){
            component.set("v.uploadpassportFormatError", true);
            component.set("v.uploadpassportError", false); 
            return false;
        }

        component.set("v.fileName2", fileName);
        component.set("v.uploadpassportFormatError", false); 
        component.set("v.uploadpassportError", false);
    },
    
    emirtaesId: function(component, event, helper) {
        var fileName = 'No File Selected..';
        if (event.getSource().get("v.files").length > 0) {
            fileName = event.getSource().get("v.files")[0]['name'];
        }
        component.set("v.fileName3", fileName);
        component.set("v.uploademirateError", false); 
    },
    PassportPhoto: function(component, event, helper) {
        var fileName = 'No File Selected..';
        if (event.getSource().get("v.files").length > 0) {
            fileName = event.getSource().get("v.files")[0]['name'];
        }
        component.set("v.fileName4", fileName);
        component.set("v.uploadpasspError", false); 
    },
    /*
    ParentConsForm: function(component, event, helper) {
        var fileName = 'No File Selected..';
        if (event.getSource().get("v.files").length > 0) {
            fileName = event.getSource().get("v.files")[0]['name'];
        }
        component.set("v.fileName5", fileName);
        component.set("v.uploadconsentError", false);
    }, */
     UploadVideoForm: function(component, event, helper) {
        var fileName = 'No File Selected..';
        if (event.getSource().get("v.files").length > 0) {
            fileName = event.getSource().get("v.files")[0]['name'];
        }
        component.set("v.fileName6", fileName);
        component.set("v.uploadvideoError", false);
    },
   
})