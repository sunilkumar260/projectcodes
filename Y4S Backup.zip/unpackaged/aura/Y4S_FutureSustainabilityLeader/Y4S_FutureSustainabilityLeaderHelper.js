({
    handleSave : function(component, event, helper){
        
        //getting the customer information
        var contactRecord = component.get("v.con");
        console.log('final save record customer = '+ JSON.stringify(contactRecord));
        
        var action = component.get("c.createRecords");
        
        action.setParams({
            contactRecord : contactRecord,
            
        });
        action.setCallback(this,function(a){
            var state = a.getState();
            console.log('State = '+state);
            if(state == "SUCCESS"){
                var result =a.getReturnValue();
                console.log('result='+result);
                component.set("v.parentId",result);		
                //alert('Your Files are uploaded successfully');
                //alert('Record Saved Successfully');
                //alert('An email has been sent to your email address');
                
                
                this.handleAttachments(component,event,helper);
                //window.open('/apex/Y4S_ThankYouPage',"_self");
                
            } else if(state == "ERROR"){
                alert('Error in Saving record');
                           }
        });
        
        $A.enqueueAction(action);
        
        
        
    },
    
    
    
    getContactuniversity : function(component,event,helper){
        var action = component.get("c.getPickListValues");
        action.setParams({
            objectType : "contact",
            selectedField : "Y4S_University_Name__c"
        })
        action.setCallback(this,function(response){
            var locationpic = response.getReturnValue();
            console.log('locationpic'+locationpic);
            component.set("v.universitypicklist", locationpic); 
            
        })
        $A.enqueueAction(action);
    },
    getContactemirate : function(component,event,helper){
        var action = component.get("c.getPickListValues");
        action.setParams({
            objectType : "contact",
            selectedField : "Y4S_Emirate__c"
        })
        action.setCallback(this,function(response){
            var emiratep = response.getReturnValue();
            console.log('emiratep'+emiratep);
            component.set("v.emiratepicklist", emiratep); 
            
        })
        $A.enqueueAction(action);
    },
    
    getContactyear : function(component,event,helper){
        var action = component.get("c.getPickListValues");
        action.setParams({
            objectType : "contact",
            selectedField : "Y4S_Year__c"
        })
        action.setCallback(this,function(response){
            var yearval = response.getReturnValue();
            component.set("v.yearpicklist", yearval); 
            
        })
        $A.enqueueAction(action);
    },
    
    getAreaOfStudy : function(component,event,helper){
        var action = component.get("c.getPickListValues");
        action.setParams({
            objectType : "contact",
            selectedField : "Current_Major_Area_of_Study__c"
        })
        action.setCallback(this,function(response){
            var sub = response.getReturnValue();
            component.set("v.subpicklist", sub); 
            
        })
        $A.enqueueAction(action);
    },
    
    getContactRecord : function(component,event,helper){
        var action = component.get("c.getPickListValues");
        action.setParams({
            objectType : "contact",
            selectedField : "Y4S_Upload_Video__c"
        })
        action.setCallback(this,function(response){
            var locationpic = response.getReturnValue();
            component.set("v.recordvideopic", locationpic); 
            
        })
        $A.enqueueAction(action);
    },
    
    //File Upload Functionality
    
    MAX_FILE_SIZE: 7000000, //Max file size 7 MB 
    CHUNK_SIZE: 10000000,      //Chunk Max size 750Kb 
    
    uploadHelper: function(component, event,actFile) {
        
        component.set("v.showLoadingSpinner", true);
        
        var fileInput = actFile;
        
        var file = fileInput[0];
        var self = this;
        
        console.log('self.MAX_FILE_SIZE='+self.MAX_FILE_SIZE);
        console.log('file.size='+file.size);
        
        if (file.size > self.MAX_FILE_SIZE) {
            component.set("v.showLoadingSpinner", false);
            // component.set("v.fileName", 'Alert : File size cannot exceed ' + self.MAX_FILE_SIZE + ' bytes.\n' + ' Selected file size: ' + file.size);
            component.set("v.fileName", 'File size exceeded.');
            
            return false;
        }
        var objFileReader = new FileReader();
        
        objFileReader.onload = $A.getCallback(function() {
            var fileContents = objFileReader.result;
            var base64 = 'base64,';
            var dataStart = fileContents.indexOf(base64) + base64.length;
            
            fileContents = fileContents.substring(dataStart);
            
            self.uploadProcess(component, file, fileContents);
        });
        
        objFileReader.readAsDataURL(file);
    },
    
    uploadProcess: function(component, file, fileContents) {
        
        var startPosition = 0;
        
        var endPosition = Math.min(fileContents.length, startPosition + this.CHUNK_SIZE);
        
        
        this.uploadInChunk(component, file, fileContents, startPosition, endPosition, '');
    },
    
    
    uploadInChunk: function(component, file, fileContents, startPosition, endPosition, attachId) {
        
        console.log('component.get("v.parentId"): '+component.get("v.parentId"));
        console.log('file.name: '+file.name);
        console.log('file.type: '+file.type);
        console.log('attachId: '+attachId);
        console.log(encodeURIComponent(getchunk));
        var getchunk = fileContents.substring(startPosition, endPosition);
        var action = component.get("c.saveChunk");
        console.log('parent id ='+component.get("v.parentId"));
        action.setParams({
            parentId: component.get("v.parentId"),
            fileName: file.name,
            base64Data: encodeURIComponent(getchunk),
            contentType: file.type,
            fileId: attachId
        });
        
        
        action.setCallback(this, function(response) {
            
            var state = response.getState();
            if (state === "SUCCESS") {
                
                startPosition = endPosition;
                endPosition = Math.min(fileContents.length, startPosition + this.CHUNK_SIZE);
                
                if (startPosition < endPosition) {
                    this.uploadInChunk(component, file, fileContents, startPosition, endPosition, attachId);
                } else {
                    //alert('your File is uploaded successfully');
                    component.set("v.showLoadingSpinner", false);
                }
                
            } else if (state === "ERROR") {
                alert('File Upload Error Occured In Server Side:');
            }
        });
        
        $A.enqueueAction(action);
    },
    
    
    handleAttachments : function(component, event, helper) {
        
        if (component.find("fileId1").get("v.files").length > 0) {
            var cv = component.find("fileId1").get("v.files");
            console.log('inside cv');
            console.log ('cv ='+ cv);
            var actFile = cv;
            helper.uploadHelper(component, event,actFile);
            component.set("v.ShowMainForm1", false);
            component.set("v.ShowSuccessMesg1", true);
        } else {
            alert('Please Select a Valid File');
        }
        
        
        if (component.find("fileId2").get("v.files").length > 0) {
            var ps = component.find("fileId2").get("v.files");
            console.log('inside passport copy');
            console.log ('ps ='+ ps);
            var actFile = ps;
            helper.uploadHelper(component, event,actFile);
            component.set("v.ShowMainForm2", false);
            component.set("v.ShowSuccessMesg2", true);
        } else {
            alert('Please Select a Valid File');
        }
        
        
        
        if(component.find("fileId3").get("v.files") != null){
            
        if (component.find("fileId3").get("v.files").length > 0) {
            var ps = component.find("fileId3").get("v.files");
            console.log('inside emirates id');
            console.log ('ps ='+ ps);
            var actFile = ps;
            helper.uploadHelper(component, event,actFile);
           
        } else {
            alert('Please Select a Valid File');
        }
            
        }
        
       
        
        
        if (component.find("fileId4").get("v.files").length > 0) {
            var passPhoto = component.find("fileId4").get("v.files");
            console.log('inside epassPhoto');
            console.log (' passPhoto ='+ passPhoto);
            var actFile = passPhoto;
            helper.uploadHelper(component, event,actFile);
            component.set("v.ShowMainForm4", false);
            component.set("v.ShowSuccessMesg4", true);
        } else {
            alert('Please Select a Valid File');
        }
        
        
       
        
        if (component.find("fileId6").get("v.files").length > 0) {
            var uploadvideo = component.find("fileId6").get("v.files");
            console.log('inside uploadvideo');
            console.log (' uploadvideo ='+ uploadvideo);
            var actFile = uploadvideo;
            helper.uploadHelper(component, event,actFile);
            component.set("v.ShowMainForm6", false);
            component.set("v.ShowSuccessMesg6", true);
        } else {
            alert('Please Select a Valid File');
        }
        
    },
    
    EmailValidations : function(component, event, helper){
        
    },
    
    
    HandleValidations : function(component, event, helper){
        var contactRecord = component.get("v.con"); 
        var flag;
        
        if($A.util.isUndefinedOrNull(contactRecord.FirstName)){
            
            component.set('v.firstNameError',true);
            flag = false;    
        }else{
            component.set('v.firstNameError',false);
        }
        if($A.util.isUndefinedOrNull(contactRecord.LastName)){
            
            component.set('v.lastNameError',true);
            flag = false;
        } else{
            component.set('v.lastNameError',false);
        } 
        
        if($A.util.isUndefinedOrNull(contactRecord.Y4S_Date_Of_Birth__c)){
            // alert('Date Of Birth is Required');
            component.set('v.birthError',true);
            flag = false;
        }else{
            component.set('v.birthError',false);
        }  
        
        var today = new Date();
        var futureDate = new Date(contactRecord.Y4S_Date_Of_Birth__c);
        var CurrentYear =today.getFullYear();
        console.log('Current Date Year====='+ CurrentYear);
        
        var DOBYear = futureDate.getFullYear();
        console.log('Date of Birth Year===='+ DOBYear);
        if(CurrentYear - DOBYear < 18 || CurrentYear - DOBYear > 30){
             flag = false;
            component.set('v.birthDateError1',true);
        }
        else{
            component.set('v.birthDateError1',false);
        }
        
        
        if (today <= futureDate) {
            component.set('v.birthDateError',true);
        }else{
            component.set('v.birthDateError',false);
        }
        
        
        
        if($A.util.isEmpty(contactRecord.Y4S_Email__c) || $A.util.isUndefined(contactRecord.Y4S_Email__c)){
            //  alert('Email Adress is Required');
            component.set('v.emailError',true);
            flag = false;
        } else {
            component.set('v.emailError',false);
        }
        
        if($A.util.isEmpty(contactRecord.Y4S_Mobile__c) || $A.util.isUndefined(contactRecord.Y4S_Mobile__c)){
            // alert('Mobile Number is Required');
            component.set('v.mobileError',true);
            flag = false;
        }  else{
            component.set('v.mobileError',false);
        }
        
        if($A.util.isEmpty(contactRecord.Y4S_Nationality__c) || $A.util.isUndefined(contactRecord.Y4S_Nationality__c)){
            // alert('Mobile Number is Required');
            component.set('v.nationerror',true);
            flag = false;
        }  else{
            component.set('v.nationerror',false);
        }
        
        
        
        if($A.util.isEmpty(contactRecord.Y4S_Current_home_address__c) || $A.util.isUndefined(contactRecord.Y4S_Current_home_address__c)){
            // alert('Mobile Number is Required');
            component.set('v.homeError',true);
            flag = false;
        }  else{        
            component.set('v.homeError',false);
        }
        
        if($A.util.isEmpty(contactRecord.Y4S_University_Name__c) || $A.util.isUndefined(contactRecord.Y4S_University_Name__c)){
            // alert('Mobile Number is Required');
            component.set('v.universityError',true);
            flag = false;
        }  else{
            component.set('v.universityError',false);
        }
        
        /*Other university*/
        if(component.get("v.ShowOtherUniver") == true && ($A.util.isEmpty(contactRecord.Y4S_Other_University_Name__c) || $A.util.isUndefined(contactRecord.Y4S_Other_University_Name__c))){
            component.set('v.otherUniversityError',true);
            flag = false;
        }  else{
            component.set('v.otherUniversityError',false);
        }
        
        
        if($A.util.isEmpty(contactRecord.Y4S_Emirate__c) || $A.util.isUndefined(contactRecord.Y4S_Emirate__c)){
            // alert('Mobile Number is Required');
            component.set('v.emirateError',true);
            flag = false;
        }  else{
            component.set('v.emirateError',false);
        }
        
        if(component.get("v.ShowOtherEmirate") == true && ($A.util.isEmpty(contactRecord.Y4S_Other_Emirate__c) || $A.util.isUndefined(contactRecord.Y4S_Other_Emirate__c))){
            // alert('Other Location is Required');
            console.log('inside other');
            component.set('v.OtherEmirateError',true);
            flag = false;
        }  else{
            component.set('v.OtherEmirateError',false);
        }
        
         if(component.get("v.ShowOtherArea") == true && ($A.util.isEmpty(contactRecord.Y4S_Other_Area_of_Study__c) || $A.util.isUndefined(contactRecord.Y4S_Other_Area_of_Study__c))){
            // alert('Other Location is Required');
            console.log('inside other');
            component.set('v.otherAreaError',true);
            flag = false;
        }  else{
            component.set('v.otherAreaError',false);
        }
        
        if($A.util.isEmpty(contactRecord.Y4S_Year__c) || $A.util.isUndefined(contactRecord.Y4S_Year__c)){
            // alert('Mobile Number is Required');
            component.set('v.yearError',true);
            flag = false;
        }  else{
            component.set('v.yearError',false);
        }
        
        if($A.util.isEmpty(contactRecord.Current_Major_Area_of_Study__c) || $A.util.isUndefined(contactRecord.Current_Major_Area_of_Study__c)){
            // alert('Mobile Number is Required');
            component.set('v.subError',true);
            flag = false;
        }  else{
            component.set('v.subError',false);
        }        
        
        if($A.util.isEmpty(contactRecord.Degree__c) || $A.util.isUndefined(contactRecord.Degree__c)){
            component.set('v.degreeError',true);
            flag = false;
        }  else{
            component.set('v.degreeError',false);
        }  
        
        
        
        if($A.util.isEmpty(contactRecord.Y4S_Twitter_Username__c) || $A.util.isUndefined(contactRecord.Y4S_Twitter_Username__c)){
            // alert('Mobile Number is Required');
            component.set('v.twitterError',true);
            flag = false;
        }  else{
            component.set('v.twitterError',false);
        }
        
        
        if($A.util.isEmpty(contactRecord.Y4S_Instagram_Username__c) || $A.util.isUndefined(contactRecord.Y4S_Instagram_Username__c)){
            component.set('v.instagramError',true);
            flag = false;
        }  else{
            component.set('v.instagramError',false);
        }
        
        
        if($A.util.isEmpty(contactRecord.Y4S_Personal_Biography__c) || $A.util.isUndefined(contactRecord.Y4S_Personal_Biography__c)){
            // alert('Mobile Number is Required');
            component.set('v.personalError',true);
            flag = false;
        }  else{
            component.set('v.personalError',false);
        }
        
        if($A.util.isEmpty(contactRecord.Y4S_why_are_interested__c) || $A.util.isUndefined(contactRecord.Y4S_why_are_interested__c)){
            // alert('Mobile Number is Required');
            component.set('v.interError',true);
            flag = false;
        }  else{
            component.set('v.interError',false);
        }
        //Student Other Information
        
        if($A.util.isEmpty(contactRecord.Y4S_Your_Opinion__c) || $A.util.isUndefined(contactRecord.Y4S_Your_Opinion__c)){
            // alert('Mobile Number is Required');
            component.set('v.opinionError',true);
            flag = false;
        }  else{
            component.set('v.opinionError',false);
        }
        
        if($A.util.isEmpty(contactRecord.Y4S_What_would_you_bring__c) || $A.util.isUndefined(contactRecord.Y4S_What_would_you_bring__c)){
            // alert('Mobile Number is Required');
            component.set('v.discError',true);
            flag = false;
        }  else{
            component.set('v.discError',false);
        }
        
        if($A.util.isEmpty(contactRecord.Y4S_Describe_sustainability_related__c) || $A.util.isUndefined(contactRecord.Y4S_Describe_sustainability_related__c)){
            // alert('Mobile Number is Required');
            component.set('v.rprojError',true);
            flag = false;
        }  else{
            component.set('v.rprojError',false);
        }
        
        if($A.util.isEmpty(contactRecord.Y4S_Suggest_possible_ways_to_engage__c) || $A.util.isUndefined(contactRecord.Y4S_Suggest_possible_ways_to_engage__c)){
            // alert('Mobile Number is Required');
            component.set('v.suggestError',true);
            flag = false;
        }  else{
            component.set('v.suggestError',false);
        }
        
        if($A.util.isEmpty(contactRecord.Y4S_Describe_your_dedication__c) || $A.util.isUndefined(contactRecord.Y4S_Describe_your_dedication__c)){
            // alert('Mobile Number is Required');
            component.set('v.describError',true);
            flag = false;
        }  else{
            component.set('v.describError',false);
        }
        
       
        
        if(flag==false){
            return false;
        }else{
            return true;    
        }
        
        
    },
    
    HandleAttachmentsValidation : function(component, event, helper) {
        
        
        var cvv= component.find("fileId1").get("v.files");
        console.log('cvv dada= '+cvv);
        
        if (component.find("fileId1").get("v.files") == null) {
            console.log('cdcscscsc '+cvv);
            //component.set("v.fileName1", 'Please Upload Your Latest CV');
            component.set('v.uploadcvError',true);
            
        }else if (component.find("fileId1").get("v.files")[0].size > 2000000){
            console.log('inside elsesss');
            component.set("v.fileName1", 'File size cannot be more than 2MB.');
            
        }else {
            console.log('fileId1 else');
            component.set('v.uploadcvError',false);
        }
        
        
        if (component.find("fileId2").get("v.files") == null) {
            console.log('cdcs1111 '+cvv);
            //component.set("v.fileName2", 'Please Upload Your Passport Copy');
            component.set('v.uploadpassportError',true);            
        }else if (component.find("fileId2").get("v.files")[0].size > 2000000){
            console.log('inside elsesss');
            component.set("v.fileName2", 'File size cannot be more than 2MB.');
            
        }else{
            console.log('fileId2 else');
            component.set('v.uploadpassportError',false);
        }
        
        
        
        
        if (component.find("fileId4").get("v.files") == null) {
            console.log('cdcsc333'+cvv);
            //component.set("v.fileName4", 'Please Upload Your Latest Photo Copy');
            component.set('v.uploadpasspError',true);
        }else if (component.find("fileId4").get("v.files")[0].size > 2000000){
            console.log('inside elsesss');
            component.set("v.fileName4", 'File size cannot be more than 2MB.');
            
        }
        else{
            console.log('fileId4 else');
            component.set('v.uploadpasspError',false);
        }
        
        
        
        
        if (component.find("fileId6").get("v.files") == null) {
            console.log('uload video'+cvv);
            
            component.set('v.uploadvideoError',true);
        }else if (component.find("fileId6").get("v.files")[0].size > 2000000){
            console.log('inside elsesss');
            component.set("v.fileName6", 'File size cannot be more than 2MB.');
        }
        else{
            console.log('fileId6 else');
            component.set('v.uploadvideoError',false);
        }
        
        console.log('before attach validation');
        if(component.find("fileId1").get("v.files") == null || component.find("fileId2").get("v.files") == null || 
            component.find("fileId4").get("v.files") == null || component.find("fileId6").get("v.files") == null || 
           component.find("fileId1").get("v.files")[0].size > 2000000 ||
           component.find("fileId2").get("v.files")[0].size > 2000000 ||
           
           component.find("fileId4").get("v.files")[0].size > 2000000 ||
          
           component.find("fileId6").get("v.files")[0].size > 2000000){
            
            console.log('inside attach validation');
            return false;
        }else{
            console.log('outside attach validation');
            return true;
        }
        
        if(component.find("fileId1").get("v.files") != null && component.find("fileId2").get("v.files") != null  &&
        component.find("fileId4").get("v.files") != null && component.find("fileId6").get("v.files") != null){
            
            console.log('inside NOT EMPTY Values');
            component.set('v.ShowSuccessMesg', true)
        }else{
            console.log('outside aNOT EMPTY Values');
            component.set('v.ShowMainForm', false);
        } 
        
    }
})