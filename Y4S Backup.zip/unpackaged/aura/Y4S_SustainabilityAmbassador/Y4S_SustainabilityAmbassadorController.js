({
    doInit : function(component,event,helper) {
        //Contact SA picklist
        helper.getContactGender(component,event,helper);
        helper.getContactlocation(component,event,helper);
        helper.getContactRecord(component,event,helper);
        helper.getContactGuardianGender(component,event,helper);
        helper.getSchoolLocation(component,event,helper);
        
    },
    
    //ParentalConcentForm
    ParentalConcentFormPdf : function(component , event, helper){
        
        window.open('/Y4S/Y4S_ParentalConsentFormPDF');
    }, 
    
    //FINAL SAVE
    FinalSave : function(component, event, helper){
        console.log('Outside final save');
        
        var contactRecord = component.get("v.con"); 
        helper.HandleValidations(component, event, helper);        
        
        if (component.find("fileId1").get("v.files") == null) {
            component.set('v.uploadcvError',true);
        }
        if (component.find("fileId2").get("v.files") == null) {
            component.set('v.uploadpassportError',true);
        }
        
        if (component.find("fileId4").get("v.files") == null) {
            component.set('v.uploadpasspError',true);
        }
        
        
         if (component.find("fileId5").get("v.files") == null) {
            component.set('v.uploadvideoError',true);
        }
          if (component.find("fileId6").get("v.files") == null) {
            component.set('v.uploadguardError',true);
        }
        
        
        
        
        if($A.util.isEmpty(contactRecord.Y4S_Email__c) || $A.util.isUndefined(contactRecord.Y4S_Email__c)){
            component.set('v.emailError',true);
        } else {
            component.set('v.emailError',false);
            
            var action = component.get("c.validateEmail");
            action.setParams({ email : contactRecord.Y4S_Email__c });
            
            action.setCallback(this, function(response) {
                var state = response.getState();            
                if (state === "SUCCESS") {
                    
                    if(response.getReturnValue() > 0){
                        component.set('v.emailValidationError',true);  
                    }else{
                        component.set('v.emailValidationError',false);
                        
                        if(helper.HandleValidations(component, event, helper) && helper.HandleAttachmentsValidation(component, event, helper)){
                            
                            helper.handleSave(component, event, helper);
                            
                        }
                    }
                }
                else if (state === "INCOMPLETE") {
                    console.log('INCOMPLETE');
                    // do something
                }else if (state === "ERROR") {
                    console.log('ERROR');
                }
                
            });
            
            $A.enqueueAction(action);        
            
        }
        /*helper.handleAttachmentsValidation(component, event, helper);
        if(helper.handleVaidations(component, event, helper) && helper.handleAttachmentsValidation(component, event, helper)){
            console.log('inside final save');
            helper.handleSave(component,event,helper);
            
        }*/
        
        
        
        /*  if(helper.handleAttachmentsValidation(component, event, helper)){
            console.log('inside final save');
          helper.handleSave(component,event,helper);
        }*/
        //   helper.handleSave(component,event,helper);
    },
    
    
    onGenderChange : function(component,event,helper){
        
        var value = component.find('gender').get('v.value');
        console.log('gender is'+value);
        component.set("v.con.Y4S_Gender__c",value);
        
    },
    onGuardianGenderchange : function(component,event,helper){
        
        var value = component.find('ggender').get('v.value');
        console.log('gender is'+ value);
        component.set("v.con.Y4S_Guardian_Gender__c",value);
        
    },
    //School Other Location
    onSchoolLocationchange : function(component,event,helper){
        
        var value = component.find('schloc').get('v.value');
        console.log('School Location IS'+ value);
        component.set("v.con.Y4S_School_Location__c",value);
        if(value == 'Other'){
            component.set("v.showOtherSchLoc",true);
            
        }else{
            component.set("v.showOtherSchLoc",false);
        }
        
    },
    
    
    //Student Other Location
    onlocationChange : function(component,event,helper){
        
        var value = component.find('location').get('v.value');
        console.log('Location is '+value);
        component.set("v.con.Y4S_Location__c",value);
        if(value == 'Others'){
            component.set("v.showOtherLoc",true);
            
        }else{
            component.set("v.showOtherLoc",false);
        }
        
    },
    
    
    
    onrecordChange : function(component,event,helper){
        
        var value = component.find('recordvideo').get('v.value');
        console.log('recordvideo is '+value);
        component.set("v.con.Y4S_Upload_Video__c",value);
        if(value == 'Record & Upload'){
            console.log('Enter Into The  upload video **********' + value);
            component.set("v.showvideosec",true);
            
        }else{
            component.set("v.showvideosec",false);
            
        } if (value == 'Upload Video'){
            
            component.set("v.showuploadsec",true);
        }else{
            component.set("v.showuploadsec",false);
        }
        
        
    },
    
    
    
    gotoHomePage : function (component, event, helper) {
        window.open('/Y4S/Y4S_LandingHomePage',"_self"); 
    },
    
/*    
     doSave: function(component, event, helper) {
        var cv = component.find("fileId1").get("v.files");
        var passCopy = component.find("fileId2").get("v.files");
        var emiId = component.find("fileId3").get("v.files");
        var passPhoto = component.find("fileId4").get("v.files");
        
        var uploadrecvido = component.find("fileId5").get("v.files");
        var gurdianupload = component.find("fileId6").get("v.files");
        console.log('inside do Save');
        
        if (cv.length > 0) {
            console.log('inside cv');
            console.log ('cv ='+cv);
            var actFile = cv;
            helper.uploadHelper(component, event,actFile);
        } else {
            alert('Please Select a Valid File CV');
        }
        
        if (passCopy.length > 0) {
            
            console.log('inside passCopy');
            console.log ('passCopy ='+passCopy);
            var actFile = passCopy;
            helper.uploadHelper(component, event,actFile);
        } else {
            alert('Please Select a Valid File PASSPORT COPY');
        }
        
        if (emiId.length > 0) {
            
            console.log('inside emiId');
            console.log ('emiId ='+emiId);
            
            var actFile = emiId;
            helper.uploadHelper(component, event,actFile);
        } else {
            alert('Please Select a Valid File EMIRATE ID');
        }
        
        if (passPhoto.length > 0) {
            
            console.log('inside passPhoto');
            console.log ('passPhoto ='+passPhoto);
            
            var actFile = passPhoto;
            helper.uploadHelper(component, event,actFile);
        } else {
            alert('Please Select a Valid File PASSPORT PHOTO');
        }
        

        if (uploadrecvido.length > 0) {
            console.log('inside uploadrecvido');
            console.log ('Recorded video  ='+uploadrecvido);
            
            var actFile = uploadrecvido;
            helper.uploadHelper(component, event,actFile);
        } else {
            alert('Please Select a valid video file');
        } 
        
        if (gurdianupload.length > 0) {
            console.log('inside gurdianupload');
            console.log ('Upload Video ='+gurdianupload);
            var actFile = gurdianupload;
            helper.uploadHelper(component, event,actFile);
        } else {
            alert('Please Select a valid gurdian form');
        }
        
        
    }, */
    
    latestCV: function(component, event, helper) {
        var fileName = 'No File Selected..';
        if (event.getSource().get("v.files").length > 0) {
            fileName = event.getSource().get("v.files")[0]['name'];
            console.log(event.getSource().get("v.files")[0]['type']);
        }

        if(event.getSource().get("v.files")[0]['type']=='video/mp4' || event.getSource().get("v.files")[0]['type']=='video/webm'){
            component.set("v.uploadcvFormatError", true);
            component.set("v.uploadcvError", false); 
            return false;
        }
        
        component.set("v.fileName1", fileName);
        component.set("v.uploadcvFormatError", false);
        component.set("v.uploadcvError", false);        
        
    },
    
    passport: function(component, event, helper) {
        var fileName = 'No File Selected..';
        if (event.getSource().get("v.files").length > 0) {
            fileName = event.getSource().get("v.files")[0]['name'];
        }
        if(event.getSource().get("v.files")[0]['type']=='video/mp4' || event.getSource().get("v.files")[0]['type']=='video/webm'){
            component.set("v.uploadpassportFormatError", true);
            component.set("v.uploadpassportError", false); 
            return false;
        }

        component.set("v.fileName2", fileName);
        component.set("v.uploadpassportFormatError", false); 
        component.set("v.uploadpassportError", false);
    },
    
    emirtaesId: function(component, event, helper) {
        var fileName = 'No File Selected..';
        if (event.getSource().get("v.files").length > 0) {
            fileName = event.getSource().get("v.files")[0]['name'];
        }
        component.set("v.fileName3", fileName);
        component.set("v.uploademirateError", false); 
    },
    PassportPhoto: function(component, event, helper) {
        var fileName = 'No File Selected..';
        if (event.getSource().get("v.files").length > 0) {
            fileName = event.getSource().get("v.files")[0]['name'];
        }
        component.set("v.fileName4", fileName);
        component.set("v.uploadpasspError", false); 
    },
   
     UploadVideoForm: function(component, event, helper) {
        var fileName = 'No File Selected..';
        if (event.getSource().get("v.files").length > 0) {
            fileName = event.getSource().get("v.files")[0]['name'];
        }
        component.set("v.fileName5", fileName);
        component.set("v.uploadvideoError", false);
    },
    
     guardianConsenForm: function(component, event, helper) {
        var fileName = 'No File Selected..';
        if (event.getSource().get("v.files").length > 0) {
            fileName = event.getSource().get("v.files")[0]['name'];
        }
        component.set("v.fileName6", fileName);
        component.set("v.uploadguardError", false);
    },
    
    
    handleCheck : function(component, event, helper) {
        var isChecked = component.find("saterms").get("v.checked");
        component.set("v.con.Y4S_SA_Terms__c", isChecked);
        //consol.log('Terms and conditions are=='+component.get("v.con.Y4S_SA_Terms__c"));
        if(isChecked == true){
            component.set("v.disabledSubmit", false);
            
        }else{
            component.set("v.disabledSubmit", true);
        }
    },
    register : function(component, event) {
        var inputCmp = component.find("fninput");
        var value = inputCmp.get("v.value");
        // is input valid text?
        if (value == null) {
            inputCmp.setCustomValidity("First Name is mandatory to fill");
        } else {
            inputCmp.setCustomValidity(""); // if there was a custom error before, reset it
        }
        inputCmp.reportValidity(); // Tells lightning:input to show the error right away without needing interaction
    },
    DoBValidation : function(component, event) {
        console.log('inside of DOB validation')
        
        var datevalue = component.find('dateval').get('v.value');
        console.log('input date is==='+datevalue);
        
        var today = new Date();
        var futureDate = new Date(datevalue);
        var CurrentYear =today.getFullYear();
        console.log('Current Date Year====='+ CurrentYear);
        
        var DOBYear = futureDate.getFullYear();
        console.log('Date of Birth Year===='+ DOBYear);
        if(CurrentYear - DOBYear < 18 || CurrentYear - DOBYear > 30){
            component.set('v.birthDateError1',true);
        }
        else {
            component.set('v.birthDateError1',false);
        }
        
        
        if (today <= futureDate) {
            component.set('v.birthDateError',true);
        }else{
            component.set('v.birthDateError',false);
        }
    }
        
        
    
})