({
    
    handleSave : function(component, event, helper){
        
         var contactRecord = component.get("v.con");  
        console.log('final save record customer = '+ JSON.stringify(contactRecord));
        
        var action = component.get("c.createRecords");
        
        action.setParams({
            contactRecord : contactRecord,
            
        });
        
        action.setCallback(this,function(a){
            var state = a.getState();
            console.log('State = '+state);
            if(state == "SUCCESS"){
                var result =a.getReturnValue();
                console.log('result='+result);
                component.set("v.parentId",result);		
               
               alert('An email has been sent to Guardian Email & Supervisor Email');
               
                this.handleAttachments(component,event,helper);
                
            } else if(state == "ERROR"){
                alert('Error in Saving record');
                
            }
        });
        
        $A.enqueueAction(action);
        
        
        
    },
    
    HandleValidations : function(component,event,helper){
        
        var contactRecord = component.get("v.con"); 
        
        //Student Information Validations

        if($A.util.isUndefinedOrNull(contactRecord.FirstName)){
            // alert('First Name is Required');
            component.set('v.firstNameError',true);
        }else{
            component.set('v.firstNameError',false);
        }
        if($A.util.isUndefinedOrNull(contactRecord.LastName)){
            //  alert('Last Name is Required');
            component.set('v.lastNameError',true);
        } else{
            component.set('v.lastNameError',false);
        } 
        if($A.util.isUndefinedOrNull(contactRecord.Y4S_Gender__c)){
            // alert('Gender is Required');
            component.set('v.genderError',true);
        }  else{
            component.set('v.genderError',false);
        }
        if($A.util.isUndefinedOrNull(contactRecord.Y4S_Date_Of_Birth__c)){
            // alert('Date Of Birth is Required');
            component.set('v.birthError',true);
        }else{
            component.set('v.birthError',false);
        }  

        
        if($A.util.isEmpty(contactRecord.Y4S_Email__c) || $A.util.isUndefined(contactRecord.Y4S_Email__c)){
            //  alert('Email Adress is Required');
            component.set('v.emailError',true);
            
        }  else{
            component.set('v.emailError',false);
        }
        
        if($A.util.isEmpty(contactRecord.Y4S_Location__c) || $A.util.isUndefined(contactRecord.Y4S_Location__c)){
            // alert('Location is Required');
            component.set('v.locationError',true);
        } else{
            component.set('v.locationError',false);
        } 
        if($A.util.isEmpty(contactRecord.Y4S_Mobile__c) || $A.util.isUndefined(contactRecord.Y4S_Mobile__c)){
            // alert('Mobile Number is Required');
            component.set('v.mobileError',true);
        }  else{
            component.set('v.mobileError',false);
        }
            console.log('component.get'+component.get("v.showOtherLoc"));
         if(component.get("v.showOtherLoc") == true && ($A.util.isEmpty(contactRecord.Y4S_Other_Location__c) || $A.util.isUndefined(contactRecord.Y4S_Other_Location__c))){
            // alert('Other Location is Required');
            console.log('inside other');
            component.set('v.otherLocationError',true);
        }  else{
            component.set('v.otherLocationError',false);
        }
        
        //school Other Location
        console.log('component.get'+component.get("v.showOtherSchLoc"));
         if(component.get("v.showOtherSchLoc") == true && ($A.util.isEmpty(contactRecord.Y4S_Other_School_Location__c) || $A.util.isUndefined(contactRecord.Y4S_Other_School_Location__c))){
            // alert('Other Location is Required');
            console.log('inside other');
            component.set('v.otherSchLocationError',true);
        }  else{
            component.set('v.otherSchLocationError',false);
        }
        
        
        /*if($A.util.isEmpty(contactRecord.Y4S_Other_Location__c) || $A.util.isUndefined(contactRecord.Y4S_Other_Location__c)){
            alert('Other Location is Required');
            return;
        }  */
        
       
        //Guardian Information Validations
        
        if($A.util.isEmpty(contactRecord.Y4S_Guardian_First_Name__c) || $A.util.isUndefined(contactRecord.Y4S_Guardian_First_Name__c)){
            // alert('Guardian First Name is Required');
            component.set('v.guardFirstNameError',true);
        }  else{
            component.set('v.guardFirstNameError',false);
        }
        if($A.util.isEmpty(contactRecord.Y4S_Guardian_Last_Name__c) || $A.util.isUndefined(contactRecord.Y4S_Guardian_Last_Name__c)){
            //  alert('Guardian Last Name is Required');
            component.set('v.guardlastNameError',true);
        } else{
            component.set('v.guardlastNameError',false);
        } 
        if($A.util.isEmpty(contactRecord.Y4S_Guardian_Gender__c) || $A.util.isUndefined(contactRecord.Y4S_Guardian_Gender__c)){
            // alert('Guardian Gender is Required');
            component.set('v.guardGenderError',true);
        } else{
            component.set('v.guardGenderError',false);
        }
       /* if($A.util.isEmpty(contactRecord.Y4S_Guardian_Email__c) || $A.util.isUndefined(contactRecord.Y4S_Guardian_Email__c)){
            //  alert('Guardian Email Adress is Required');
            component.set('v.guardEmailError',true);
        } else{
            component.set('v.guardEmailError',false);
        } */
        if($A.util.isEmpty(contactRecord.Y4S_Guardian_Mobile__c) || $A.util.isUndefined(contactRecord.Y4S_Guardian_Mobile__c)){
            // alert('Gaurdian Mobile Number is Required');
            component.set('v.guardMobileError',true);
        } else{
            component.set('v.guardMobileError',false);
        }
        

          //Supervisor Information Validations
        
        if($A.util.isEmpty(contactRecord.Y4S_Supervisor_s_First_Name__c) || $A.util.isUndefined(contactRecord.Y4S_Supervisor_s_First_Name__c)){
            // alert('Supervisor First Name is Required');
            component.set('v.superFirstNameError',true);
        } else{
            component.set('v.superFirstNameError',false);
        }
        
        if($A.util.isEmpty(contactRecord.Y4S_Supervisor_s_Last_Name__c) || $A.util.isUndefined(contactRecord.Y4S_Supervisor_s_Last_Name__c)){
            //  alert('Supervisor Last Name is Required');
            component.set('v.superLastNameError',true);
        }else{
            component.set('v.superLastNameError',false);
        }
        
        if($A.util.isEmpty(contactRecord.Y4S_School_Name__c) || $A.util.isUndefined(contactRecord.Y4S_School_Name__c)){
            // alert('Supervisor School Name is Required');
            component.set('v.superSchoolNameError',true);
        } else{
            component.set('v.superSchoolNameError',false);
        }
        
        if($A.util.isEmpty(contactRecord.Y4S_School_Location__c) || $A.util.isUndefined(contactRecord.Y4S_School_Location__c)){
            // alert('Supervisor School Location is Required');
            component.set('v.superSchoolLocError',true);
        } else{
            component.set('v.superSchoolLocError',false);
        }
        
        if($A.util.isEmpty(contactRecord.Y4S_Supervisor_s_Email__c) || $A.util.isUndefined(contactRecord.Y4S_Supervisor_s_Email__c)){
            // alert('Supervisor Email Adress is Required');
            component.set('v.superEmailError',true);
        } else{
            component.set('v.superEmailError',false);
        }
        
        if($A.util.isEmpty(contactRecord.Y4S_Supervisor_s_Mobile__c) || $A.util.isUndefined(contactRecord.Y4S_Supervisor_s_Mobile__c)){
            // alert('Supervisor Mobile Number is Required');
            component.set('v.superMobileError',true);
        }else{
            component.set('v.superMobileError',false);
        } 

        /*
        if($A.util.isEmpty(contactRecord.FirstName) || $A.util.isUndefined(contactRecord.FirstName) || $A.util.isEmpty(contactRecord.LastName) || $A.util.isUndefined(contactRecord.LastName) ||
           $A.util.isEmpty(contactRecord.Y4S_Gender__c) || $A.util.isUndefined(contactRecord.Y4S_Gender__c) ||
           $A.util.isEmpty(contactRecord.Y4S_Date_Of_Birth__c) || $A.util.isUndefined(contactRecord.Y4S_Date_Of_Birth__c) || $A.util.isEmpty(contactRecord.Y4S_Email__c) || $A.util.isUndefined(contactRecord.Y4S_Email__c) ||
           $A.util.isEmpty(contactRecord.Y4S_Location__c) || $A.util.isUndefined(contactRecord.Y4S_Location__c) || $A.util.isEmpty(contactRecord.Y4S_Mobile__c) || $A.util.isUndefined(contactRecord.Y4S_Mobile__c) ||
           $A.util.isEmpty(contactRecord.Y4S_Guardian_First_Name__c) || $A.util.isUndefined(contactRecord.Y4S_Guardian_First_Name__c) || $A.util.isEmpty(contactRecord.Y4S_Guardian_Last_Name__c) || $A.util.isUndefined(contactRecord.Y4S_Guardian_Last_Name__c) ||
           $A.util.isEmpty(contactRecord.Y4S_Guardian_Gender__c) || $A.util.isUndefined(contactRecord.Y4S_Guardian_Gender__c) ||  
           $A.util.isEmpty(contactRecord.Y4S_Guardian_Mobile__c) || $A.util.isUndefined(contactRecord.Y4S_Guardian_Mobile__c) || $A.util.isEmpty(contactRecord.Y4S_Supervisor_s_First_Name__c) || $A.util.isUndefined(contactRecord.Y4S_Supervisor_s_First_Name__c) ||
           $A.util.isEmpty(contactRecord.Y4S_Supervisor_s_Last_Name__c) || $A.util.isUndefined(contactRecord.Y4S_Supervisor_s_Last_Name__c) || $A.util.isEmpty(contactRecord.Y4S_School_Name__c) || $A.util.isUndefined(contactRecord.Y4S_School_Name__c) ||
           $A.util.isEmpty(contactRecord.Y4S_School_Location__c) || $A.util.isUndefined(contactRecord.Y4S_School_Location__c) || $A.util.isEmpty(contactRecord.Y4S_Supervisor_s_Email__c) || $A.util.isUndefined(contactRecord.Y4S_Supervisor_s_Email__c) ||
           $A.util.isEmpty(contactRecord.Y4S_Supervisor_s_Mobile__c) || $A.util.isUndefined(contactRecord.Y4S_Supervisor_s_Mobile__c) ||
           $A.util.isEmpty(contactRecord.Y4S_Other_School_Location__c) || $A.util.isUndefined(contactRecord.Y4S_Other_School_Location__c))
        {
            console.log('inside false');
            return false;
        }  
        else{
              console.log('inside true');
            return true;
        } */
         return true;
              
    },
    getContactGender : function(component,event,helper){
        var action = component.get("c.getPickListValues");
        action.setParams({
            objectType : "contact",
            selectedField : "Y4S_Gender__c"
        })
        action.setCallback(this,function(response){
            var pklist = response.getReturnValue();
            component.set("v.picklistValues", pklist); 
            
        })
        $A.enqueueAction(action);
    },
    getContactGuardianGender : function(component,event,helper){
        var action = component.get("c.getPickListValues");
        action.setParams({
            objectType : "contact",
            selectedField : "Y4S_Guardian_Gender__c"
        })
        action.setCallback(this,function(response){
            var guardiangen = response.getReturnValue();
            component.set("v.Gaurdiangender", guardiangen); 
            
        })
        $A.enqueueAction(action);
    },
    
    getContactlocation : function(component,event,helper){
        var action = component.get("c.getPickListValues");
        action.setParams({
            objectType : "contact",
            selectedField : "Y4S_Location__c"
        })
        action.setCallback(this,function(response){
            var locationpic = response.getReturnValue();
            component.set("v.locpicklistValues", locationpic); 
            
        })
        $A.enqueueAction(action);
    },
    getContactRecord : function(component,event,helper){
        var action = component.get("c.getPickListValues");
        action.setParams({
            objectType : "contact",
            selectedField : "Y4S_Upload_Video__c"
        })
        action.setCallback(this,function(response){
            var locationpic = response.getReturnValue();
            component.set("v.recordvideopic", locationpic); 
            
        })
        $A.enqueueAction(action);
    },
    
    getSchoolLocation : function(component,event,helper){
        var action = component.get("c.getPickListValues");
        action.setParams({
            objectType : "contact",
            selectedField : "Y4S_School_Location__c"
        })
        action.setCallback(this,function(response){
            var schoolloc = response.getReturnValue();
            component.set("v.SchoolLoctn", schoolloc); 
            
        })
        $A.enqueueAction(action);
    },
    
    //File Upload Functionality
    
    MAX_FILE_SIZE: 9000000, //Max file size 7 MB 
    CHUNK_SIZE: 10000000,      //Chunk Max size 750Kb 
    
    uploadHelper: function(component, event,actFile) {
        
        component.set("v.showLoadingSpinner", true);
        
        var fileInput = actFile;
        
        var file = fileInput[0];
        var self = this;
        console.log('self.MAX_FILE_SIZE='+self.MAX_FILE_SIZE);
        console.log('file.size='+file.size);
        if (file.size > self.MAX_FILE_SIZE) {
            console.log('inside max size');
            component.set("v.showLoadingSpinner", false);
            // component.set("v.fileName", 'Alert : File size cannot exceed ' + self.MAX_FILE_SIZE + ' bytes.\n' + ' Selected file size: ' + file.size);
            component.set("v.fileName", 'File size exceeded.');
            
            return false;
        }
        var objFileReader = new FileReader();
        
        objFileReader.onload = $A.getCallback(function() {
            var fileContents = objFileReader.result;
            var base64 = 'base64,';
            var dataStart = fileContents.indexOf(base64) + base64.length;
            
            fileContents = fileContents.substring(dataStart);
            
            self.uploadProcess(component, file, fileContents);
        });
        
        objFileReader.readAsDataURL(file);
    },
    
    uploadProcess: function(component, file, fileContents) {
        
        var startPosition = 0;
        
        var endPosition = Math.min(fileContents.length, startPosition + this.CHUNK_SIZE);
        
        
        this.uploadInChunk(component, file, fileContents, startPosition, endPosition, '');
    },
    
    
    uploadInChunk: function(component, file, fileContents, startPosition, endPosition, attachId) {
        
        var getchunk = fileContents.substring(startPosition, endPosition);
        var action = component.get("c.saveChunk");
        console.log('parent id ='+component.get("v.parentId"));
        //alert(file.name+'-------'+file.type);
        action.setParams({
            parentId: component.get("v.parentId"),
            fileName: file.name,
            base64Data: encodeURIComponent(getchunk),
            contentType: file.type,
            fileId: attachId
        });
        
        
        action.setCallback(this, function(response) {
            
            var state = response.getState();
            if (state === "SUCCESS") {
                
                startPosition = endPosition;
                endPosition = Math.min(fileContents.length, startPosition + this.CHUNK_SIZE);
                
                if (startPosition < endPosition) {
                    this.uploadInChunk(component, file, fileContents, startPosition, endPosition, attachId);
                } else {
                    //alert('your File is uploaded successfully');
                    component.set("v.showLoadingSpinner", false);
                }
                
            } else if (state === "INCOMPLETE") {
                alert("From server: " + response.getReturnValue());
            } else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        
        $A.enqueueAction(action);
    },
    
   handleAttachments : function(component, event, helper) {
        
        if (component.find("fileId1").get("v.files").length > 0) {
            var cv = component.find("fileId1").get("v.files");
            console.log('inside cv');
            console.log ('cv ='+ cv);
            var actFile = cv;
            helper.uploadHelper(component, event,actFile);
            component.set("v.ShowMainForm1", false);
            component.set("v.ShowSuccessMesg1", true);
        } else {
            alert('Please Select a Valid File');
        }
        
        
        if (component.find("fileId2").get("v.files").length > 0) {
            var ps = component.find("fileId2").get("v.files");
            console.log('inside passport copy');
            console.log ('ps ='+ ps);
            var actFile = ps;
            helper.uploadHelper(component, event,actFile);
            component.set("v.ShowMainForm2", false);
            component.set("v.ShowSuccessMesg2", true);
        } else {
            alert('Please Select a Valid File');
        }
        
        
        
        if(component.find("fileId3").get("v.files") != null){
            
        if (component.find("fileId3").get("v.files").length > 0) {
            var ps = component.find("fileId3").get("v.files");
            console.log('inside emirates id');
            console.log ('ps ='+ ps);
            var actFile = ps;
            helper.uploadHelper(component, event,actFile);
           
        } else {
            alert('Please Select a Valid File');
        }
            
        }
        
       
        
        
        if (component.find("fileId4").get("v.files").length > 0) {
            var passPhoto = component.find("fileId4").get("v.files");
            console.log('inside epassPhoto');
            console.log (' passPhoto ='+ passPhoto);
            var actFile = passPhoto;
            helper.uploadHelper(component, event,actFile);
            component.set("v.ShowMainForm4", false);
            component.set("v.ShowSuccessMesg4", true);
        } else {
            alert('Please Select a Valid File');
        }
        
        
       
        
        if (component.find("fileId5").get("v.files").length > 0) {
            var uploadvideo = component.find("fileId5").get("v.files");
            console.log('inside uploadvideo');
            console.log (' uploadvideo ='+ uploadvideo);
            var actFile = uploadvideo;
            helper.uploadHelper(component, event,actFile);
            component.set("v.ShowMainForm5", false);
            component.set("v.ShowSuccessMesg5", true);
        } else {
            alert('Please Select a Valid File');
        }
       
       
        if (component.find("fileId6").get("v.files").length > 0) {
            var uploadguradian = component.find("fileId6").get("v.files");
            console.log('inside uploadguradian');
            console.log (' uploadguradian ='+ uploadguradian);
            var actFile = uploadguradian;
            helper.uploadHelper(component, event,actFile);
            component.set("v.ShowMainForm6", false);
            component.set("v.ShowSuccessMesg6", true);
        } else {
            alert('Please Select a Valid File');
        }
        
    },
     HandleAttachmentsValidation : function(component, event, helper) {
        
        
        var cvv= component.find("fileId1").get("v.files");
        console.log('cvv dada= '+cvv);
        
        if (component.find("fileId1").get("v.files") == null) {
            console.log('cdcscscsc '+cvv);
            //component.set("v.fileName1", 'Please Upload Your Latest CV');
            component.set('v.uploadcvError',true);
            
        }else if (component.find("fileId1").get("v.files")[0].size > 2000000){
            console.log('inside elsesss');
            component.set("v.fileName1", 'File size cannot be more than 2MB.');
            
        }else {
            console.log('fileId1 else');
            component.set('v.uploadcvError',false);
        }
        
        
        if (component.find("fileId2").get("v.files") == null) {
            console.log('cdcs1111 '+cvv);
            //component.set("v.fileName2", 'Please Upload Your Passport Copy');
            component.set('v.uploadpassportError',true);            
        }else if (component.find("fileId2").get("v.files")[0].size > 2000000){
            console.log('inside elsesss');
            component.set("v.fileName2", 'File size cannot be more than 2MB.');
            
        }else{
            console.log('fileId2 else');
            component.set('v.uploadpassportError',false);
        }
         
         if(component.find("fileId3").get("v.files") != null){
             
             if (component.find("fileId3").get("v.files")[0].size > 2000000){
                 console.log('inside elsesss');
                 component.set("v.fileName3", 'File size cannot be more than 2MB.');
                 
             }
         else{
             console.log('fileId3 else');
             //component.set('v.uploadpassportError',false);
         }
         }
         
         
        if (component.find("fileId4").get("v.files") == null) {
            console.log('cdcsc333'+cvv);
            //component.set("v.fileName4", 'Please Upload Your Latest Photo Copy');
            component.set('v.uploadpasspError',true);
        }else if (component.find("fileId4").get("v.files")[0].size > 2000000){
            console.log('inside elsesss');
            component.set("v.fileName4", 'File size cannot be more than 2MB.');
            
        }
            else{
                console.log('fileId4 else');
                component.set('v.uploadpasspError',false);
            }
         
         if (component.find("fileId5").get("v.files") == null) {
             console.log('uload video'+cvv);
             
             component.set('v.uploadvideoError',true);
             
         }else if (component.find("fileId5").get("v.files")[0].size > 3000000){
             console.log('inside elsesss');
             component.set("v.fileName5", 'File size cannot be more than 3MB.');
         }
             else{
                 console.log('fileId5 else');
                 component.set('v.uploadvideoError',false);
             }        
         
         
         
         if (component.find("fileId6").get("v.files") == null) {
             console.log('Gurdian form'+cvv);
             
            component.set('v.uploadguardError',true);
             
        }else if (component.find("fileId6").get("v.files")[0].size > 2000000){
            console.log('inside elsesss');
            component.set("v.fileName6", 'File size cannot be more than 2MB.');
        }
        else{
            console.log('fileId6 else');
            component.set('v.uploadguardError',false);
        }
        
         console.log('before attach validation');
         if(component.find("fileId1").get("v.files") == null || component.find("fileId2").get("v.files") == null ||  
            
            component.find("fileId4").get("v.files") == null || component.find("fileId5").get("v.files") == null || 
            component.find("fileId6").get("v.files") == null ||
            component.find("fileId1").get("v.files")[0].size > 2000000 ||
            component.find("fileId2").get("v.files")[0].size > 2000000 ||
            (component.find("fileId3").get("v.files") != null && component.find("fileId3").get("v.files")[0].size > 2000000) ||
            component.find("fileId4").get("v.files")[0].size > 2000000 ||
            component.find("fileId5").get("v.files")[0].size > 3000000 ||
            component.find("fileId6").get("v.files")[0].size > 2000000){
             
             console.log('inside attach validation');
             return false;
         }else{
             console.log('outside attach validation');
             return true;
         }
        
        if(component.find("fileId1").get("v.files") != null && component.find("fileId2").get("v.files") != null  &&
           component.find("fileId4").get("v.files") != null &&
           component.find("fileId5").get("v.files") != null  &&component.find("fileId6").get("v.files") != null){
            
            console.log('inside NOT EMPTY Values');
            component.set('v.ShowSuccessMesg', true)
        }else{
            console.log('outside aNOT EMPTY Values');
            component.set('v.ShowMainForm', false);
        } 
        
    }
})