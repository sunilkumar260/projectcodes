({
    doInit: function(component, event, helper) {
        var typeInput = component.get("v.inputType");
        var displayOptions = [];
        if (typeInput == 'Radio') {
            displayOptions = component.get("v.inputOptions");
            var radioList = [];
            for (var key in displayOptions) {
                console.log('key >>> ' + displayOptions[key]);
                radioList.push({
                    label: displayOptions[key],
                    value: displayOptions[key]
                });
            }
            component.set("v.iterateOptions", radioList);
        }
    },

    wordsCount: function(component, event, helper) {
        var dataWrapper = component.get('v.dataWrapper');
        var qValue = event.getSource().get("v.value");
        var qNumber = event.getSource().get("v.name");
        console.log({
            qNumber,
            qValue
        });
        for (var key1 in dataWrapper) {
            if (dataWrapper[key1].qNo == qNumber) {
                var wordLen = dataWrapper[key1].response.dependentWrps.depWordLimit;
                var len = qValue.split(/[\s]+/);
                var remainingwords = wordLen - len.length;
                if (qValue != '' && dataWrapper[key1].response.dependentWrps.showDepValue == true) {
                    if (len != '' && len.length <= wordLen && len.length > 0) {
                        if (len[len.length - 1] == '')
                            dataWrapper[key1].response.dependentWrps.depWordCount = remainingwords + 1 + ' words Left';
                        if (len[len.length - 1] != '')
                            dataWrapper[key1].response.dependentWrps.depWordCount = remainingwords + ' words Left';
                    }

                    if (len.length > wordLen) {
                        var wordQn = qValue;
                        var val = wordQn.split(" ").slice(0, wordLen).join(" ").trim(val);
                        val = val.concat(" ")
                        event.preventDefault();
                        event.getSource().set("v.value", val);
                        dataWrapper[key1].response.dependentWrps.depWordCount = '0 words Left';
                    }
                }
            }
        }
        component.set("v.dataWrapper", dataWrapper);
    },

    handleRadioChange: function(component, event, helper) {
        var dataWrapper = component.get('v.dataWrapper');
        var key = component.get('v.quesNo');
        var selectedValue = component.find('select').get('v.value');
        var selectedRadioOption = event.getSource().get("v.value");
        console.log({
            key,
            selectedValue,
            selectedRadioOption,
            dataWrapper
        });

        for (var key1 in dataWrapper) {
            if (key == '0.4') {
                if (selectedValue != 'Other') {
                    if (dataWrapper[key1].qNo == '0.4') {
                        dataWrapper[key1].response.dependentWrps.showDepValue = false;
                        dataWrapper[key1].response.dependentWrps.dependentValue = '';
                    }
                } else if (selectedValue == 'Other') {
                    if (dataWrapper[key1].qNo == '0.4') {
                        dataWrapper[key1].response.dependentWrps.showDepValue = true;
                    }
                }
            }
            if (key == '1.1') {
                if (selectedValue != 'Other') {
                    if (dataWrapper[key1].qNo == '1.1') {
                        dataWrapper[key1].response.dependentWrps.showDepValue = false;
                        dataWrapper[key1].response.dependentWrps.dependentValue = '';
                    }
                } else if (selectedValue == 'Other') {
                    if (dataWrapper[key1].qNo == '1.1') {
                        dataWrapper[key1].response.dependentWrps.showDepValue = true;
                    }
                }
            }

            if (key == '0.4') {
                if (selectedValue == 'Non-Profit Organisation' || selectedValue == 'Other') {
                    if (dataWrapper[key1].qNo == '0.10') {
                        dataWrapper[key1].showQsn = true;
                        dataWrapper[key1].response.showHideTableWrp.otherOrNPOtable = true;
                        dataWrapper[key1].response.showHideTableWrp.sMEtable = false;
                        dataWrapper[key1].response.financialInfoTableWrps[1] = [];
                        for (var i = 0; i < 3; i++) {
                            dataWrapper[key1].response.financialInfoTableWrps[1].push({
                                year: '',
                                totalRevenue: '',
                                grossProfitMargin: '',
                                financingRaised: '',
                                revenueGrowth: ''
                            });
                        }
                        console.log('NPO Other');
                    }
                } else if (selectedValue == 'Small and Medium Enterprise') {
                    if (dataWrapper[key1].qNo == '0.10') {
                        dataWrapper[key1].showQsn = true;
                        dataWrapper[key1].response.showHideTableWrp.sMEtable = true;
                        dataWrapper[key1].response.showHideTableWrp.otherOrNPOtable = false;
                        dataWrapper[key1].response.financialInfoTableWrps[0] = [];
                        for (var i = 0; i < 3; i++) {
                            dataWrapper[key1].response.financialInfoTableWrps[0].push({
                                year: '',
                                totalRevenue: '',
                                majorSourceRevenue: '',
                                revenueGrowth: '',
                                outgoings: ''
                            });
                        }
                        console.log('SME');
                    }
                }
            } else if (key == '0.9') {
                if (selectedValue == 'Yes') {
                    if (dataWrapper[key1].qNo == '0.9.1') {
                        dataWrapper[key1].showQsn = true;
                    }
                } else {
                    if (dataWrapper[key1].qNo == '0.9.1') {
                        dataWrapper[key1].showQsn = false;
                        dataWrapper[key1].response.respValueWrps.value = '';
                    }
                }
            } else if (key == '1.5') {
                if (selectedValue == 'Yes' || selectedValue == 'No, but I intend to') {
                    if (dataWrapper[key1].qNo == '1.5.1') {
                        dataWrapper[key1].showQsn = true;
                    }
                } else {
                    if (dataWrapper[key1].qNo == '1.5.1') {
                        dataWrapper[key1].showQsn = false;
                        dataWrapper[key1].response.respValueWrps.value = '';
                    }
                }
            } else if (key == '2.3') {
                if (selectedValue == 'Yes') {
                    if (dataWrapper[key1].qNo == '2.3.1') {
                        dataWrapper[key1].showQsn = true;
                    }
                    if (dataWrapper[key1].qNo == '2.3.2') {
                        dataWrapper[key1].showQsn = true;
                    }
                    if (dataWrapper[key1].qNo == '2.3.2.1') {
                        dataWrapper[key1].showQsn = true;
                    }
                } else {
                    if (dataWrapper[key1].qNo == '2.3.1') {
                        dataWrapper[key1].showQsn = false;
                        dataWrapper[key1].response.respValueWrps.value = '';
                    }
                    if (dataWrapper[key1].qNo == '2.3.2') {
                        dataWrapper[key1].showQsn = false;
                        dataWrapper[key1].response.respValueWrps.value = '';
                    }
                    if (dataWrapper[key1].qNo == '2.3.2.1') {
                        dataWrapper[key1].showQsn = false;
                        dataWrapper[key1].response.unitCostTableWrps = [];
                        dataWrapper[key1].response.unitCostTableWrps.push({
                            placeHolder: '% value',
                            reductionPercentage: 'How much in percentage terms?',
                            peopleBenifited: ''
                        });
                        dataWrapper[key1].response.unitCostTableWrps.push({
                            placeHolder: 'Number',
                            reductionPercentage: 'How many people have benefited from this cost reduction?',
                            peopleBenifited: ''
                        });
                    }
                }
            } else if (key == '2.3.2') {
                if (selectedValue == 'Yes') {
                    if (dataWrapper[key1].qNo == '2.3.2.1') {
                        dataWrapper[key1].showQsn = true;
                    }
                } else {
                    if (dataWrapper[key1].qNo == '2.3.2.1') {
                        dataWrapper[key1].showQsn = false;
                        dataWrapper[key1].response.unitCostTableWrps = [];
                        dataWrapper[key1].response.unitCostTableWrps.push({
                            placeHolder: '% value',
                            reductionPercentage: 'How much in percentage terms?',
                            peopleBenifited: ''
                        });
                        dataWrapper[key1].response.unitCostTableWrps.push({
                            placeHolder: 'Number',
                            reductionPercentage: 'How many people have benefited from this cost reduction?',
                            peopleBenifited: ''
                        });
                    }
                }
            } else if (key == '2.4') {
                if (selectedValue == 'Yes') {
                    if (dataWrapper[key1].qNo == '2.4.1') {
                        dataWrapper[key1].showQsn = true;
                    }
                    if (dataWrapper[key1].qNo == '2.4.2') {
                        dataWrapper[key1].showQsn = true;
                    }
                    if (dataWrapper[key1].qNo == '2.4.3') {
                        dataWrapper[key1].showQsn = true;
                    }
                } else {
                    if (dataWrapper[key1].qNo == '2.4.1') {
                        dataWrapper[key1].showQsn = false;
                        for (var a in dataWrapper[key1].response.multiCheckboxWrps) {
                            dataWrapper[key1].response.multiCheckboxWrps[a].isChecked = false;
                            dataWrapper[key1].response.dependentWrps.showDepValue = false;
                            dataWrapper[key1].response.dependentWrps.dependentValue = '';
                        }
                    }
                    if (dataWrapper[key1].qNo == '2.4.2') {
                        dataWrapper[key1].showQsn = false;
                        dataWrapper[key1].response.respValueWrps.value = '';
                    }
                    if (dataWrapper[key1].qNo == '2.4.3') {
                        dataWrapper[key1].showQsn = false;
                        dataWrapper[key1].response.respValueWrps.value = '';
                    }
                }
            } else if (key == '2.5') {
                if (selectedValue == 'Yes') {
                    if (dataWrapper[key1].qNo == '2.5.1') {
                        dataWrapper[key1].showQsn = true;
                    }
                    if (dataWrapper[key1].qNo == '2.5.2') {
                        dataWrapper[key1].showQsn = true;
                    }
                } else {
                    if (dataWrapper[key1].qNo == '2.5.1') {
                        dataWrapper[key1].showQsn = false;
                        for (var a in dataWrapper[key1].response.multiCheckboxWrps) {
                            dataWrapper[key1].response.multiCheckboxWrps[a].isChecked = false;
                            dataWrapper[key1].response.dependentWrps.showDepValue = false;
                            dataWrapper[key1].response.dependentWrps.dependentValue = '';
                        }
                    }
                    if (dataWrapper[key1].qNo == '2.5.2') {
                        dataWrapper[key1].showQsn = false;
                        dataWrapper[key1].response.respValueWrps.value = '';
                    }
                }
            } else if (key == '5.1') {
                if (selectedValue == 'Yes') {
                    if (dataWrapper[key1].qNo == '5.1.1') {
                        dataWrapper[key1].showQsn = true;
                    }
                } else {
                    if (dataWrapper[key1].qNo == '5.1.1') {
                        dataWrapper[key1].showQsn = false;
                        for (var a in dataWrapper[key1].response.multiCheckboxWrps) {
                            dataWrapper[key1].response.multiCheckboxWrps[a].isChecked = false;
                        }
                    }
                }
            } else if (key == '5.5') {
                if (selectedValue == 'Yes') {
                    if (dataWrapper[key1].qNo == '5.5.1' || dataWrapper[key1].qNo == '5.5.2' || dataWrapper[key1].qNo == '5.5.3' ||
                        dataWrapper[key1].qNo == '5.5.4' || dataWrapper[key1].qNo == '5.5.5' || dataWrapper[key1].qNo == '5.5.6' ||
                        dataWrapper[key1].qNo == '5.5.7') {
                        dataWrapper[key1].showQsn = true;
                    }
                } else {
                    if (dataWrapper[key1].qNo == '5.5.1' || dataWrapper[key1].qNo == '5.5.2' || dataWrapper[key1].qNo == '5.5.3' ||
                        dataWrapper[key1].qNo == '5.5.4' || dataWrapper[key1].qNo == '5.5.5' || dataWrapper[key1].qNo == '5.5.6' ||
                        dataWrapper[key1].qNo == '5.5.7') {
                        dataWrapper[key1].showQsn = false;
                        dataWrapper[key1].response.respValueWrps.value = '';
                    }
                }
            }
        }
        component.set("v.dataWrapper", dataWrapper);
    },

    handleMultiCheckboxChange: function(component, event, helper) {
        var selectedValue = event.getSource().get("v.value");
        var selectedlabel = event.getSource().get("v.label");
        var wrapdata = component.get('v.responseList.multiCheckboxWrps');
        var dependentWrap = component.get('v.responseList.dependentWrps');
        var key = component.get('v.quesNo');
        var dataWrapper = component.get('v.dataWrapper');
        console.log({
            key,
            selectedValue,
            selectedlabel,
            dataWrapper,
            wrapdata
        });

        for (var f in wrapdata) {
            if (wrapdata[f].name == selectedValue) {
                if (event.getSource().get('v.checked') == true) {
                    if (key == '0.5' || key == '0.6' || key == '2.4.1' || key == '2.5.1') {
                        if (selectedValue == 'Other') {
                            //wrapdata[f].showResValue = true; 
                            dependentWrap.showDepValue = true;
                        } else if (selectedValue != 'Other') {
                            for (var a in wrapdata) {
                                if (wrapdata[a].name == 'Other' && wrapdata[a].isChecked == true) {
                                    dependentWrap.showDepValue = true;
                                } else if (wrapdata[a].name == 'Other' && wrapdata[a].isChecked == false) {
                                    dependentWrap.showDepValue = false;
                                    dependentWrap.dependentValue = '';
                                }
                            }
                        }
                    } else if (key == '2.6') {
                        if (selectedValue == 'Other') {
                            dependentWrap.showDepValue = true;
                        }

                        if (selectedValue == 'None') {
                            dependentWrap.showDepValue = false;
                            dependentWrap.dependentValue = '';
                            for (var a in wrapdata) {
                                if (wrapdata[a].name != 'None') {
                                    wrapdata[a].isChecked = false;
                                }
                            }
                            for (var b in dataWrapper) {
                                if (dataWrapper[b].qNo == '2.6.1') {
                                    dataWrapper[b].showQsn = false;
                                    dataWrapper[b].response.respValueWrps.value = '';
                                }
                            }
                        }

                        if (selectedValue == 'Economic' || selectedValue == 'Environmental' || selectedValue == 'Political' ||
                            selectedValue == 'Societal' || selectedValue == 'Technological' || selectedValue == 'Other') {
                            for (var a in wrapdata) {
                                if (wrapdata[a].name == 'None' && wrapdata[a].isChecked == true) {
                                    wrapdata[a].isChecked = false;
                                }
                                if (wrapdata[a].name == 'Other' && wrapdata[a].isChecked == true) {
                                    dependentWrap.showDepValue = true;
                                } else if (wrapdata[a].name == 'Other' && wrapdata[a].isChecked == false) {
                                    dependentWrap.showDepValue = false;
                                    dependentWrap.dependentValue = '';
                                }
                            }
                            for (var b in dataWrapper) {
                                if (dataWrapper[b].qNo == '2.6.1') {
                                    dataWrapper[b].showQsn = true;
                                }
                            }
                        }
                    } else if (key == '2.9') {
                        if (selectedValue == 'None of these') {
                            for (var b in dataWrapper) {
                                if (dataWrapper[b].qNo == '2.9.1') {
                                    dataWrapper[b].showQsn = false;
                                    dataWrapper[b].response.respValueWrps.value = '';
                                }
                                if (dataWrapper[b].qNo == '2.9.2') {
                                    dataWrapper[b].showQsn = false;
                                    dataWrapper[b].response.impactTableWrps = [];
                                    dataWrapper[b].response.impactTableWrps.push({
                                        area: '',
                                        impactDescription: '',
                                        impactNumber: '',
                                        areaPlaceHolder: 'e.g. Water',
                                        impDescPlaceHolder: 'Water savings through efficiency measures',
                                        impNumPlaceHolder: '2,000,000 litres'
                                    });
                                    dataWrapper[b].response.impactTableWrps.push({
                                        area: '',
                                        impactDescription: '',
                                        impactNumber: '',
                                        areaPlaceHolder: 'e.g. Energy',
                                        impDescPlaceHolder: 'Providing people access to affordable energy',
                                        impNumPlaceHolder: '50000'
                                    });
                                    dataWrapper[b].response.impactTableWrps.push({
                                        area: '',
                                        impactDescription: '',
                                        impactNumber: '',
                                        areaPlaceHolder: 'e.g. Health',
                                        impDescPlaceHolder: 'Providing people access to essential healthcare',
                                        impNumPlaceHolder: '20000'
                                    });
                                }
                            }
                            for (var a in wrapdata) {
                                if (wrapdata[a].name != 'None of these' && wrapdata[a].isChecked == true) {
                                    wrapdata[a].isChecked = false;
                                }
                            }
                        } else if (selectedValue != 'None of these') {
                            for (var b in dataWrapper) {
                                if (dataWrapper[b].qNo == '2.9.1' || dataWrapper[b].qNo == '2.9.2') {
                                    dataWrapper[b].showQsn = true;
                                }
                            }
                            for (var a in wrapdata) {
                                if (wrapdata[a].name == 'None of these' && wrapdata[a].isChecked == true) {
                                    wrapdata[a].isChecked = false;
                                }
                            }
                        }
                    }
                } else { //Unchecked
                    if (key == '0.5' || key == '0.6' || key == '2.4.1' || key == '2.5.1' || key == '2.6') {
                        if (selectedValue == 'Other') {
                            dependentWrap.showDepValue = false;
                            dependentWrap.dependentValue = '';
                        }
                    }
                    if (key == '2.6') {
                        if (selectedValue == 'Economic' || selectedValue == 'Environmental' || selectedValue == 'Political' ||
                            selectedValue == 'Societal' || selectedValue == 'Technological' || selectedValue == 'Other') {
                            var ischecked = false;
                            for (var a in wrapdata) {
                                if (wrapdata[a].name != 'None' && wrapdata[a].isChecked == true) {
                                    ischecked = true;
                                    //console.log('Entered');
                                    break;
                                }
                            }
                            console.log(ischecked);
                            for (var b in dataWrapper) {
                                if (ischecked == true) {
                                    if (dataWrapper[b].qNo == '2.6.1') {
                                        dataWrapper[b].showQsn = true;
                                    }
                                } else {
                                    if (dataWrapper[b].qNo == '2.6.1') {
                                        dataWrapper[b].showQsn = false;
                                        dataWrapper[b].response.respValueWrps.value = '';
                                    }
                                }
                            }
                        }
                    } //
                    if (key == '2.9') {
                        if (selectedValue != 'None of these') {
                            var checkedCount = 0;
                            for (var a in wrapdata) {
                                if (wrapdata[a].name != 'None of these' && wrapdata[a].isChecked == true) {
                                    checkedCount += 1;
                                }
                            }
                            if (checkedCount < 1) {
                                for (var b in dataWrapper) {
                                    if (dataWrapper[b].qNo == '2.9.1') {
                                        dataWrapper[b].showQsn = false;
                                        dataWrapper[b].response.respValueWrps.value = '';
                                    }
                                    if (dataWrapper[b].qNo == '2.9.2') {
                                        dataWrapper[b].showQsn = false;
                                        dataWrapper[b].response.impactTableWrps = [];
                                        dataWrapper[b].response.impactTableWrps.push({
                                            area: '',
                                            impactDescription: '',
                                            impactNumber: '',
                                            areaPlaceHolder: 'e.g. Water',
                                            impDescPlaceHolder: 'Water savings through efficiency measures',
                                            impNumPlaceHolder: '2,000,000 litres'
                                        });
                                        dataWrapper[b].response.impactTableWrps.push({
                                            area: '',
                                            impactDescription: '',
                                            impactNumber: '',
                                            areaPlaceHolder: 'e.g. Energy',
                                            impDescPlaceHolder: 'Providing people access to affordable energy',
                                            impNumPlaceHolder: '50000'
                                        });
                                        dataWrapper[b].response.impactTableWrps.push({
                                            area: '',
                                            impactDescription: '',
                                            impactNumber: '',
                                            areaPlaceHolder: 'e.g. Health',
                                            impDescPlaceHolder: 'Providing people access to essential healthcare',
                                            impNumPlaceHolder: '20000'
                                        });
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        console.log(wrapdata);
        console.log(JSON.stringify(dependentWrap));
        component.set("v.dataWrapper", dataWrapper);
    },

})