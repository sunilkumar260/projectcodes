({
	
    handleSaveHelper: function(component, event, helper) {
     console.log('Entered In handleSaveHelper');
     var dataWrapper = component.get('v.FoodCatWrp');
     component.set("v.isSubmitError", false);
     component.set("v.sumbitErrorMsg", '');
     //console.log(JSON.stringify(component.get('v.FoodCatWrp')));
     var confirmId;
     var finalistId; 
     var agreeId;
     for(var key1 in dataWrapper){
            if(dataWrapper[key1].qNo == '1'){
                confirmId = dataWrapper[key1].response.multiCheckboxWrps[0].isChecked;
            } 
            if(dataWrapper[key1].qNo == '2'){
                finalistId = dataWrapper[key1].response.multiCheckboxWrps[0].isChecked;
            } 
            if(dataWrapper[key1].qNo == '3'){
                agreeId = dataWrapper[key1].response.multiCheckboxWrps[0].isChecked;
            } 
        }
        console.log('checkbox values');
        console.log({confirmId,finalistId,agreeId});
        if(confirmId != false && finalistId != false && agreeId != false){
            console.log('true');
            var status = 'Submitted';
            var successMsg = true;
            var isSaveDraft = false;         
            this.saveHelper(component, event, helper, status, successMsg, isSaveDraft); 
        }else{
            var ToastMsg = 'Please make sure you have agreed to all the Terms and Conditions before submitting the application';
            component.set("v.isSubmitError", true);
            component.set("v.sumbitErrorMsg", ToastMsg);
                     window.setTimeout(
                        $A.getCallback(function() {
                            component.set("v.isSubmitError", false);
                            component.set("v.sumbitErrorMsg", '');
                        }), 5000
                    );
         }
    },
    
    saveHelper : function(component, event, helper, status, successMsg, isSaveDraft ){
        console.log('Entered In saveHelper :');
        var actSaveData = component.get("c.saveWrapper");
        var registrationId = component.get("v.userRegistrationId");
        console.log('registrationId2 >'+registrationId);
        actSaveData.setParams({
            "listToSavemainWrp":JSON.stringify(component.get('v.FoodCatWrp')),
            "registrationId" : registrationId,  //'a1k5E000000jdPY'
            "respId" : component.get("v.respIdZSP"),
            "respStatus": status
        });
        actSaveData.setCallback(this, function(response) {
            var state = response.getState();
            console.log('state--> '+state);
            if(component.isValid() && state === "SUCCESS") {
                var result = response.getReturnValue();
                console.log('actSaveData result');
                console.log(JSON.stringify(result));
                component.set("v.respIdZSP", result);
                component.set("v.successMsg", successMsg);
                console.log(JSON.stringify(component.get('v.FoodCatWrp')));
               if(isSaveDraft == true){
                    component.set("v.showSaveDraftMsg", true);  
                }else{
                    component.set("v.showSaveDraftMsg", false); 
                }
              }            
               else if(component.isValid() && state === "ERROR"){
                console.log("Exception caught successfully");
                console.log("Error object", response);
                console.log("Error Message", response.getError()[0]);
                console.log("Error Message", response.getError()[0].message);
                console.log("Error Message", response.getState());
                console.log("Error object", JSON.stringify(response));
                component.set("v.showSaveDraftMsg", false); 
            }
        });
        $A.enqueueAction(actSaveData); 
    },
                     
    loadAttachments : function(component, event, helper,attToDelete){
        //actAttachments
        console.log('attToDelete ID'+attToDelete); 
        var actAttachments = component.get("c.getAttachments");
        actAttachments.setParams({
            "aplId": component.get("v.respIdZSP"),
            "attId": attToDelete
        });
       actAttachments.setCallback(this, function(response) {
            var state = response.getState();
            console.log('actAttachments state--> '+state);
            if(component.isValid() && state === "SUCCESS") {
                //$A.get('e.force:refreshView').fire(); //JSON.stringify(result)
                var result = response.getReturnValue();
                console.log('result>>> '+JSON.stringify(result));
                console.log('result attList_TL Size>>> '+JSON.stringify(result.attList_TL.length));
               
                component.set("v.aplAttachMap", result);
                //component.set("v.SizeAplAttachments", result.length);
            }
            else if(component.isValid() && state === "ERROR"){
                console.log("Exception caught successfully");
                console.log("Error object", response);
                console.log("Error Message", response.getError()[0]);
                console.log("Error Message", response.getError()[0].message);
                console.log("Error Message", response.getState());
                console.log("Error object", JSON.stringify(response));
            }
        });
        $A.enqueueAction(actAttachments); 
    },
    
    
})