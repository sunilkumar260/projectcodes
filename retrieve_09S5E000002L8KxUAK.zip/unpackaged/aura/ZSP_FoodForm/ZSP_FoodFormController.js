({
    init: function(component, event, helper) {
        component.set("v.spinner", true);
        component.set("v.successMsg", false);
        component.set("v.showContinueButton", false);
        component.set("v.showSaveDraftMsg", false);
        component.set("v.showTLError", false); //New
        var urlString = window.location.href;
        var baseURL = urlString.substring(0, urlString.indexOf("/apex"));
        component.set("v.cbaseURL", baseURL);
        var recordId = component.get("v.recordId");
        console.log({
            recordId,baseURL
        });

        if (recordId != null) {
            component.set("v.respIdZSP", recordId);
            component.set("v.readOnly", true);
            component.set("v.isAccess", true);
        }

        var isAccess = component.get("v.isAccess");
        var isNew = component.get("v.isNew");
        var readOnly = component.get("v.readOnly");
        var isEditOrDraft = component.get("v.isEditOrDraft");
        var userRegistrationId = component.get("v.userRegistrationId");
        var respIdZSP = component.get("v.respIdZSP");
        console.log({
            isAccess,
            isNew,
            readOnly,
            isEditOrDraft,
            userRegistrationId,
            respIdZSP
        });

        if (component.get("v.isAccess") == true) {
            if (component.get("v.isEditOrDraft") == true) {
                component.set("v.step", 1);
                component.set('v.selectedSection', 'General_Information');
            } else if (component.get("v.readOnly") == true) {
                component.set("v.step", 1);
                component.set('v.selectedSection', 'General_Information');
            }

            //Getting Food Wrapper
            var actFood = component.get("c.ZSP_FoodCategoryList");
            actFood.setParams({
                "regId": component.get("v.userRegistrationId"),
                "aplId": component.get("v.respIdZSP")
            });
            actFood.setCallback(this, function(response) {
                var state = response.getState();
                console.log('state--> ' + state);
                if (component.isValid() && state === "SUCCESS") {
                    var result = response.getReturnValue();
                    console.log('result>>> ' + JSON.stringify(result));
                    if (result == null && isNew == true) {
                        console.log(document.URL.split('/apex'));
                        window.open(document.URL.split('/apex')[0], '_self');
                    } else if (result != null && isNew == true) {
                        component.set("v.step", 0);
                    }
                    if (result != null)
                        component.set("v.FoodCatWrp", result);
                    component.set("v.spinner", false);
                } else if (component.isValid() && state === "ERROR") {
                    console.log("Exception caught successfully");
                    console.log("Error object", response);
                    console.log("Error Message", response.getError()[0]);
                    console.log("Error Message", response.getError()[0].message);
                    console.log("Error Message", response.getState());
                    console.log("Error object", JSON.stringify(response));
                }
            });
            $A.enqueueAction(actFood);
            //loading Attachments
            helper.loadAttachments(component, event, helper, null);
        }
    },

    wordsCount: function(component, event, helper) {
        var dataWrapper = component.get('v.FoodCatWrp');
        var qValue = event.getSource().get("v.value");
        var qNumber = event.getSource().get("v.name");
        console.log({
            qNumber,
            qValue
        });
        for (var key1 in dataWrapper) {
            if (dataWrapper[key1].qNo == qNumber) {
                var wordLen = dataWrapper[key1].response.respValueWrps.wordLimit;
                var len = qValue.split(/[\s]+/);
                var remainingwords = wordLen - len.length;
                if (qValue != '' && dataWrapper[key1].showQsn == true) {
            
                    if (len != '' && len.length <= wordLen && len.length > 0) {
                        if (len[len.length - 1] == '')
                            dataWrapper[key1].response.respValueWrps.wordCount = remainingwords + 1 + ' words Left';
                        if (len[len.length - 1] != '')
                            dataWrapper[key1].response.respValueWrps.wordCount = remainingwords + ' words Left';
                    }

                    if (len.length > wordLen) {
                        var wordQn = qValue;
                        var val = wordQn.split(" ").slice(0, wordLen).join(" ").trim(val);
                        console.log('len :' + len);
                        val = val.concat(" ")
                        event.preventDefault();
                        event.getSource().set("v.value", val);
                    
                        dataWrapper[key1].response.respValueWrps.wordCount = '0 words Left';
                    }
                }
            }
        }
        component.set("v.FoodCatWrp", dataWrapper);
        
    },

    handleSection: function(component, event, helper) {
        var selected = event.getParam('name');
        console.log(selected);
        if (selected === 'Instructions') {
            component.set('v.step', 0);
        } else if (selected === 'General_Information') {
            component.set('v.step', 1);
        } else if (selected === 'Innovation') {
            component.set('v.step', 2);
        } else if (selected === 'Impact') {
            component.set('v.step', 3);
        } else if (selected === 'Inspiration') {
            component.set('v.step', 4);
        } else if (selected === 'Other_Information') {
            component.set('v.step', 5);
        } else if (selected === 'Networking') {
            component.set('v.step', 6);
        } else if (selected === 'Submit') {
            component.set('v.step', 7);
        }
    },

    onCheck: function(component, event, helper) {
        var selectedValue = event.getSource().get("v.value");
        var selectedlabel = event.getSource().get("v.label");
        console.log({
            selectedValue,
            selectedlabel
        });
        if (event.getSource().get('v.checked') == true)
            component.set("v.showContinueButton", true);
        else
            component.set("v.showContinueButton", false);
    },

    handleBack: function(component, event, helper) {
        window.scrollTo(0, 0);
        if (component.get('v.step') == 7) {
            component.set("v.step", component.get('v.step') - 1);
            component.set('v.selectedSection', 'Networking');
        } else if (component.get('v.step') == 6) {
            component.set("v.step", component.get('v.step') - 1);
            component.set('v.selectedSection', 'Other_Information');
        } else if (component.get('v.step') == 5) {
            component.set("v.step", component.get('v.step') - 1);
            component.set('v.selectedSection', 'Inspiration');
        } else if (component.get('v.step') == 4) {
            component.set("v.step", component.get('v.step') - 1);
            component.set('v.selectedSection', 'Impact');
        } else if (component.get('v.step') == 3) {
            component.set("v.step", component.get('v.step') - 1);
            component.set('v.selectedSection', 'Innovation');
        } else if (component.get('v.step') == 2) {
            component.set("v.step", component.get('v.step') - 1);
            component.set('v.selectedSection', 'General_Information');
        }
    },

    handleContinue: function(component, event, helper) {
        window.scrollTo(0, 0);
        if (component.get('v.step') == 0) {
            component.set("v.step", component.get('v.step') + 1);
            component.set('v.selectedSection', 'General_Information');
        } else if (component.get('v.step') == 1) {
            component.set("v.step", component.get('v.step') + 1);
            component.set('v.selectedSection', 'Innovation');
        } else if (component.get('v.step') == 2) {
            component.set("v.step", component.get('v.step') + 1);
            component.set('v.selectedSection', 'Impact');
        } else if (component.get('v.step') == 3) {
            component.set("v.step", component.get('v.step') + 1);
            component.set('v.selectedSection', 'Inspiration');
        } else if (component.get('v.step') == 4) {
            component.set("v.step", component.get('v.step') + 1);
            component.set('v.selectedSection', 'Other_Information');
        } else if (component.get('v.step') == 5) {
            component.set("v.step", component.get('v.step') + 1);
            component.set('v.selectedSection', 'Networking');
        } else if (component.get('v.step') == 6) {
            component.set("v.step", component.get('v.step') + 1);
            component.set('v.selectedSection', 'Submit');
        }
    },

    handleSaveContinue: function(component, event, helper) {
        window.scrollTo(0, 0);
        if (component.get('v.step') == 0) {
            component.set("v.step", component.get('v.step') + 1);
            component.set('v.selectedSection', 'General_Information');
        } else if (component.get('v.step') == 1) {
            component.set("v.step", component.get('v.step') + 1);
            component.set('v.selectedSection', 'Innovation');
        } else if (component.get('v.step') == 2) {
            component.set("v.step", component.get('v.step') + 1);
            component.set('v.selectedSection', 'Impact');
        } else if (component.get('v.step') == 3) {
            component.set("v.step", component.get('v.step') + 1);
            component.set('v.selectedSection', 'Inspiration');
        } else if (component.get('v.step') == 4) {
            component.set("v.step", component.get('v.step') + 1);
            component.set('v.selectedSection', 'Other_Information');
        } else if (component.get('v.step') == 5) {
            component.set("v.step", component.get('v.step') + 1);
            component.set('v.selectedSection', 'Networking');
        } else if (component.get('v.step') == 6) {
            component.set("v.step", component.get('v.step') + 1);
            component.set('v.selectedSection', 'Submit');
        }

        var status = 'Draft';
        var successMsg = false;
        var isSaveDraft = false;
        helper.saveHelper(component, event, helper, status, successMsg, isSaveDraft);
    },

    handleSaveDraft: function(component, event, helper) {
        var status = 'Draft';
        var successMsg = false;
        var isSaveDraft = true;
        helper.saveHelper(component, event, helper, status, successMsg, isSaveDraft);
    },

    handleSave: function(component, event, helper) {
        component.set("v.isSectionsError", false)
        var dataWrapper = component.get('v.FoodCatWrp');
        var ErrorMsg = '';
        var isGeneralComplete = true;
        var isInnovationComplete = true;
        var isImpactComplete = true;
        var isInspirationComplete = true;
        var isOtherInfoComplete = true;
        var isNetworkingComplete = true;

        //General Section
        for (var key1 in dataWrapper) {
            if (dataWrapper[key1].qNo == '0.1' || dataWrapper[key1].qNo == '0.2' || dataWrapper[key1].qNo == '0.3' || dataWrapper[key1].qNo == '0.7' || dataWrapper[key1].qNo == '0.8' || dataWrapper[key1].qNo == '0.9' || dataWrapper[key1].qNo == '0.9.1') {
                if (dataWrapper[key1].response.respValueWrps.value == '' && dataWrapper[key1].showQsn == true) {
                    console.log('0.1 IN');
                    dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                    isGeneralComplete = false;
                    console.log('0.1 IN' + dataWrapper[key1].response.respValueWrps.errorMsg);
                } else {
                    dataWrapper[key1].response.respValueWrps.errorMsg = '';
                }
            } else if (dataWrapper[key1].qNo == '0.4') {
                if (dataWrapper[key1].response.respValueWrps.value == '' && dataWrapper[key1].showQsn == true) {
                    dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                    isGeneralComplete = false;
                } else {
                    dataWrapper[key1].response.respValueWrps.errorMsg = '';
                }
                if (dataWrapper[key1].response.respValueWrps.value == 'Other' && dataWrapper[key1].showQsn == true &&
                    dataWrapper[key1].response.dependentWrps.dependentValue == '' && dataWrapper[key1].response.dependentWrps.showDepValue == true) {
                    dataWrapper[key1].response.dependentWrps.depErrorMsg = $A.get("$Label.c.ZSP_AnswerIfOtherSelected");
                    isGeneralComplete = false;
                } else if (dataWrapper[key1].response.respValueWrps.value == 'Other' && dataWrapper[key1].showQsn == true &&
                    dataWrapper[key1].response.dependentWrps.dependentValue != '' && dataWrapper[key1].response.dependentWrps.showDepValue == true) {
                    dataWrapper[key1].response.dependentWrps.depErrorMsg = '';
                } else if (dataWrapper[key1].response.respValueWrps.value != 'Other' && dataWrapper[key1].showQsn == true &&
                    dataWrapper[key1].response.dependentWrps.dependentValue == '' && dataWrapper[key1].response.dependentWrps.showDepValue == false) {
                    dataWrapper[key1].response.dependentWrps.depErrorMsg = '';
                }
            } else if (dataWrapper[key1].qNo == '0.5' && dataWrapper[key1].showQsn == true) {
                console.log(dataWrapper[key1].response);
                var unCheckedCount = 0;
                for (var key12 in dataWrapper[key1].response.multiCheckboxWrps) {
                    if (dataWrapper[key1].response.multiCheckboxWrps[key12].isChecked == false) {
                        unCheckedCount += 1;
                    }
                    if (dataWrapper[key1].response.multiCheckboxWrps[key12].isChecked == true && dataWrapper[key1].response.multiCheckboxWrps[key12].name == 'Other' &&
                        dataWrapper[key1].response.dependentWrps.showDepValue == true && dataWrapper[key1].response.dependentWrps.dependentValue == '') {
                        dataWrapper[key1].response.dependentWrps.depErrorMsg = $A.get("$Label.c.ZSP_AnswerIfOtherSelected");
                        isGeneralComplete = false;
                    } else if (dataWrapper[key1].response.multiCheckboxWrps[key12].isChecked == true && dataWrapper[key1].response.multiCheckboxWrps[key12].name == 'Other' &&
                        dataWrapper[key1].response.dependentWrps.showDepValue == true && dataWrapper[key1].response.dependentWrps.dependentValue != '') {
                        dataWrapper[key1].response.dependentWrps.depErrorMsg = '';
                    } else if (dataWrapper[key1].response.multiCheckboxWrps[key12].isChecked == false && dataWrapper[key1].response.multiCheckboxWrps[key12].name == 'Other' &&
                        dataWrapper[key1].response.dependentWrps.showDepValue == false && dataWrapper[key1].response.dependentWrps.dependentValue == '') {
                        dataWrapper[key1].response.dependentWrps.depErrorMsg = '';
                    }
                }
                if (unCheckedCount == 5) {
                    dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                    isGeneralComplete = false;
                } else if (unCheckedCount < 5) {
                    dataWrapper[key1].response.respValueWrps.errorMsg = '';
                }
            } else if (dataWrapper[key1].qNo == '0.6' && dataWrapper[key1].showQsn == true) {
                console.log(dataWrapper[key1].response);
                var unCheckedCount = 0;
                for (var key12 in dataWrapper[key1].response.multiCheckboxWrps) {
                    if (dataWrapper[key1].response.multiCheckboxWrps[key12].isChecked == false) {
                        unCheckedCount += 1;
                    }
                    if (dataWrapper[key1].response.multiCheckboxWrps[key12].isChecked == true && dataWrapper[key1].response.multiCheckboxWrps[key12].name == 'Other' &&
                        dataWrapper[key1].response.dependentWrps.showDepValue == true && dataWrapper[key1].response.dependentWrps.dependentValue == '') {
                        dataWrapper[key1].response.dependentWrps.depErrorMsg = $A.get("$Label.c.ZSP_AnswerIfOtherSelected");
                        isGeneralComplete = false;
                    } else if (dataWrapper[key1].response.multiCheckboxWrps[key12].isChecked == true && dataWrapper[key1].response.multiCheckboxWrps[key12].name == 'Other' &&
                        dataWrapper[key1].response.dependentWrps.showDepValue == true && dataWrapper[key1].response.dependentWrps.dependentValue != '') {
                        dataWrapper[key1].response.dependentWrps.depErrorMsg = '';
                    } else if (dataWrapper[key1].response.multiCheckboxWrps[key12].isChecked == false && dataWrapper[key1].response.multiCheckboxWrps[key12].name == 'Other' &&
                        dataWrapper[key1].response.dependentWrps.showDepValue == false && dataWrapper[key1].response.dependentWrps.dependentValue == '') {
                        dataWrapper[key1].response.dependentWrps.depErrorMsg = '';
                    }
                }
                if (unCheckedCount == 8) {
                    dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                    isGeneralComplete = false;
                } else if (unCheckedCount < 8) {
                    dataWrapper[key1].response.respValueWrps.errorMsg = '';
                }
            }
            if (dataWrapper[key1].qNo == '0.10' && dataWrapper[key1].showQsn == true) {
                if (dataWrapper[key1].response.showHideTableWrp.otherOrNPOtable == true) {
                    for (var key12 in dataWrapper[key1].response.financialInfoTableWrps[0]) {
                        if (dataWrapper[key1].response.financialInfoTableWrps[0][key12].year == '' || dataWrapper[key1].response.financialInfoTableWrps[0][key12].totalRevenue == '' ||
                            dataWrapper[key1].response.financialInfoTableWrps[0][key12].majorSourceRevenue == '' || dataWrapper[key1].response.financialInfoTableWrps[0][key12].revenueGrowth == '' ||
                            dataWrapper[key1].response.financialInfoTableWrps[0][key12].outgoings == '') {
                            dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                            isGeneralComplete = false;
                            break;
                        } else {
                            dataWrapper[key1].response.respValueWrps.errorMsg = '';
                        }
                    }
                } else if (dataWrapper[key1].response.showHideTableWrp.sMEtable == true) {
                    for (var key12 in dataWrapper[key1].response.financialInfoTableWrps[1]) {
                        if (dataWrapper[key1].response.financialInfoTableWrps[1][key12].year == '' || dataWrapper[key1].response.financialInfoTableWrps[1][key12].totalRevenue == '' ||
                            dataWrapper[key1].response.financialInfoTableWrps[1][key12].grossProfitMargin == '' || dataWrapper[key1].response.financialInfoTableWrps[1][key12].financingRaised == '' ||
                            dataWrapper[key1].response.financialInfoTableWrps[1][key12].revenueGrowth == '') {
                            dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                            isGeneralComplete = false;
                            break;
                        } else {
                            dataWrapper[key1].response.respValueWrps.errorMsg = '';
                        }
                    }
                }
            }
        }

        //Innovation Section
        for (var key1 in dataWrapper) {
            if (dataWrapper[key1].qNo == '1.1.1' || dataWrapper[key1].qNo == '1.2' || dataWrapper[key1].qNo == '1.3' ||
                dataWrapper[key1].qNo == '1.4' || dataWrapper[key1].qNo == '1.4.1' || dataWrapper[key1].qNo == '1.5' || dataWrapper[key1].qNo == '1.5.1') {
                if (dataWrapper[key1].response.respValueWrps.value == '' && dataWrapper[key1].showQsn == true) {
                    dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                    isInnovationComplete = false;
                } else {
                    dataWrapper[key1].response.respValueWrps.errorMsg = '';
                }
            } else if (dataWrapper[key1].qNo == '1.1') {
                if (dataWrapper[key1].response.respValueWrps.value == '' && dataWrapper[key1].showQsn == true) {
                    dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                    isInnovationComplete = false;
                } else {
                    dataWrapper[key1].response.respValueWrps.errorMsg = '';
                }
                if (dataWrapper[key1].response.respValueWrps.value == 'Other' && dataWrapper[key1].showQsn == true &&
                    dataWrapper[key1].response.dependentWrps.dependentValue == '' && dataWrapper[key1].response.dependentWrps.showDepValue == true) {
                    dataWrapper[key1].response.dependentWrps.depErrorMsg = $A.get("$Label.c.ZSP_AnswerIfOtherSelected");
                    isInnovationComplete = false;
                } else if (dataWrapper[key1].response.respValueWrps.value == 'Other' && dataWrapper[key1].showQsn == true &&
                    dataWrapper[key1].response.dependentWrps.dependentValue != '' && dataWrapper[key1].response.dependentWrps.showDepValue == true) {
                    dataWrapper[key1].response.dependentWrps.depErrorMsg = '';
                } else if (dataWrapper[key1].response.respValueWrps.value != 'Other' && dataWrapper[key1].showQsn == true &&
                    dataWrapper[key1].response.dependentWrps.dependentValue == '' && dataWrapper[key1].response.dependentWrps.showDepValue == false) {
                    dataWrapper[key1].response.dependentWrps.depErrorMsg = '';
                }
            }
        }

        //Impact Section
        var checkedCount = 0;
        for (var key1 in dataWrapper) {
            //Text or Number
            if (dataWrapper[key1].qNo == '2.1' || dataWrapper[key1].qNo == '2.2' ||
                dataWrapper[key1].qNo == '2.3' || dataWrapper[key1].qNo == '2.3.1' ||
                dataWrapper[key1].qNo == '2.3.2' || dataWrapper[key1].qNo == '2.4' ||
                dataWrapper[key1].qNo == '2.4.1' || dataWrapper[key1].qNo == '2.4.3' ||
                dataWrapper[key1].qNo == '2.5' || dataWrapper[key1].qNo == '2.5.1' ||
                dataWrapper[key1].qNo == '2.6.1' || dataWrapper[key1].qNo == '2.7' ||
                dataWrapper[key1].qNo == '2.8' || dataWrapper[key1].qNo == '2.9.1' ||
                dataWrapper[key1].qNo == '2.10' || dataWrapper[key1].qNo == '2.11' ||
                dataWrapper[key1].qNo == '2.12') {
                if (dataWrapper[key1].response.respValueWrps.value == '' && dataWrapper[key1].showQsn == true) {
                    dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                    isImpactComplete = false;
                } else {
                    dataWrapper[key1].response.respValueWrps.errorMsg = '';
                }
            }

            //table
            else if (dataWrapper[key1].qNo == '2.3.2.1' && dataWrapper[key1].showQsn == true) {
                for (var key12 in dataWrapper[key1].response.unitCostTableWrps) {
                    if (dataWrapper[key1].response.unitCostTableWrps[key12].reductionPercentage == '' ||
                        dataWrapper[key1].response.unitCostTableWrps[key12].peopleBenifited == '') {
                        dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                        isImpactComplete = false;
                        break;
                    } else {
                        dataWrapper[key1].response.respValueWrps.errorMsg = '';
                    }
                }
            }

            //MultiCheckbox
            else if (dataWrapper[key1].qNo == '2.4.1' && dataWrapper[key1].showQsn == true) {
                console.log(dataWrapper[key1].response);
                var unCheckedCount = 0;
                for (var key12 in dataWrapper[key1].response.multiCheckboxWrps) {
                    if (dataWrapper[key1].response.multiCheckboxWrps[key12].isChecked == false) {
                        unCheckedCount += 1;
                    }
                    if (dataWrapper[key1].response.multiCheckboxWrps[key12].isChecked == true && dataWrapper[key1].response.multiCheckboxWrps[key12].name == 'Other' &&
                        dataWrapper[key1].response.dependentWrps.showDepValue == true && dataWrapper[key1].response.dependentWrps.dependentValue == '') {
                        dataWrapper[key1].response.dependentWrps.depErrorMsg = $A.get("$Label.c.ZSP_AnswerIfOtherSelected");
                        isImpactComplete = false;
                    } else if (dataWrapper[key1].response.multiCheckboxWrps[key12].isChecked == true && dataWrapper[key1].response.multiCheckboxWrps[key12].name == 'Other' &&
                        dataWrapper[key1].response.dependentWrps.showDepValue == true && dataWrapper[key1].response.dependentWrps.dependentValue != '') {
                        dataWrapper[key1].response.dependentWrps.depErrorMsg = '';
                    } else if (dataWrapper[key1].response.multiCheckboxWrps[key12].isChecked == false && dataWrapper[key1].response.multiCheckboxWrps[key12].name == 'Other' &&
                        dataWrapper[key1].response.dependentWrps.showDepValue == false && dataWrapper[key1].response.dependentWrps.dependentValue == '') {
                        dataWrapper[key1].response.dependentWrps.depErrorMsg = '';
                    }
                }
                if (unCheckedCount == 5) {
                    dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                    isImpactComplete = false;
                } else if (unCheckedCount < 5) {
                    dataWrapper[key1].response.respValueWrps.errorMsg = '';
                }
            } else if ((dataWrapper[key1].qNo == '2.5.1' || dataWrapper[key1].qNo == '2.6') && dataWrapper[key1].showQsn == true) {
                console.log(dataWrapper[key1].response);
                var unCheckedCount = 0;
                for (var key12 in dataWrapper[key1].response.multiCheckboxWrps) {
                    if (dataWrapper[key1].response.multiCheckboxWrps[key12].isChecked == false) {
                        unCheckedCount += 1;
                    }
                    if (dataWrapper[key1].response.multiCheckboxWrps[key12].isChecked == true && dataWrapper[key1].response.multiCheckboxWrps[key12].name == 'Other' &&
                        dataWrapper[key1].response.dependentWrps.showDepValue == true && dataWrapper[key1].response.dependentWrps.dependentValue == '') {
                        dataWrapper[key1].response.dependentWrps.depErrorMsg = $A.get("$Label.c.ZSP_AnswerIfOtherSelected");
                        isImpactComplete = false;
                    } else if (dataWrapper[key1].response.multiCheckboxWrps[key12].isChecked == true && dataWrapper[key1].response.multiCheckboxWrps[key12].name == 'Other' &&
                        dataWrapper[key1].response.dependentWrps.showDepValue == true && dataWrapper[key1].response.dependentWrps.dependentValue != '') {
                        dataWrapper[key1].response.dependentWrps.depErrorMsg = '';
                    } else if (dataWrapper[key1].response.multiCheckboxWrps[key12].isChecked == false && dataWrapper[key1].response.multiCheckboxWrps[key12].name == 'Other' &&
                        dataWrapper[key1].response.dependentWrps.showDepValue == false && dataWrapper[key1].response.dependentWrps.dependentValue == '') {
                        dataWrapper[key1].response.dependentWrps.depErrorMsg = '';
                    }
                }
                if (unCheckedCount == 7) {
                    dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                    isImpactComplete = false;
                } else if (unCheckedCount < 7) {
                    dataWrapper[key1].response.respValueWrps.errorMsg = '';
                }
            } else if (dataWrapper[key1].qNo == '2.9' && dataWrapper[key1].showQsn == true) {
                var unCheckedCount = 0;
                for (var key12 in dataWrapper[key1].response.multiCheckboxWrps) {
                    if (dataWrapper[key1].response.multiCheckboxWrps[key12].isChecked == false) {
                        unCheckedCount += 1;
                    }
                    if (dataWrapper[key1].response.multiCheckboxWrps[key12].name != 'None of these' &&
                        dataWrapper[key1].response.multiCheckboxWrps[key12].isChecked == true) {
                        checkedCount += 1;
                    }
                }
                if (unCheckedCount == 4) {
                    dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                    isImpactComplete = false;
                } else if (unCheckedCount < 4) {
                    dataWrapper[key1].response.respValueWrps.errorMsg = '';
                }
            } else if (dataWrapper[key1].qNo == '2.9.2' && dataWrapper[key1].showQsn == true) {
                if (checkedCount == 0)
                    for (var key12 in dataWrapper[key1].response.impactTableWrps) {
                        if (dataWrapper[key1].response.impactTableWrps[key12].area == '' ||
                            dataWrapper[key1].response.impactTableWrps[key12].impactDescription == '' ||
                            dataWrapper[key1].response.impactTableWrps[key12].impactNumber == '') {
                            dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                            isImpactComplete = false;
                            break;
                        } else {
                            dataWrapper[key1].response.respValueWrps.errorMsg = '';
                        }
                    }
                if (checkedCount == 1) {
                    if (dataWrapper[key1].response.impactTableWrps[0].area == '' ||
                        dataWrapper[key1].response.impactTableWrps[0].impactDescription == '' ||
                        dataWrapper[key1].response.impactTableWrps[0].impactNumber == '') {
                        dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                        isImpactComplete = false;
                    } else {
                        dataWrapper[key1].response.respValueWrps.errorMsg = '';
                    }
                }
                if (checkedCount == 2) {
                    if (dataWrapper[key1].response.impactTableWrps[0].area == '' ||
                        dataWrapper[key1].response.impactTableWrps[0].impactDescription == '' ||
                        dataWrapper[key1].response.impactTableWrps[0].impactNumber == '' ||
                        dataWrapper[key1].response.impactTableWrps[1].area == '' ||
                        dataWrapper[key1].response.impactTableWrps[1].impactDescription == '' ||
                        dataWrapper[key1].response.impactTableWrps[1].impactNumber == '') {
                        dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                        isImpactComplete = false;
                    } else {
                        dataWrapper[key1].response.respValueWrps.errorMsg = '';
                    }
                }
                if (checkedCount == 3) {
                    if (dataWrapper[key1].response.impactTableWrps[0].area == '' ||
                        dataWrapper[key1].response.impactTableWrps[0].impactDescription == '' ||
                        dataWrapper[key1].response.impactTableWrps[0].impactNumber == '' ||
                        dataWrapper[key1].response.impactTableWrps[1].area == '' ||
                        dataWrapper[key1].response.impactTableWrps[1].impactDescription == '' ||
                        dataWrapper[key1].response.impactTableWrps[1].impactNumber == '' ||
                        dataWrapper[key1].response.impactTableWrps[2].area == '' ||
                        dataWrapper[key1].response.impactTableWrps[2].impactDescription == '' ||
                        dataWrapper[key1].response.impactTableWrps[2].impactNumber == '') {
                        dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                        isImpactComplete = false;
                    } else {
                        dataWrapper[key1].response.respValueWrps.errorMsg = '';
                    }
                }
            }
        }

        //Inspiration Section
        for (var key1 in dataWrapper) {
            //Text or Number
            if (dataWrapper[key1].qNo == '3.1' || dataWrapper[key1].qNo == '3.2' || dataWrapper[key1].qNo == '3.3' || dataWrapper[key1].qNo == '3.4') {
                if (dataWrapper[key1].response.respValueWrps.value == '' && dataWrapper[key1].showQsn == true) {
                    dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                    isInspirationComplete = false;
                } else {
                    dataWrapper[key1].response.respValueWrps.errorMsg = '';
                }
            }
        }

        //Other Info Section
        var attTLCount = component.get("v.aplAttachMap").attList_TL.length;
        console.log('attTLCount >>> ' + attTLCount);
        if (attTLCount == 0) {
            component.set("v.showTLError", true);
            isOtherInfoComplete = false;
        } else {
            component.set("v.showTLError", false);
        }


        //Networking Section
        for (var key1 in dataWrapper) {
            if (dataWrapper[key1].qNo == '5.1' || dataWrapper[key1].qNo == '5.2' ||
                dataWrapper[key1].qNo == '5.3' || dataWrapper[key1].qNo == '5.4' || dataWrapper[key1].qNo == '5.5' ||
                dataWrapper[key1].qNo == '5.5.1' || dataWrapper[key1].qNo == '5.5.2' || dataWrapper[key1].qNo == '5.5.3' ||
                dataWrapper[key1].qNo == '5.5.4' || dataWrapper[key1].qNo == '5.5.5' || dataWrapper[key1].qNo == '5.5.6' || dataWrapper[key1].qNo == '5.5.7') {
                if (dataWrapper[key1].response.respValueWrps.value == '' && dataWrapper[key1].showQsn == true) {
                    dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                    isNetworkingComplete = false;
                } else {
                    dataWrapper[key1].response.respValueWrps.errorMsg = '';
                }
            } else if (dataWrapper[key1].qNo == '5.1.1' && dataWrapper[key1].showQsn == true) {
                var unCheckedCount = 0;
                for (var key12 in dataWrapper[key1].response.multiCheckboxWrps) {
                    if (dataWrapper[key1].response.multiCheckboxWrps[key12].isChecked == false) {
                        unCheckedCount += 1;
                    }
                }
                console.log('unCheckedCount out>> ' + unCheckedCount);
                if (unCheckedCount == 42) {
                    dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                    isNetworkingComplete = false;
                } else if (unCheckedCount < 42) {
                    dataWrapper[key1].response.respValueWrps.errorMsg = '';
                }
            }
        }

        //sections conditions
        if (isGeneralComplete == false) {
            if (ErrorMsg != '' && ErrorMsg != null)
                ErrorMsg += ',General Section';
            else
                ErrorMsg += 'General Section';
        }
        if (isInnovationComplete == false) {
            if (ErrorMsg != '' && ErrorMsg != null)
                ErrorMsg += ',Innovation Section';
            else
                ErrorMsg += 'Innovation Section';
        }
        if (isImpactComplete == false) {
            if (ErrorMsg != '' && ErrorMsg != null)
                ErrorMsg += ',Impact Section';
            else
                ErrorMsg += 'Impact Section';
        }
        if (isInspirationComplete == false) {
            if (ErrorMsg != '' && ErrorMsg != null)
                ErrorMsg += ',Inspiration Section';
            else
                ErrorMsg += 'Inspiration Section';
        }
        if (isOtherInfoComplete == false) {
            if (ErrorMsg != '' && ErrorMsg != null)
                ErrorMsg += ',Other Information Section';
            else
                ErrorMsg += 'Other Information Section';
        }
        if (isNetworkingComplete == false) {
            if (ErrorMsg != '' && ErrorMsg != null)
                ErrorMsg += ',Networking Section';
            else
                ErrorMsg += 'Networking Section';
        }

        if (ErrorMsg != '' && ErrorMsg != null)
            component.set("v.isSectionsError", true);
        else
            component.set("v.isSectionsError", false);
        component.set("v.sectionsErrorMsg", 'Please fill the following Sections: ' + ErrorMsg);
        component.set("v.FoodCatWrp", dataWrapper);
        console.log(dataWrapper);

        if (component.get("v.isSectionsError") == false && ErrorMsg == '')
            helper.handleSaveHelper(component, event, helper);
    },

    addImpactRow: function(component, event, helper) {
        var wrp = component.get("v.FoodCatWrp");
        for (var key in wrp) {
            if (wrp[key].qNo == '2.9.2') {
                wrp[key].response.impactTableWrps.push({
                    area: '',
                    impactDescription: '',
                    impactNumber: '',
                    areaPlaceHolder: '',
                    impDescPlaceHolder: '',
                    impNumPlaceHolder: ''
                });
                component.set("v.FoodCatWrp", wrp);
            }
        }
    },

    removeImpactRow: function(component, event, helper) {
        var whichOne = event.target.getAttribute("id")
        var wrp = component.get("v.FoodCatWrp");
        for (var key in wrp) {
            if (wrp[key].qNo == '2.9.2') {
                wrp[key].response.impactTableWrps.splice(whichOne, 1);
                component.set("v.FoodCatWrp", wrp);
            }
        }
    },

    viewAttach: function(component, event, helper) {
        var attachment = event.getSource().get("v.value");
        console.log('attachment ID' + attachment.Id);
        console.log('View Attachment Classic >>> ' + document.URL.split('/apex')[0]);
        console.log('View Attachment Lightning >>>  ' + document.URL.split('/lightning')[0]);

        if (document.URL.includes('/apex'))
            window.open(document.URL.split('/apex')[0] + '/servlet/servlet.FileDownload?file=' + attachment.Id + '&operationContext=S1', '_blank');

        if (document.URL.includes('/lightning'))
            window.open(document.URL.split('/lightning')[0] + '/servlet/servlet.FileDownload?file=' + attachment.Id + '&operationContext=S1', '_blank');
    },

    removeAttach: function(component, event, helper) {
        var attachment = event.getSource().get("v.value")
        console.log('Remove Attachment >>> ' + attachment);
        console.log('attachment ID >>> ' + attachment.Id); //attToDelete
        helper.loadAttachments(component, event, helper, attachment.Id);
    },

    handleFileUploadEvent: function(component, event, helper) {
        console.log('getAttachmentList parameter>>>  ' + event.getParam("getAttachmentList"));
        if (event.getParam("getAttachmentList") == true)
            helper.loadAttachments(component, event, helper, null);
    },

    closeModel: function(component, event, helper) {
        component.set("v.showSaveDraftMsg", false);
    },

});