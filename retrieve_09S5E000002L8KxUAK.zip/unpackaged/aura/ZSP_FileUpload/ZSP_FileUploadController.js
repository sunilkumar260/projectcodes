({
    doInit : function(component, event, helper) {
        console.log(component.get("v.totalAttachments"));
        component.set("v.fileName", 'No File Selected..');
         //No File Selected..
    },
    
    doSave: function(component, event, helper) {
        //console.log(component.find("fileId").get("v.files"));
         component.set("v.hideUploadButton", true);
        if (component.find("fileId").get("v.files") !=null &&component.find("fileId").get("v.files").length > 0 ) {
            helper.uploadHelper(component, event);
        } else {
            alert('Please Select a Valid File');
            component.set("v.hideUploadButton", false);
        }
    },
    
    handleFilesChange: function(component, event, helper) {
        var uploadedFiles = event.getParam("v.files");
        var fileName = 'No File Selected..';
        if (event.getSource().get("v.files").length > 0) {
            fileName = event.getSource().get("v.files")[0]['name'];
            component.set("v.hideUploadButton", false);
        }
        component.set("v.fileName", fileName);
        //component.set("v.fileName", fileName);
        console.log("fileName >>"+fileName);
    }, 
    
})