({
    MAX_FILE_SIZE: 7850000, //Max file size 7 MB 
    CHUNK_SIZE: 750000,      //Chunk Max size 750Kb 
    
    uploadHelper: function(component, event) {
        //debugger;
        component.set("v.showLoadingSpinner", true);
        var fileInput = component.find("fileId").get("v.files");
        var file = fileInput[0];
        var self = this;
        if (file.size > self.MAX_FILE_SIZE) {
            component.set("v.showLoadingSpinner", false);
            component.set("v.fileName", 'File size cannot exceed more than 7MB.');
            return;
        }
        
        var objFileReader = new FileReader();
        objFileReader.onload = $A.getCallback(function() {
            var fileContents = objFileReader.result;
            var base64 = 'base64,';
            var dataStart = fileContents.indexOf(base64) + base64.length;
            fileContents = fileContents.substring(dataStart);
            self.uploadProcess(component, file, fileContents);
        });
        objFileReader.readAsDataURL(file);
    },
    
    uploadProcess: function(component, file, fileContents) {
        //console.log('uploadProcess');
        var startPosition = 0;
        var endPosition = Math.min(fileContents.length, startPosition + this.CHUNK_SIZE);
        this.uploadInChunk(component, file, fileContents, startPosition, endPosition, '');
    },
    
    uploadInChunk: function(component, file, fileContents, startPosition, endPosition, attachId) {
        //console.log('uploadInChunk');
        var isTL = component.get("v.isTradeLicense");
        var fName;
        if(isTL == true){
            if(file.name.startsWith('TL-')){
                fName = file.name;
            }else{
                fName = 'TL-'+file.name;
            }
        }else{
            fName = file.name;
            var nameCount = fName.split('TL-');
            //alert(nameCount);
            for(var i=0; i<nameCount.length; i++){
                if(fName.startsWith('TL-')){
                    fName=fName.replace('TL-','');
                    //alert(fName);
                } 
            }
        }
        
        var getchunk = fileContents.substring(startPosition, endPosition);
        var action = component.get("c.saveChunk");
        action.setParams({
            parentId: component.get("v.parentId"),
            fileName: fName,
            base64Data: encodeURIComponent(getchunk),
            contentType: file.type,
            fileId: attachId
        });
        action.setCallback(this, function(response) {
            attachId = response.getReturnValue();
            var state = response.getState();
            if (state === "SUCCESS") {
                startPosition = endPosition;
                endPosition = Math.min(fileContents.length, startPosition + this.CHUNK_SIZE);
                if (startPosition < endPosition) {
                    this.uploadInChunk(component, file, fileContents, startPosition, endPosition, attachId);
                } else {
                    component.set("v.hideUploadButton", true);
                    component.set("v.showLoadingSpinner", false); 
                    component.set("v.fileName", '');
                    component.set("v.uploadSuccessMsg", true);
                    component.set("v.successFileUpload", "Your File is uploaded successfully");
                    window.setTimeout(
                        $A.getCallback(function() {
                            component.set("v.uploadSuccessMsg", false);
                            component.set("v.fileName", 'No File Selected..');
                        }), 5000
                    );
                    //New Change
                    console.log('HI');
                    var myEvent = component.getEvent("fileUploadEvent");
                    myEvent.setParams({"getAttachmentList": true});
                    myEvent.fire();
                }
            } else if (state === "INCOMPLETE") {
                alert("From server: " + response.getReturnValue());
            } else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        });
        $A.enqueueAction(action);
    },
    
    // Helper function for toast Messages.
    fireToasts : function(ToastMsg) {
        console.log(ToastMsg);
        
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            title : 'Please review below errors',
            message:'\n'+ToastMsg,
            messageTemplate: 'Mode is pester ,duration is 5sec and Message is overrriden',
            duration:'5000',
            key: 'info_alt',
            type: 'Error',
            mode:'dismissible'
        });
        toastEvent.fire(); 
        
    },
})