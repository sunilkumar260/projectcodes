({
    doInit: function(component, event, helper) {
        var typeInput = component.get("v.inputType");
        var displayOptions = [];
        if (typeInput == 'Radio') {
            displayOptions = component.get("v.inputOptions");
            //console.log('displayOptions >>> '+displayOptions);
            var radioList = [];
            for (var key in displayOptions){
                console.log('key >>> '+displayOptions[key]);
                radioList.push({
                    label: displayOptions[key],
                    value: displayOptions[key]
                });
            } 
            component.set("v.iterateOptions", radioList); 
        }
        if(typeInput == 'Picklist') {
            component.set("v.iterateOptions",component.get("v.inputOptions"));
         } 
    },
    
    handlePicklistChange: function (component, event, helper) {
        var dataWrapper = component.get('v.dataWrapper');
        var key = component.get('v.quesNo');
        var value = component.find('select').get('v.value');
        
        var cmpEvent = component.getEvent("cmpEvent");
        
        console.log('value  --> '+value);
        
        //----------------------------------------------
        
        for(var key1 in dataWrapper){          
            if(key == '0.8'){
                if(value == 'Yes'){
                    if(dataWrapper[key1].qNo == '0.8.1'){
                        dataWrapper[key1].response.showQsn = true;
                        console.log(dataWrapper[key1].response.showQsn);    
                    }
                    
                } else{
                    
                    if(dataWrapper[key1].qNo == '0.8.1'){
                        dataWrapper[key1].response.showQsn = false;
                        dataWrapper[key1].response.value = '';
                        console.log(dataWrapper[key1].response.value);  
                    }
                    
                }
            }
        }
        
        component.set("v.dataWrapper", dataWrapper );
    },
   
    handleRadioChange: function(component, event, helper) {
        var dataWrapper = component.get('v.dataWrapper');
        var key = component.get('v.quesNo');
        var selectedValue = component.find('select').get('v.value');
        var selectedRadioOption = event.getSource().get("v.value");
        console.log({
            key,
            selectedValue,
            selectedRadioOption,
            dataWrapper
        });

        for (var key1 in dataWrapper) {
            if (key == '0.4') {
                if (selectedValue != 'Other') {
                    if (dataWrapper[key1].qNo == '0.4') {
                        dataWrapper[key1].response.dependentWrps.showDepValue = false;
                        dataWrapper[key1].response.dependentWrps.dependentValue = '';
                    }
                } else if (selectedValue == 'Other') {
                    if (dataWrapper[key1].qNo == '0.4') {
                        dataWrapper[key1].response.dependentWrps.showDepValue = true;
                        //dataWrapper[key1].response.dependentWrps.dependentValue = ''; 
                    }
                }
            }
            
         }
        component.set("v.dataWrapper", dataWrapper);
    },

    handleMultiCheckboxChange: function(component, event, helper) {
        
        var dataWrapper = component.get('v.dataWrapper');
        var key = component.get('v.quesNo');
        var selectedValue = event.getSource().get("v.value");
        console.log({
            key,
            selectedValue,
            dataWrapper
        });

        for (var key1 in dataWrapper) {
             if (event.getSource().get('v.checked') == true) {
             if (key == '0.8') {
               if (selectedValue == 'Energy' && dataWrapper[key1].qNo == '2.2'){
                        dataWrapper[key1].showQsn = true;
                    if (dataWrapper[key1].response.showCategoriesWrps.showEnergy == true && 
                        dataWrapper[key1].response.showCategoriesWrps.showWater == true && 
                        dataWrapper[key1].response.showCategoriesWrps.showFood == true &&
                        dataWrapper[key1].response.showCategoriesWrps.showHealth == true){
            
                        //Energy
                        dataWrapper[key1].response.showCategoriesWrps.showEnergy = true;
            
                        //Water
                        dataWrapper[key1].response.showCategoriesWrps.showWater = false;
                        dataWrapper[key1].response.categoriesWrps[1] = [];
                        dataWrapper[key1].response.categoriesWrps[1].push({
                        goal: '',
                        goalPlaceholder: 'e.g. Annual Water consumption',
                        unit: '',
                        unitPlaceholder: 'Litres/year',
                        currentLevel: '',
                        currentLevelPlaceholder: '50000',
                        target: '',
                        targetPlaceholder: '40000'
                        });
                        dataWrapper[key1].response.categoriesWrps[1].push({
                        goal: '',
                        goalPlaceholder: 'e.g. Availability of safe drinking water',
                        unit: '',
                        unitPlaceholder: '%',
                        currentLevel: '',
                        currentLevelPlaceholder: '50%',
                        target: '',
                        targetPlaceholder: '90%'
                        });
                        
                        //Food
                        dataWrapper[key1].response.showCategoriesWrps.showFood = false;
                        dataWrapper[key1].response.categoriesWrps[2] = [];
                        dataWrapper[key1].response.categoriesWrps[2].push({
                            goal: '',
                            goalPlaceholder: 'e.g. production of food grown per year through sustainable methods (e.g. hydroponics)',
                            unit: '',
                            unitPlaceholder: 'Kg',
                            currentLevel: '',
                            currentLevelPlaceholder: '0',
             				target: '',
                            targetPlaceholder: '250'
                          });
        
                        //Health
                        dataWrapper[key1].response.showCategoriesWrps.showHealth = false;
                        dataWrapper[key1].response.categoriesWrps[3] = [];
                        dataWrapper[key1].response.categoriesWrps[3].push({
                            goal: '',
                            goalPlaceholder: 'e.g. Availability of essential health care services at school',
                            unit: '',
                            unitPlaceholder: '% of students with access to healthcare',
                            currentLevel: '',
                            currentLevelPlaceholder: '25%',
             				target: '',
                            targetPlaceholder: '75%'
                          });
                     }
                   else{
                        dataWrapper[key1].response.showCategoriesWrps.showEnergy = true;
                    }
                 } 
                 else if (selectedValue == 'Water' && dataWrapper[key1].qNo == '2.2'){
                        dataWrapper[key1].showQsn = true;
                    if (dataWrapper[key1].response.showCategoriesWrps.showEnergy == true && 
                        dataWrapper[key1].response.showCategoriesWrps.showWater == true && 
                        dataWrapper[key1].response.showCategoriesWrps.showFood == true &&
                        dataWrapper[key1].response.showCategoriesWrps.showHealth == true){
                        
                        //Water
                        dataWrapper[key1].response.showCategoriesWrps.showWater = true;
                        
                        //Energy
                        dataWrapper[key1].response.showCategoriesWrps.showEnergy = false;
                        dataWrapper[key1].response.categoriesWrps[0] = [];
                        dataWrapper[key1].response.categoriesWrps[0].push({
                            goal: '',
                            goalPlaceholder: 'e.g. Annual Energy Consumption',
                            unit: '',
                            unitPlaceholder: 'MWh per year',
                            currentLevel: '',
                            currentLevelPlaceholder: '',
             				target: '',
                            targetPlaceholder: ''
                          });
                        dataWrapper[key1].response.categoriesWrps[0].push({
                            goal: '',
                            goalPlaceholder: 'e.g. Renewable Energy Generated',
                            unit: '',
                            unitPlaceholder: 'MWh per year',
                            currentLevel: '',
                            currentLevelPlaceholder: '',
             				target: '',
                            targetPlaceholder: ''
                          });
         				dataWrapper[key1].response.categoriesWrps[0].push({
                            goal: '',
                            goalPlaceholder: 'e.g. Proportion of Renewable Energy used at school',
                            unit: '',
                            unitPlaceholder: '%',
                            currentLevel: '',
                            currentLevelPlaceholder: '',
             				target: '',
                            targetPlaceholder: ''
                          });

                        //Food
                        dataWrapper[key1].response.showCategoriesWrps.showFood = false;
                        dataWrapper[key1].response.categoriesWrps[2] = [];
                        dataWrapper[key1].response.categoriesWrps[2].push({
                            goal: '',
                            goalPlaceholder: 'e.g. production of food grown per year through sustainable methods (e.g. hydroponics)',
                            unit: '',
                            unitPlaceholder: 'Kg',
                            currentLevel: '',
                            currentLevelPlaceholder: '0',
             				target: '',
                            targetPlaceholder: '250'
                          });
        
                        //Health
                        dataWrapper[key1].response.showCategoriesWrps.showHealth = false;
                        dataWrapper[key1].response.categoriesWrps[3] = [];
                        dataWrapper[key1].response.categoriesWrps[3].push({
                            goal: '',
                            goalPlaceholder: 'e.g. Availability of essential health care services at school',
                            unit: '',
                            unitPlaceholder: '% of students with access to healthcare',
                            currentLevel: '',
                            currentLevelPlaceholder: '25%',
             				target: '',
                            targetPlaceholder: '75%'
                          });
                     }
                     else{
                        dataWrapper[key1].response.showCategoriesWrps.showWater = true;
                    }
                 } 
                  else if (selectedValue == 'Food' && dataWrapper[key1].qNo == '2.2'){
                        dataWrapper[key1].showQsn = true;
                    if (dataWrapper[key1].response.showCategoriesWrps.showEnergy == true && 
                        dataWrapper[key1].response.showCategoriesWrps.showWater == true && 
                        dataWrapper[key1].response.showCategoriesWrps.showFood == true &&
                        dataWrapper[key1].response.showCategoriesWrps.showHealth == true){
                        
                        //Food
                        dataWrapper[key1].response.showCategoriesWrps.showFood = true;
                        
                        //Energy
                        dataWrapper[key1].response.showCategoriesWrps.showEnergy = false;
                        dataWrapper[key1].response.categoriesWrps[0] = [];
                        dataWrapper[key1].response.categoriesWrps[0].push({
                            goal: '',
                            goalPlaceholder: 'e.g. Annual Energy Consumption',
                            unit: '',
                            unitPlaceholder: 'MWh per year',
                            currentLevel: '',
                            currentLevelPlaceholder: '',
             				target: '',
                            targetPlaceholder: ''
                          });
                        dataWrapper[key1].response.categoriesWrps[0].push({
                            goal: '',
                            goalPlaceholder: 'e.g. Renewable Energy Generated',
                            unit: '',
                            unitPlaceholder: 'MWh per year',
                            currentLevel: '',
                            currentLevelPlaceholder: '',
             				target: '',
                            targetPlaceholder: ''
                          });
         				dataWrapper[key1].response.categoriesWrps[0].push({
                            goal: '',
                            goalPlaceholder: 'e.g. Proportion of Renewable Energy used at school',
                            unit: '',
                            unitPlaceholder: '%',
                            currentLevel: '',
                            currentLevelPlaceholder: '',
             				target: '',
                            targetPlaceholder: ''
                          });
                        
                        //Water
                        dataWrapper[key1].response.showCategoriesWrps.showWater = false;
                        dataWrapper[key1].response.categoriesWrps[1] = [];
                        dataWrapper[key1].response.categoriesWrps[1].push({
                        goal: '',
                        goalPlaceholder: 'e.g. Annual Water consumption',
                        unit: '',
                        unitPlaceholder: 'Litres/year',
                        currentLevel: '',
                        currentLevelPlaceholder: '50000',
                        target: '',
                        targetPlaceholder: '40000'
                        });
                        dataWrapper[key1].response.categoriesWrps[1].push({
                        goal: '',
                        goalPlaceholder: 'e.g. Availability of safe drinking water',
                        unit: '',
                        unitPlaceholder: '%',
                        currentLevel: '',
                        currentLevelPlaceholder: '50%',
                        target: '',
                        targetPlaceholder: '90%'
                        });
                        
                        //Health
                        dataWrapper[key1].response.showCategoriesWrps.showHealth = false;
                        dataWrapper[key1].response.categoriesWrps[3] = [];
                        dataWrapper[key1].response.categoriesWrps[3].push({
                            goal: '',
                            goalPlaceholder: 'e.g. Availability of essential health care services at school',
                            unit: '',
                            unitPlaceholder: '% of students with access to healthcare',
                            currentLevel: '',
                            currentLevelPlaceholder: '25%',
             				target: '',
                            targetPlaceholder: '75%'
                          });
                     }
                      else{
                        dataWrapper[key1].response.showCategoriesWrps.showFood = true;
                    }
                 } 
                   else if (selectedValue == 'Health' && dataWrapper[key1].qNo == '2.2'){
                       dataWrapper[key1].showQsn = true; 
                    if (dataWrapper[key1].response.showCategoriesWrps.showEnergy == true && 
                        dataWrapper[key1].response.showCategoriesWrps.showWater == true && 
                        dataWrapper[key1].response.showCategoriesWrps.showFood == true &&
                        dataWrapper[key1].response.showCategoriesWrps.showHealth == true){
                        
                        //Health
                        dataWrapper[key1].response.showCategoriesWrps.showHealth = true;
                        
                        //Energy
                        dataWrapper[key1].response.showCategoriesWrps.showEnergy = false;
                        dataWrapper[key1].response.categoriesWrps[0] = [];
                        dataWrapper[key1].response.categoriesWrps[0].push({
                            goal: '',
                            goalPlaceholder: 'e.g. Annual Energy Consumption',
                            unit: '',
                            unitPlaceholder: 'MWh per year',
                            currentLevel: '',
                            currentLevelPlaceholder: '',
             				target: '',
                            targetPlaceholder: ''
                          });
                        dataWrapper[key1].response.categoriesWrps[0].push({
                            goal: '',
                            goalPlaceholder: 'e.g. Renewable Energy Generated',
                            unit: '',
                            unitPlaceholder: 'MWh per year',
                            currentLevel: '',
                            currentLevelPlaceholder: '',
             				target: '',
                            targetPlaceholder: ''
                          });
         				dataWrapper[key1].response.categoriesWrps[0].push({
                            goal: '',
                            goalPlaceholder: 'e.g. Proportion of Renewable Energy used at school',
                            unit: '',
                            unitPlaceholder: '%',
                            currentLevel: '',
                            currentLevelPlaceholder: '',
             				target: '',
                            targetPlaceholder: ''
                          });
                        
                        //Water
                        dataWrapper[key1].response.showCategoriesWrps.showWater = false;
                        dataWrapper[key1].response.categoriesWrps[1] = [];
                        dataWrapper[key1].response.categoriesWrps[1].push({
                        goal: '',
                        goalPlaceholder: 'e.g. Annual Water consumption',
                        unit: '',
                        unitPlaceholder: 'Litres/year',
                        currentLevel: '',
                        currentLevelPlaceholder: '50000',
                        target: '',
                        targetPlaceholder: '40000'
                        });
                        dataWrapper[key1].response.categoriesWrps[1].push({
                        goal: '',
                        goalPlaceholder: 'e.g. Availability of safe drinking water',
                        unit: '',
                        unitPlaceholder: '%',
                        currentLevel: '',
                        currentLevelPlaceholder: '50%',
                        target: '',
                        targetPlaceholder: '90%'
                        });
                        
                        //Food
                        dataWrapper[key1].response.showCategoriesWrps.showFood = false;
                        dataWrapper[key1].response.categoriesWrps[2] = [];
                        dataWrapper[key1].response.categoriesWrps[2].push({
                            goal: '',
                            goalPlaceholder: 'e.g. production of food grown per year through sustainable methods (e.g. hydroponics)',
                            unit: '',
                            unitPlaceholder: 'Kg',
                            currentLevel: '',
                            currentLevelPlaceholder: '0',
             				target: '',
                            targetPlaceholder: '250'
                          });
                     }
                       else{
                        dataWrapper[key1].response.showCategoriesWrps.showHealth = true;
                    }
                 }   
              }
            }
             else{
                if (key == '0.8') {
                    if (dataWrapper[key1].qNo == '0.8') {
                        var unCheckedCount=0;
                        for(var key12 in dataWrapper[key1].response.multiCheckboxWrps){
                            if(dataWrapper[key1].response.multiCheckboxWrps[key12].isChecked == false){
                                //alert(dataWrapper[key1].response.multiCheckboxWrps[key12].name);
                                unCheckedCount+=1;
                            }
                        }
                    }
                    if (dataWrapper[key1].qNo == '2.2') {
                        if(unCheckedCount==4){
                            dataWrapper[key1].showQsn = false;
                        }else if(unCheckedCount<4){
                            dataWrapper[key1].showQsn = true;
                        }
                    }
                if (selectedValue == 'Energy') {
                    if (dataWrapper[key1].qNo == '2.2') {
                        dataWrapper[key1].response.showCategoriesWrps.showEnergy = false;
                        dataWrapper[key1].response.categoriesWrps[0] = [];
                        dataWrapper[key1].response.categoriesWrps[0].push({
                            goal: '',
                            goalPlaceholder: 'e.g. Annual Energy Consumption',
                            unit: '',
                            unitPlaceholder: 'MWh per year',
                            currentLevel: '',
                            currentLevelPlaceholder: '',
             				target: '',
                            targetPlaceholder: ''
                          });
                        dataWrapper[key1].response.categoriesWrps[0].push({
                            goal: '',
                            goalPlaceholder: 'e.g. Renewable Energy Generated',
                            unit: '',
                            unitPlaceholder: 'MWh per year',
                            currentLevel: '',
                            currentLevelPlaceholder: '',
             				target: '',
                            targetPlaceholder: ''
                          });
         				dataWrapper[key1].response.categoriesWrps[0].push({
                            goal: '',
                            goalPlaceholder: 'e.g. Proportion of Renewable Energy used at school',
                            unit: '',
                            unitPlaceholder: '%',
                            currentLevel: '',
                            currentLevelPlaceholder: '',
             				target: '',
                            targetPlaceholder: ''
                          });
         			 }
                } 
                if (selectedValue == 'Water') {
                    if (dataWrapper[key1].qNo == '2.2') {
                        dataWrapper[key1].response.showCategoriesWrps.showWater = false;
                        dataWrapper[key1].response.categoriesWrps[1] = [];
                        dataWrapper[key1].response.categoriesWrps[1].push({
                            goal: '',
                            goalPlaceholder: 'e.g. Annual Water consumption',
                            unit: '',
                            unitPlaceholder: 'Litres/year',
                            currentLevel: '',
                            currentLevelPlaceholder: '50000',
             				target: '',
                            targetPlaceholder: '40000'
                          });
                        dataWrapper[key1].response.categoriesWrps[1].push({
                            goal: '',
                            goalPlaceholder: 'e.g. Availability of safe drinking water',
                            unit: '',
                            unitPlaceholder: '%',
                            currentLevel: '',
                            currentLevelPlaceholder: '50%',
             				target: '',
                            targetPlaceholder: '90%'
                          });
         		    }
                } 
                if (selectedValue == 'Food') {
                    if (dataWrapper[key1].qNo == '2.2') {
                        dataWrapper[key1].response.showCategoriesWrps.showFood = false;
                        dataWrapper[key1].response.categoriesWrps[2] = [];
                        dataWrapper[key1].response.categoriesWrps[2].push({
                            goal: '',
                            goalPlaceholder: 'e.g. production of food grown per year through sustainable methods (e.g. hydroponics)',
                            unit: '',
                            unitPlaceholder: 'Kg',
                            currentLevel: '',
                            currentLevelPlaceholder: '0',
             				target: '',
                            targetPlaceholder: '250'
                          });
                     }
                } 
                if (selectedValue == 'Health') {
                    if (dataWrapper[key1].qNo == '2.2') {
                        dataWrapper[key1].response.showCategoriesWrps.showHealth = false;
                        dataWrapper[key1].response.categoriesWrps[3] = [];
                        dataWrapper[key1].response.categoriesWrps[3].push({
                            goal: '',
                            goalPlaceholder: 'e.g. Availability of essential health care services at school',
                            unit: '',
                            unitPlaceholder: '% of students with access to healthcare',
                            currentLevel: '',
                            currentLevelPlaceholder: '25%',
             				target: '',
                            targetPlaceholder: '75%'
                          });
                     }
                } 
             }
          }
        }
        
        console.log(dataWrapper);
        component.set("v.dataWrapper", dataWrapper);
        
      /*  var selectedValue = event.getSource().get("v.value");
        var selectedlabel = event.getSource().get("v.label");
        var wrapdata = component.get('v.responseList.multiCheckboxWrps');
        var dependentWrap = component.get('v.responseList.dependentWrps');
        var key = component.get('v.quesNo');
        var dataWrapper = component.get('v.dataWrapper');
        console.log({
            key,
            selectedValue,
            selectedlabel,
            dataWrapper,
            wrapdata
        });

        for (var f in wrapdata) {
            if (wrapdata[f].name == selectedValue) {
                if (event.getSource().get('v.checked') == true) {
                    if (key == '0.8') {
                        if (selectedValue == 'Other') {
                            //wrapdata[f].showResValue = true; 
                            dependentWrap.showDepValue = true;
                        } else if (selectedValue != 'Other') {
                            for (var a in wrapdata) {
                                if (wrapdata[a].name == 'Other' && wrapdata[a].isChecked == true) {
                                    dependentWrap.showDepValue = true;
                                } else if (wrapdata[a].name == 'Other' && wrapdata[a].isChecked == false) {
                                    dependentWrap.showDepValue = false;
                                    dependentWrap.dependentValue = '';
                                }
                            }
                        }
                    } else if (key == '2.6') {
                        if (selectedValue == 'Other') {
                            dependentWrap.showDepValue = true; 
                        }

                        if (selectedValue == 'None') {
                            dependentWrap.showDepValue = false;
                            dependentWrap.dependentValue = '';
                            for (var a in wrapdata) {
                                if (wrapdata[a].name != 'None') {
                                    wrapdata[a].isChecked = false;
                                }
                            }
                            for (var b in dataWrapper) {
                                if (dataWrapper[b].qNo == '2.6.1') {
                                    dataWrapper[b].showQsn = false;
                                    dataWrapper[b].response.respValueWrps.value = '';
                                }
                            }
                        }

                        if (selectedValue == 'Economic' || selectedValue == 'Environmental' || selectedValue == 'Political' ||
                            selectedValue == 'Societal' || selectedValue == 'Technological' || selectedValue == 'Other') {
                            for (var a in wrapdata) {
                                if (wrapdata[a].name == 'None' && wrapdata[a].isChecked == true) {
                                    wrapdata[a].isChecked = false;
                                }
                                 if (wrapdata[a].name == 'Other' && wrapdata[a].isChecked == true) {
                                    dependentWrap.showDepValue = true;
                                } else if (wrapdata[a].name == 'Other' && wrapdata[a].isChecked == false) {
                                    dependentWrap.showDepValue = false;
                                    dependentWrap.dependentValue = '';
                                }
                            }
                            for (var b in dataWrapper) {
                                if (dataWrapper[b].qNo == '2.6.1') {
                                    dataWrapper[b].showQsn = true;
                                }
                            }
                        }
                    } else if (key == '2.9') {
                        if (selectedValue == 'None of these') {
                            for (var a in wrapdata) {
                                if (wrapdata[a].name != 'None of these' && wrapdata[a].isChecked == true) {
                                    wrapdata[a].isChecked = false;
                                }
                            }
                        } else if (selectedValue != 'None of these') {
                            for (var a in wrapdata) {
                                if (wrapdata[a].name == 'None of these' && wrapdata[a].isChecked == true) {
                                    wrapdata[a].isChecked = false;
                                }
                            }
                        }
                    }
                } else { //Unchecked
                    if (key == '0.5' || key == '0.6' || key == '2.4.1' || key == '2.5.1' || key == '2.6') {
                        if (selectedValue == 'Other') {
                            dependentWrap.showDepValue = false;
                            dependentWrap.dependentValue = '';
                        }
                    }
                    if (key == '2.6') {
                        if (selectedValue == 'Economic' || selectedValue == 'Environmental' || selectedValue == 'Political' ||
                            selectedValue == 'Societal' || selectedValue == 'Technological' || selectedValue == 'Other') {
                            var ischecked = false;
                            for (var a in wrapdata) {
                                if (wrapdata[a].name != 'None' && wrapdata[a].isChecked == true) {
                                    ischecked = true;
                                    //console.log('Entered');
                                    break;
                                }
                            }
                            console.log(ischecked);
                            for (var b in dataWrapper) {
                                if (ischecked == true) {
                                    if (dataWrapper[b].qNo == '2.6.1') {
                                        dataWrapper[b].showQsn = true;
                                    }
                                } else {
                                    if (dataWrapper[b].qNo == '2.6.1') {
                                        dataWrapper[b].showQsn = false;
                                        dataWrapper[b].response.respValueWrps.value = '';
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        console.log(wrapdata);
        console.log(JSON.stringify(dependentWrap));
        component.set("v.dataWrapper", dataWrapper); */
    },
            
})