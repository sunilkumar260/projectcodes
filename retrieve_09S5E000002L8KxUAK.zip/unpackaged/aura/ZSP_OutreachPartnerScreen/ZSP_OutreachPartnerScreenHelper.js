({
    getApplications: function(component, page, recordToDisply) {
        var action = component.get("c.fetchApplications");
        action.setParams({
            "pageNumber": page,
            "recordToDisply": recordToDisply
        });
        action.setCallback(this, function(a) {
            var result = a.getReturnValue();
            console.log('result ---->' + JSON.stringify(result));
            component.set("v.applications", result.applications);
            component.set("v.page", result.page);
            component.set("v.total", result.total);
            component.set("v.pages", Math.ceil(result.total / recordToDisply));
        });
        $A.enqueueAction(action);
    }
})