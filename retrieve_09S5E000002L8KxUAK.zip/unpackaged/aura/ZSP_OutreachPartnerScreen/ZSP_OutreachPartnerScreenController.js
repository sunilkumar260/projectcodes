({
    doInit: function(component, event, helper) {
        var page = component.get("v.page") || 1;
        var recordToDisply = component.find("recordSize").get("v.value");
        helper.getApplications(component, page, recordToDisply);
    },
    
    navigate: function(component, event, helper) {
        var page = component.get("v.page") || 1;
        var direction = event.getSource().get("v.label");
        var recordToDisply = component.find("recordSize").get("v.value");
        page = direction === "Previous Page" ? (page - 1) : (page + 1);
        helper.getApplications(component, page, recordToDisply);
    },
    
    onSelectChange: function(component, event, helper) {
        var page = 1
        var recordToDisply = component.find("recordSize").get("v.value");
        helper.getApplications(component, page, recordToDisply);
    },
    
    viewApplication : function(component, event, helper) {
        var val = event.getSource().get("v.value");
        console.log('Resp ID'+val.Id); 
        console.log('Classic -->  '+document.URL.includes('/apex'));  
        console.log('Lightning -->  '+document.URL.includes('/lightning'));
        
        if(document.URL.includes('/apex'))
            window.open(document.URL.split('/apex')[0]+'/apex/ZSP_CategoriesPage?id='+val.Id+'&isView='+true, '_blank');
        if(document.URL.includes('/lightning'))
            window.open(document.URL.split('/lightning')[0]+'/apex/ZSP_CategoriesPage?id='+val.Id+'&isView='+true, '_blank');
    },
    
})