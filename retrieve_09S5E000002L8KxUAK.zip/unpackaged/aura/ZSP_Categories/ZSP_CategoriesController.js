({
	doInit : function(component, event, helper) {
        console.log('HI Iam Here'); 
        var actResponseWrp = component.get("c.regResponse");
        actResponseWrp.setCallback(this, function(response) {
            var state = response.getState();
            console.log('state resWrp--> '+state);
            if(state == "SUCCESS"){
                var result = response.getReturnValue();
                console.log('result  >> '); 
                console.log(result);
                component.set("v.regRespWrp", result);  
                component.set("v.respList", result.respList);
            }else{
                console.error("fail:" + response.getError()[0].message); 
            }
        });
        $A.enqueueAction(actResponseWrp);
    },
    
    callNewComp : function(component, event, helper){
        var val = event.getSource().get("v.value");
        console.log('val >>> '+JSON.stringify(val)); 
        console.log('document.URL >>> '+document.URL.replace('s/','')+'apex/ZSP_CategoriesPage?regId='+val.registrationId+'&isNew='+true); 
        
        window.open(document.URL.replace('s/','')+'apex/ZSP_CategoriesPage?regId='+val.registrationId+'&isNew='+true, '_self');
    },
    
    callEditComp : function(component, event, helper){
        var val = event.getSource().get("v.value");
        console.log('Resp ID'+val.Id); 
        window.open(document.URL.replace('s/','')+'apex/ZSP_CategoriesPage?id='+val.Id+'&isEdit='+true, '_self');
     },
    
    callViewComp  : function(component, event, helper){
        var val = event.getSource().get("v.value");
        //console.log(val.Response__c);
        //console.log(val.ZSP_Registration__c);
        console.log('Resp ID'+val.Id); 
        window.open(document.URL.replace('s/','')+'apex/ZSP_CategoriesPage?id='+val.Id+'&isView='+true, '_self');
    },   
    
    downloadPDF : function(component, event, helper){
        var val = event.getSource().get("v.value");
        //console.log(JSON.parse(val.value));
        //console.log(val.ZSP_Registration__c);
        console.log(val.Id); 
        window.open(document.URL.replace('s/','')+'apex/ZSP_DownloadPDF?id='+val.Id+'&isPDF='+true,'_blank');
        
    },  
})