({
    init : function(component, event, helper) {
        var recordId;
        recordId = component.get("v.recordId");
        console.log({recordId});
                     var actRelApl = component.get("c.releaseApplication");
                     actRelApl.setParams({
                     "currentAplId": recordId
                    });
        actRelApl.setCallback(this, function(response) {
             var state = response.getState();
            console.log('state resWrp--> '+state);
            if(state == "SUCCESS"){
            var result = response.getReturnValue();
            console.log({result}); 
            component.set("v.isSuccess", result.isSuccess);
            component.set("v.message", result.msg);
            component.set("v.clonedRecId", result.clonedRecId);
            }else{
                console.error("fail:" + response.getError()[0].message); 
            }
        });
        $A.enqueueAction(actRelApl); //event.getParams().keyCode
    },
    
    close : function(component, event, helper){
        var clonedRecId = component.get("v.clonedRecId");
        console.log($A.get("e.force:navigateToURL"));
        if(clonedRecId != null){
            var urlEvent = $A.get("e.force:navigateToURL");
            urlEvent.setParams({
                "url": "/"+clonedRecId
            });
            urlEvent.fire();  
        }else{
            $A.get("e.force:closeQuickAction").fire();
        }
    },
     
})