({
    init: function(component, event, helper) {
        component.set("v.spinner", true);
        component.set("v.successMsg", false);
        component.set("v.showContinueButton", false);
        component.set("v.showSaveDraftMsg", false);//New
        var urlString = window.location.href;
        var baseURL = urlString.substring(0, urlString.indexOf("/apex"));
        component.set("v.cbaseURL", baseURL);
        var recordId = component.get("v.recordId");
        console.log({
            recordId,baseURL
        });
        if (recordId != null) {
            component.set("v.respIdZSP", recordId);
            component.set("v.readOnly", true);
            component.set("v.isAccess", true);
        }

        var isAccess = component.get("v.isAccess");
        var isNew = component.get("v.isNew");
        var readOnly = component.get("v.readOnly");
        var isEditOrDraft = component.get("v.isEditOrDraft");
        var userRegistrationId = component.get("v.userRegistrationId");
        var respIdZSP = component.get("v.respIdZSP");
        console.log({
            isAccess,
            isNew,
            readOnly,
            isEditOrDraft,
            userRegistrationId,
            respIdZSP
        });

        if (component.get("v.isAccess") == true) {
            if (component.get("v.isEditOrDraft") == true) {
                component.set("v.step", 1);
                component.set('v.selectedSection', 'General_Information');
            } else if (component.get("v.readOnly") == true) {
                component.set("v.step", 1);
                component.set('v.selectedSection', 'General_Information');
            }

            //Getting School Wrapper
            var actWater = component.get("c.ZSP_SchoolCategoryList");
            actWater.setParams({
                "regId": component.get("v.userRegistrationId"),
                "aplId": component.get("v.respIdZSP")
            });
            actWater.setCallback(this, function(response) {
                var state = response.getState();
                console.log('state--> ' + state);
                if (component.isValid() && state === "SUCCESS") {
                    var result = response.getReturnValue();
                    console.log('result>>> ' + JSON.stringify(result));
                    if (result == null && isNew == true) {
                        console.log(document.URL.split('/apex'));
                        window.open(document.URL.split('/apex')[0], '_self');
                    } else if (result != null && isNew == true) {
                        component.set("v.step", 0);
                    }
                    if (result != null)
                        component.set("v.SchoolCatWrp", result);
                    component.set("v.spinner", false);
                } else if (component.isValid() && state === "ERROR") {
                    console.log("Exception caught successfully");
                    console.log("Error object", response);
                    console.log("Error Message", response.getError()[0]);
                    console.log("Error Message", response.getError()[0].message);
                    console.log("Error Message", response.getState());
                    console.log("Error object", JSON.stringify(response));
                }
            });
            $A.enqueueAction(actWater);
            //loading Attachments
            helper.loadAttachments(component, event, helper, null);
        }
    },

    wordsCount: function(component, event, helper) {
    var dataWrapper = component.get('v.SchoolCatWrp');
    var qValue = event.getSource().get("v.value");
    var qInfo = [];
    qInfo = event.getSource().get("v.name").split(';');
    var qNumber;
    var qRowIndex;
    qNumber = qInfo[0];
    qRowIndex = qInfo[1];

    console.log({
        qRowIndex,
        qNumber,
        qValue
    });

    for (var key1 in dataWrapper) {
        if (dataWrapper[key1].qNo == qNumber) {
            if (qNumber != '2.5') {
                var wordLen = dataWrapper[key1].response.respValueWrps.wordLimit;
                var len = qValue.split(/[\s]+/);
                var remainingwords = wordLen - len.length;
                if (qValue != '' && dataWrapper[key1].showQsn == true) {
                    if (len != '' && len.length <= wordLen && len.length > 0) {
                        if (len[len.length - 1] == '')
                            dataWrapper[key1].response.respValueWrps.wordCount = remainingwords + 1 + ' words Left';
                        if (len[len.length - 1] != '')
                            dataWrapper[key1].response.respValueWrps.wordCount = remainingwords + ' words Left';
                    }

                    if (len.length > wordLen) {
                        var wordQn = qValue;
                        var val = wordQn.split(" ").slice(0, wordLen).join(" ").trim(val);
                        console.log('len :' + len);
                        val = val.concat(" ")
                        event.preventDefault();
                        event.getSource().set("v.value", val);
                        dataWrapper[key1].response.respValueWrps.wordCount = '0 words Left';
                    }
                }
            } else if (qNumber == '2.5') {
                var wordLen = dataWrapper[key1].response.skillsWrps[qRowIndex].skillWordLimit;
                var len = dataWrapper[key1].response.skillsWrps[qRowIndex].skill.split(/[\s]+/);
                var remainingwords = wordLen - len.length;
                if (len != '' && dataWrapper[key1].showQsn == true) {
                    if (len != null && len.length <= wordLen && len.length > 0) {
                        if (len[len.length - 1] == '')
                            dataWrapper[key1].response.skillsWrps[qRowIndex].skillWordCount = remainingwords + 1 + ' words Left';
                        if (len[len.length - 1] != '')
                            dataWrapper[key1].response.skillsWrps[qRowIndex].skillWordCount = remainingwords + ' words Left';
                    }

                    if (len.length > wordLen) {
                        var wordQn = dataWrapper[key1].response.skillsWrps[qRowIndex].skill;
                        var val = wordQn.split(" ").slice(0, wordLen).join(" ").trim(val);
                        console.log('len :' + len);
                        val = val.concat(" ")
                        event.preventDefault();
                        dataWrapper[key1].response.skillsWrps[qRowIndex].skill = val;
                        dataWrapper[key1].response.skillsWrps[qRowIndex].skillWordCount = '0 words Left';
                    }
                }
             }
          }
        }
        component.set("v.SchoolCatWrp", dataWrapper);
    },
        
    handleInput: function(component, event, helper) {
    var dataWrapper = component.get('v.SchoolCatWrp');
    var qValue = event.getSource().get("v.value");
    var qNumber = event.getSource().get("v.name");

    console.log({
        qNumber,
        qValue
    });

    for (var key1 in dataWrapper) {
        if (qNumber == '2.8' && qValue >= 100000) {
            if (dataWrapper[key1].qNo == '2.8.1' || dataWrapper[key1].qNo == '2.8.2' || dataWrapper[key1].qNo == '2.8.3') {
                dataWrapper[key1].showQsn = true;
            }
        } else if (qNumber == '2.8' && qValue <= 100000) {
            if (dataWrapper[key1].qNo == '2.8.1' || dataWrapper[key1].qNo == '2.8.2' || dataWrapper[key1].qNo == '2.8.3') {
                dataWrapper[key1].showQsn = false;
                dataWrapper[key1].response.respValueWrps.value = '';
            }
         }
       }
     component.set("v.SchoolCatWrp", dataWrapper);
    },   
        
    handleSection: function(component, event, helper) {
        var selected = event.getParam('name');
        
        console.log(selected);
        if (selected === 'Instructions') {
            component.set('v.step', 0);
        }else if (selected === 'General_Information') { 
            component.set('v.step', 1);
        }else if (selected === 'Innovation') { 
            component.set('v.step', 2);
        }else if (selected === 'Impact') { 
            component.set('v.step', 3);
        }else if (selected === 'Inspiration') { 
            component.set('v.step', 4);
        }else if (selected === 'Other_Information') { 
            component.set('v.step', 5);
            //helper.loadAttachments(component, event, helper, null);
        }else if (selected === 'Submit') { 
            component.set('v.step', 6);
        }
    },
    
    onCheck : function(component, event, helper) {
        var selectedValue = event.getSource().get("v.value");
        var selectedlabel = event.getSource().get("v.label");
        console.log({selectedValue,selectedlabel});
                     if(event.getSource().get('v.checked') == true )
                     component.set("v.showContinueButton", true);
                     else 
                     component.set("v.showContinueButton", false);
       },
                     
    handleBack : function(component, event, helper) {
         window.scrollTo(0, 0);
        if(component.get('v.step') == 6){
            component.set("v.step", component.get('v.step')-1);
            component.set('v.selectedSection', 'Other_Information');
        }else if(component.get('v.step') == 5){
            component.set("v.step", component.get('v.step')-1);
            component.set('v.selectedSection', 'Inspiration');
        }else if(component.get('v.step') == 4){
            component.set("v.step", component.get('v.step')-1);
            component.set('v.selectedSection', 'Impact');
        }else if(component.get('v.step') == 3){
            component.set("v.step", component.get('v.step')-1);
            component.set('v.selectedSection', 'Innovation');
        }else if(component.get('v.step') == 2){
            component.set("v.step", component.get('v.step')-1);
            component.set('v.selectedSection', 'General_Information');
        }
    },
                   
    handleContinue: function(component, event, helper) {
         window.scrollTo(0, 0);
        if(component.get('v.step') == 0){
            component.set("v.step", component.get('v.step')+1);
            component.set('v.selectedSection', 'General_Information');
            var status = 'Draft';
            var successMsg = false;
            var isSaveDraft = false;
            helper.saveHelper(component, event, helper, status, successMsg, isSaveDraft); 
        }else if(component.get('v.step') == 1){
            component.set("v.step", component.get('v.step')+1);
            component.set('v.selectedSection', 'Innovation');
        }else if(component.get('v.step') == 2){
            component.set("v.step", component.get('v.step')+1);
            component.set('v.selectedSection', 'Impact');
        }else if(component.get('v.step') == 3){
            component.set("v.step", component.get('v.step')+1);
            component.set('v.selectedSection', 'Inspiration');
        }else if(component.get('v.step') == 4){
            component.set("v.step", component.get('v.step')+1);
            component.set('v.selectedSection', 'Other_Information');
        }else if(component.get('v.step') == 5){
            component.set("v.step", component.get('v.step')+1);
            component.set('v.selectedSection', 'Submit');
        }
    },
    
    handleSaveContinue: function(component, event, helper) {
         window.scrollTo(0, 0);
        if(component.get('v.step') == 0){
            component.set("v.step", component.get('v.step')+1);
            component.set('v.selectedSection', 'General_Information');
        }else if(component.get('v.step') == 1){
            component.set("v.step", component.get('v.step')+1);
            component.set('v.selectedSection', 'Innovation');
        }else if(component.get('v.step') == 2){
            component.set("v.step", component.get('v.step')+1);
            component.set('v.selectedSection', 'Impact');
        }else if(component.get('v.step') == 3){
            component.set("v.step", component.get('v.step')+1);
            component.set('v.selectedSection', 'Inspiration');
        }else if(component.get('v.step') == 4){
            component.set("v.step", component.get('v.step')+1);
            component.set('v.selectedSection', 'Other_Information');
        }else if(component.get('v.step') == 5){
            component.set("v.step", component.get('v.step')+1);
            component.set('v.selectedSection', 'Submit');
        }
        
        var status = 'Draft';
        var successMsg = false;
        var isSaveDraft = false;
        helper.saveHelper(component, event, helper, status, successMsg, isSaveDraft); 
    },
                     
    handleSaveDraft: function(component, event, helper) {
        var status = 'Draft';
        var successMsg = false;
        var isSaveDraft = true;
        helper.saveHelper(component, event, helper, status, successMsg, isSaveDraft); 
    },
    
    handleSave: function(component, event, helper) {
        component.set("v.isSectionsError", false)
        var dataWrapper = component.get('v.SchoolCatWrp');
        var ErrorMsg = ''; 
        var isGeneralComplete = true;
        var isInnovationComplete = true;
        var isImpactComplete = true;
        var isInspirationComplete = true;
        var isOtherInfoComplete = true;
        
        //General Section
        for(var key1 in dataWrapper){
            if(dataWrapper[key1].qNo == '0.1' || dataWrapper[key1].qNo == '0.7' || dataWrapper[key1].qNo == '0.9'){
                if(dataWrapper[key1].response.respValueWrps.value == '' && dataWrapper[key1].showQsn == true){
                    dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                    isGeneralComplete = false;
                } else if(dataWrapper[key1].response.respValueWrps.value != '' && dataWrapper[key1].showQsn == true){
                    dataWrapper[key1].response.respValueWrps.errorMsg ='';
                }
            } 
            
           else if(dataWrapper[key1].qNo == '0.2' && dataWrapper[key1].showQsn == true){
                if(dataWrapper[key1].response.schoolLocationWrps.selectedCountry == '' || dataWrapper[key1].response.schoolLocationWrps.selectedCountry == 'Please Select' ||
                   dataWrapper[key1].response.schoolLocationWrps.region == '' || dataWrapper[key1].response.schoolLocationWrps.cityOrTown == '') {
                    dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                    isGeneralComplete = false;
                }else {
                    dataWrapper[key1].response.respValueWrps.errorMsg ='';
                }
            }
           else if(dataWrapper[key1].qNo == '0.3'  && dataWrapper[key1].showQsn == true){
                if(dataWrapper[key1].response.schoolSizeWrps.numOfStudents == '' || dataWrapper[key1].response.schoolSizeWrps.numOfTeachers == '' || 
                   dataWrapper[key1].response.schoolSizeWrps.numOfTeachingAssistants == '' || dataWrapper[key1].response.schoolSizeWrps.numOfOtherStaff == ''){
                    dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                    isGeneralComplete = false;
                }else {
                    dataWrapper[key1].response.respValueWrps.errorMsg ='';
                }
            }
           /* else if(dataWrapper[key1].qNo == '0.4'  && dataWrapper[key1].showQsn == true){
                if(dataWrapper[key1].response.schoolTypeWrps.slected_privateORpublic == '' || dataWrapper[key1].response.schoolTypeWrps.selected_profitORnonprofit == ''){
                    dataWrapper[key1].response.respValueWrps.errorMsg ='Please answer the question';
                    isGeneralComplete = false;
                }else {
                    dataWrapper[key1].response.respValueWrps.errorMsg ='';
                }
            } */
            else if(dataWrapper[key1].qNo == '0.5'  && dataWrapper[key1].showQsn == true){
                if(dataWrapper[key1].response.studentsAgeRangeWrps.slected_lowerAge == '' || dataWrapper[key1].response.studentsAgeRangeWrps.slected_lowerAge == 'Please Select' ||
                   dataWrapper[key1].response.studentsAgeRangeWrps.selected_upperAge == '' || dataWrapper[key1].response.studentsAgeRangeWrps.selected_upperAge == 'Please Select'){
                    dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                    isGeneralComplete = false;
                }else {
                    dataWrapper[key1].response.respValueWrps.errorMsg ='';
                }
            }
            else if(dataWrapper[key1].qNo == '0.8' && dataWrapper[key1].showQsn == true){
                var unCheckedCount=0;
                for(var key12 in dataWrapper[key1].response.multiCheckboxWrps){
                    if(dataWrapper[key1].response.multiCheckboxWrps[key12].isChecked == false){
                        unCheckedCount+=1;
                    }
                }
                //console.log('unCheckedCount out>> '+unCheckedCount);
                if(unCheckedCount==4){
                    dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                    isGeneralComplete = false;
                }else if(unCheckedCount<4){
                    dataWrapper[key1].response.respValueWrps.errorMsg ='';
                }
            } 
        }
        
        //Innovation Section
        for(var key1 in dataWrapper){
            if(dataWrapper[key1].qNo == '1.1' || dataWrapper[key1].qNo == '1.2'){
                if(dataWrapper[key1].response.respValueWrps.value == '' && dataWrapper[key1].showQsn == true){
                    dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                    isInnovationComplete = false;
                } else{
                    dataWrapper[key1].response.respValueWrps.errorMsg ='';
                }
            }
        }
        
        //Impact Section
        for(var key1 in dataWrapper){
            //Text or Number
            if(dataWrapper[key1].qNo == '2.1' || dataWrapper[key1].qNo == '2.3' || dataWrapper[key1].qNo == '2.4' ||
               dataWrapper[key1].qNo == '2.8' || dataWrapper[key1].qNo == '2.8.1' || dataWrapper[key1].qNo == '2.8.2' ||
                dataWrapper[key1].qNo == '2.8.3' || dataWrapper[key1].qNo == '2.9' ||  dataWrapper[key1].qNo == '2.12'){
                if(dataWrapper[key1].response.respValueWrps.value == '' && dataWrapper[key1].showQsn == true){
                    dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                    isImpactComplete = false;
                } else {
                    dataWrapper[key1].response.respValueWrps.errorMsg ='';
                }
            }   
            
            //table
            if(dataWrapper[key1].qNo == '2.2' && dataWrapper[key1].showQsn == true  ){
                if(dataWrapper[key1].response.showCategoriesWrps.showEnergy == true){
                    for(var key12 in dataWrapper[key1].response.categoriesWrps[0]){
                        if(dataWrapper[key1].response.categoriesWrps[0][key12].goal == '' || dataWrapper[key1].response.categoriesWrps[0][key12].unit == '' || 
                           dataWrapper[key1].response.categoriesWrps[0][key12].currentLevel == '' || dataWrapper[key1].response.categoriesWrps[0][key12].target == '') {
                            dataWrapper[key1].response.showCategoriesWrps.energyError = $A.get("$Label.c.ZSP_PleaseAnswer");
                            isImpactComplete = false;
                            break;
                        }
                        else{
                            dataWrapper[key1].response.showCategoriesWrps.energyError ='';
                        }
                    }
                } 
                 if(dataWrapper[key1].response.showCategoriesWrps.showWater == true ){
                    for(var key12 in dataWrapper[key1].response.categoriesWrps[1]){
                        if(dataWrapper[key1].response.categoriesWrps[1][key12].goal == '' || dataWrapper[key1].response.categoriesWrps[1][key12].unit == '' || 
                           dataWrapper[key1].response.categoriesWrps[1][key12].currentLevel == '' || dataWrapper[key1].response.categoriesWrps[1][key12].target == '') {
                            dataWrapper[key1].response.showCategoriesWrps.waterError = $A.get("$Label.c.ZSP_PleaseAnswer");
                            isImpactComplete = false;
                            break;
                        }
                        else{
                            dataWrapper[key1].response.showCategoriesWrps.waterError ='';
                        }
                    }
                } 
                if(dataWrapper[key1].response.showCategoriesWrps.showFood == true){
                    for(var key12 in dataWrapper[key1].response.categoriesWrps[2]){
                        if(dataWrapper[key1].response.categoriesWrps[2][key12].goal == '' || dataWrapper[key1].response.categoriesWrps[2][key12].unit == '' || 
                           dataWrapper[key1].response.categoriesWrps[2][key12].currentLevel == '' || dataWrapper[key1].response.categoriesWrps[2][key12].target == '') {
                            dataWrapper[key1].response.showCategoriesWrps.foodError = $A.get("$Label.c.ZSP_PleaseAnswer");
                            isImpactComplete = false;
                            break;
                        }
                        else{
                            dataWrapper[key1].response.showCategoriesWrps.foodError ='';
                        }
                    }
                } 
                 if(dataWrapper[key1].response.showCategoriesWrps.showHealth == true ){
                    for(var key12 in dataWrapper[key1].response.categoriesWrps[3]){
                        if(dataWrapper[key1].response.categoriesWrps[3][key12].goal == '' || dataWrapper[key1].response.categoriesWrps[3][key12].unit == '' || 
                           dataWrapper[key1].response.categoriesWrps[3][key12].currentLevel == '' || dataWrapper[key1].response.categoriesWrps[3][key12].target == '') {
                            dataWrapper[key1].response.showCategoriesWrps.healthError = $A.get("$Label.c.ZSP_PleaseAnswer");
                            isImpactComplete = false;
                            break;
                        }
                        else{
                            dataWrapper[key1].response.showCategoriesWrps.healthError ='';
                        }
                    }
                }
            }                
            
            else if(dataWrapper[key1].qNo == '2.5' && dataWrapper[key1].showQsn == true){
                for(var key12 in dataWrapper[key1].response.skillsWrps){
                    if(dataWrapper[key1].response.skillsWrps[key12].skill == '') {
                        dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                        isImpactComplete = false;
                        break;
                    } 
                    else {
                        dataWrapper[key1].response.respValueWrps.errorMsg ='';
                    }
                }
            }
            
                else if(dataWrapper[key1].qNo == '2.6' && dataWrapper[key1].showQsn == true){
                    for(var key12 in dataWrapper[key1].response.projectWrps){
                        if(dataWrapper[key1].response.projectWrps[key12].name == '' || dataWrapper[key1].response.projectWrps[key12].position == '' || dataWrapper[key1].response.projectWrps[key12].role == '') {
                            dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                            isImpactComplete = false;
                            break;
                        } 
                        else {
                            dataWrapper[key1].response.respValueWrps.errorMsg ='';
                        }
                    }
                }
            
                    else if(dataWrapper[key1].qNo == '2.10' && dataWrapper[key1].showQsn == true){
                        for(var key12 in dataWrapper[key1].response.projectDetailsWrps){
                            if(dataWrapper[key1].response.projectDetailsWrps[key12].task == '' || dataWrapper[key1].response.projectDetailsWrps[key12].cost == '' ||
                               dataWrapper[key1].response.projectDetailsWrps[key12].description == '' || dataWrapper[key1].response.projectDetailsWrps[key12].workBy == '' || 
                               dataWrapper[key1].response.projectDetailsWrps[key12].duration == '') {
                                dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                                isImpactComplete = false;
                                break;
                            } 
                            else {
                                dataWrapper[key1].response.respValueWrps.errorMsg ='';
                            }
                        }
                    }
        }  
        
        //Inspiration Section
        for(var key1 in dataWrapper){
            //Text or Number
            if(dataWrapper[key1].qNo == '3.1' || dataWrapper[key1].qNo == '3.2' || dataWrapper[key1].qNo == '3.3'){
                if(dataWrapper[key1].response.respValueWrps.value == '' && dataWrapper[key1].showQsn == true){
                    dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                    isInspirationComplete = false;
                } else{
                    dataWrapper[key1].response.respValueWrps.errorMsg ='';
                }
            }
        }
        
        //Other Info Section
        for(var key1 in dataWrapper){
            if(dataWrapper[key1].qNo == '4.1' || dataWrapper[key1].qNo == '4.2' || dataWrapper[key1].qNo == '4.3'){
                if(dataWrapper[key1].response.respValueWrps.value == '' && dataWrapper[key1].showQsn == true){
                    dataWrapper[key1].response.respValueWrps.errorMsg = $A.get("$Label.c.ZSP_PleaseAnswer");
                    isOtherInfoComplete = false;
                } else {
                    dataWrapper[key1].response.respValueWrps.errorMsg ='';
                }
            }
        }
    
     //sections conditions
        if(isGeneralComplete == false){
            if(ErrorMsg!= '' && ErrorMsg!= null)
                ErrorMsg += ',General Section';
            else
                ErrorMsg += 'General Section';
        }
        if(isInnovationComplete == false){
            if(ErrorMsg!= '' && ErrorMsg!= null)
                ErrorMsg += ',Innovation Section';
            else
                ErrorMsg += 'Innovation Section';
        }
         if(isImpactComplete == false){
            if(ErrorMsg!= '' && ErrorMsg!= null)
                ErrorMsg += ',Impact Section';
            else
                ErrorMsg += 'Impact Section';
         }
        if(isInspirationComplete == false){
            if(ErrorMsg!= '' && ErrorMsg!= null)
                ErrorMsg += ',Inspiration Section';
            else
                ErrorMsg += 'Inspiration Section';
        }
        if(isOtherInfoComplete == false){
            if(ErrorMsg!= '' && ErrorMsg!= null)
                ErrorMsg += ',Other Information Section';
            else
                ErrorMsg += 'Other Information Section';
        }
        
        
        if(ErrorMsg!= '' && ErrorMsg!= null)
            component.set("v.isSectionsError", true);
        else 
            component.set("v.isSectionsError", false);
        component.set("v.sectionsErrorMsg", 'Please fill the followning Sections: '+ErrorMsg);
        component.set("v.SchoolCatWrp", dataWrapper);
        console.log(JSON.stringify(dataWrapper));
        
        if(component.get("v.isSectionsError") == false && ErrorMsg == '' )
            helper.handleSaveHelper(component, event, helper); 
    },
                     
    addRow: function(component, event, helper){
        var questionNo = event.target.getAttribute("id"); 
        console.log(questionNo);  
         // 2.2.1 is Energy Table
         // 2.2.2 is Water Table
         // 2.2.3 is Food Table
         // 2.2.4 is Health Table
        var wrp = component.get("v.SchoolCatWrp");
        for(var key in wrp){
            if(questionNo == '2.2.1' && wrp[key].qNo == '2.2'){
                wrp[key].response.categoriesWrps[0].push({goal: '', goalPlaceholder: '', unit: '', unitPlaceholder: '', goalPlaceholder: '',
                                                          currentLevel: '', currentLevelPlaceholder: '', target: '', targetPlaceholder: '',});
            }
            if(questionNo == '2.2.2' && wrp[key].qNo == '2.2'){
                wrp[key].response.categoriesWrps[1].push({goal: '', goalPlaceholder: '', unit: '', unitPlaceholder: '', goalPlaceholder: '', 
                                                          currentLevel: '', currentLevelPlaceholder: '', target: '', targetPlaceholder: '',});
            }
            if(questionNo == '2.2.3' && wrp[key].qNo == '2.2'){
                wrp[key].response.categoriesWrps[2].push({goal: '', goalPlaceholder: '', unit: '', unitPlaceholder: '', goalPlaceholder: '', 
                                                          currentLevel: '', currentLevelPlaceholder: '', target: '', targetPlaceholder: '',});
            }
            if(questionNo == '2.2.4' && wrp[key].qNo == '2.2'){
                wrp[key].response.categoriesWrps[3].push({goal: '', goalPlaceholder: '', unit: '', unitPlaceholder: '', goalPlaceholder: '', 
                                                          currentLevel: '', currentLevelPlaceholder: '', target: '', targetPlaceholder: '',});
            }
            if(questionNo == '2.5' && wrp[key].qNo == '2.5'){
                wrp[key].response.skillsWrps.push({skill: '', skillWordCount: '', skillWordLimit: '10'});
            }
            if(questionNo == '2.6' && wrp[key].qNo == '2.6'){
                wrp[key].response.projectWrps.push({name: '', position: '', role: ''});
            }
            if(questionNo == '2.10' && wrp[key].qNo == '2.10'){
                wrp[key].response.projectDetailsWrps.push({task: '', cost: '', description: '', workBy: '', duration: ''});
            }
        }
        component.set("v.SchoolCatWrp", wrp); 
    },
    
    removeRow : function(component, event, helper){
        var whichOne = event.target.getAttribute("id"); 
        console.log(whichOne);
        // 2.2.1 is Energy Table
        // 2.2.2 is Water Table
        // 2.2.3 is Food Table
        // 2.2.4 is Health Table
        var tableInfo = [];
        tableInfo = whichOne.split(';');
        var rowIndex = tableInfo[0];
        var questionNo = tableInfo[1];
        console.log({rowIndex,questionNo});
        
        var wrp = component.get("v.SchoolCatWrp");
        for(var key in wrp){
            if(questionNo == '2.2.1' && wrp[key].qNo == '2.2'){
                wrp[key].response.categoriesWrps[0].splice(rowIndex, 1);
             }
            if(questionNo == '2.2.2' && wrp[key].qNo == '2.2'){
                wrp[key].response.categoriesWrps[1].splice(rowIndex, 1);
             }
            if(questionNo == '2.2.3' && wrp[key].qNo == '2.2'){
                wrp[key].response.categoriesWrps[2].splice(rowIndex, 1);
             }
            if(questionNo == '2.2.4' && wrp[key].qNo == '2.2'){
                wrp[key].response.categoriesWrps[3].splice(rowIndex, 1);
             }
            if(questionNo == '2.5' && wrp[key].qNo == '2.5'){
                wrp[key].response.skillsWrps.splice(rowIndex, 1);
             }
            if(questionNo == '2.6' && wrp[key].qNo == '2.6'){
                wrp[key].response.projectWrps.splice(rowIndex, 1);
             }
            if(questionNo == '2.10' && wrp[key].qNo == '2.10'){
                wrp[key].response.projectDetailsWrps.splice(rowIndex, 1);
             }
        }
       component.set("v.SchoolCatWrp", wrp);      
    }, 
                   
    viewAttach: function(component, event, helper) {
        var attachment = event.getSource().get("v.value");
        console.log('attachment ID'+attachment.Id); 
        console.log('View Attachment Classic >>> '+document.URL.split('/apex')[0]);
        console.log('View Attachment Lightning >>>  '+document.URL.split('/lightning')[0]);
        
        if(document.URL.includes('/apex'))
            window.open(document.URL.split('/apex')[0]+'/servlet/servlet.FileDownload?file='+attachment.Id+'&operationContext=S1', '_blank');
        
        if(document.URL.includes('/lightning'))
            window.open(document.URL.split('/lightning')[0]+'/servlet/servlet.FileDownload?file='+attachment.Id+'&operationContext=S1', '_blank');
       },
    
    removeAttach: function(component, event, helper) {
        var attachment = event.getSource().get("v.value")
        console.log('Remove Attachment'); 
        console.log('attachment ID'+attachment.Id); //attToDelete
        helper.loadAttachments(component, event, helper, attachment.Id);
    },
   
    handleFileUploadEvent: function(component, event, helper) {
        console.log('getAttachmentList parameter>>>  '+event.getParam("getAttachmentList"));
        if(event.getParam("getAttachmentList")==true)
            helper.loadAttachments(component, event, helper, null); 
    },
                     
    closeModel: function(component, event, helper) {
        component.set("v.showSaveDraftMsg", false);
    }
                     
});