({
    doInit : function(component, event, helper) {
        //getUserDetail
        var urlString = window.location.href;
        var baseURL = urlString.substring(0, urlString.indexOf("/ZSP"));
        component.set("v.cbaseURL", baseURL+'/ZSP');
        var actUserDetails = component.get("c.getUserDetail");
        actUserDetails.setCallback(this, function(response) {
            var state = response.getState();
            console.log('state actUserDetails--> '+state);
            if(component.isValid() && state === "SUCCESS") {
                var result = response.getReturnValue();
                console.log('result actUserDetails>>> '+JSON.stringify(result));
                component.set("v.userId", result.userId);
                component.set("v.userFirstName", result.firstName);
                component.set("v.userLastName", result.lastName);
            }
            else if(component.isValid() && state === "ERROR"){
                console.log("Exception caught successfully - actUserDetails");
                console.log("Error object", response);
                console.log("Error Message", response.getError()[0]);
                console.log("Error Message", response.getError()[0].message);
                console.log("Error Message", response.getState());
                console.log("Error object", JSON.stringify(response));
            }
        });
        $A.enqueueAction(actUserDetails);
    },
    
    viewProfile: function(component, event, helper){
        var userId = component.get("v.userId");
        console.log('viewProfile  >>> '+document.URL.split('ZSP/')[0]+'ZSP/s/profile/'+userId);
        window.open(document.URL.split('ZSP/')[0]+'ZSP/s/profile/'+userId, '_blank');
    },
    
    logout: function(component, event, helper){
        var userId = component.get("v.userId");
        console.log('Logout  >>> '+document.URL.split('ZSP/')[0]+'ZSP/secur/logout.jsp');
        window.open(document.URL.split('ZSP/')[0]+'ZSP/secur/logout.jsp', '_self');
    },
})